import { signalRService } from './signalr'
import { useAppStore } from '../store/useAppStore'
import i18n from '../i18n'
import manualGateProcessorUrl from './manual-gate-processor?worker&url'
import micPipelineDeepFilterUrl from './mic-pipeline-deepfilter?worker&url'
import micPipelineRnnoiseUrl from './mic-pipeline-rnnoise?worker&url'
import micTestCaptureProcessorUrl from './mic-test-capture-processor?worker&url'
import playbackBufferProcessorUrl from './playback-buffer-processor?worker&url'
import ultraJitterProcessorUrl from './ultra-jitter-processor?worker&url'
import VadWorker from './silero-vad.worker?worker'
import {
  getDeepFilterAsset,
  getRustVoicingModule,
  getDeepFilterPayload,
  getSileroModel,
  preloadNoiseAssets,
  type DeepFilterPayload
} from './audio-assets'
import { WebRtcVadSidecar } from './webrtc-vad'
import { MediaHealthTracker } from './media-health'
import { logDiagnostic } from './diagnostics'
import {
  RC_DC_LABEL,
  RC_DC_ID,
  RC_OP_MOVE,
  RC_OP_MOUSE_DOWN,
  RC_OP_MOUSE_UP,
  RC_OP_WHEEL,
  RC_OP_KEY_DOWN,
  RC_OP_KEY_UP,
  RC_OP_PING,
  RC_OP_HOST_ACTIVE,
  RC_OP_HOST_IDLE,
  RC_OP_RESET,
  RC_OP_HOST_REVOKED,
  RC_OP_BUSY,
  RC_OP_START,
  RC_OP_STOP,
  RC_OP_KEYFRAME_REQUEST,
  RC_OP_ACCEPT,
  RemoteControlProtocol,
  isShortcutSafe
} from './remoteControl'

export const VAD_CALIBRATION_ENABLED: boolean = false
const FIXED_SILERO_THRESHOLD = 0.4

const DEFAULT_SILERO_THRESHOLD = 0.4
const MIN_VOICE_CALIBRATION_WINDOWS = 12
const VAD_CALIBRATION_MARGIN_RATIO = 0.42
const VAD_CALIBRATION_MARGIN_FLOOR = 0.06
const VAD_CALIBRATION_MIN_THRESHOLD = 0.4
const VAD_CALIBRATION_MAX_THRESHOLD = 0.85

const vadThresholdFromVoiceLow = (voiceLow: number): number => {
  const margin = Math.max(VAD_CALIBRATION_MARGIN_FLOOR, voiceLow * VAD_CALIBRATION_MARGIN_RATIO)
  return Math.max(
    VAD_CALIBRATION_MIN_THRESHOLD,
    Math.min(VAD_CALIBRATION_MAX_THRESHOLD, voiceLow - margin)
  )
}

export type SmartNoiseModel = 'deepfilter' | 'rnnoise'
const SMART_MODEL_STORAGE_KEY = 'zabor_smart_noise_model'
const SUPPRESSION_STRENGTH_STORAGE_KEY = 'zabor_suppression_strength_db'
const SPEECH_ANALYZER_STORAGE_KEY = 'zabor_speech_analyzer_enabled'
const ECHO_CANCELLATION_STORAGE_KEY = 'zabor_echo_cancellation_enabled'
const NOISE_SUPPRESSION_STORAGE_KEY = 'zabor_noise_suppression'
const RELAY_ONLY_STORAGE_KEY = 'zabor_relay_only_ice'
const ULTRA_LOW_LATENCY_STORAGE_KEY = 'zabor_ultra_low_latency'

export const MIN_SUPPRESSION_STRENGTH_DB = 5
export const MAX_SUPPRESSION_STRENGTH_DB = 30

const DEEPFILTER_LOCAL_BASE = 'zabor-local://deepfilternet3'
const DEEPFILTER_ASSETS = new Set(['pkg/df_bg.wasm', 'models/DeepFilterNet3_onnx.tar.gz'])
const DEEPFILTER_MIN_ATTEN = MIN_SUPPRESSION_STRENGTH_DB
const DEEPFILTER_MAX_ATTEN = MAX_SUPPRESSION_STRENGTH_DB
const SUPPRESSION_SOFT_KNEE_DB = 24
const SUPPRESSION_ABOVE_KNEE_SLOPE = 0.5
const DEEPFILTER_SMART_DEFAULT_ATTEN = 15
const DEEPFILTER_MANUAL_ATTEN = 7
const DEEPFILTER_POST_FILTER_BETA = 0.02
const DEEPFILTER_MAX_POST_FILTER_BETA = 0.05
const TARGET_SPEECH_TO_NOISE_DB = 55
const ALC_TARGET_DBFS = -20
const TARGET_RESIDUAL_NOISE_DBFS = ALC_TARGET_DBFS - TARGET_SPEECH_TO_NOISE_DB
const ASSUMED_SPEECH_LEVEL_DBFS = -30
const DEFAULT_VAD_TRACKER_SEED = 0.05
const MIN_CALIBRATION_FRAMES = 20
const PLAYBACK_MAKEUP_GAIN_DB = 0
const PLAYBACK_VOICE_LIMIT_DB = -1.5
const PLAYBACK_STREAM_LIMIT_DB = -1.5
const PLAYBACK_VOICE_SPREAD = 0
const PLAYBACK_SEAT_GLIDE_S = 0.08
const OPUS_AUDIO_BITRATE = 64_000
const ULTRA_OPUS_BITRATE = 96_000
const MIC_CAPTURE_TIMEOUT_MS = 5_000
const SILERO_MODEL_LOAD_TIMEOUT_MS = 10_000
const VAD_WORKER_READY_TIMEOUT_MS = 15_000
const CALIBRATION_PREPARE_TIMEOUT_MS = 20_000
const CALIBRATION_CLEANUP_TIMEOUT_MS = 5_000
const RUMBLE_GUARD_HZ = 70
const RUMBLE_GUARD_QS = [0.5177, 0.7071, 1.9319]
const PRE_ENGINE_SEED_FIELDS = [
  'engineInputGain',
  'engineInputSpeechRms',
  'engineInputPeakEnvelope',
  'noiseRmsHigh'
] as const
const ALC_SEED_FIELDS = [
  'alcGain',
  'alcSpeechRms',
  'alcPeakEnvelope'
] as const
const MIC_TEST_DURATION_MS = 5_000
const MIC_TEST_CAPTURE_GRACE_MS = 4_000
const MIC_TEST_PIPELINE_FLUSH_MS = 280
const MIC_TEST_MONITOR_SETTLE_MS = 120
const MIC_TEST_SEEK_TAIL_S = 0.05

export const MIC_TEST_SILENCE_DBFS = -70

export type MicTestClip = {
  durationSeconds: number
  peakDb: number
}

type SpeakingEntry = {
  timer: NodeJS.Timeout
  stream: MediaStream

  nodes: AudioNode[]
}

type CalibrationResult = {
  vadThreshold?: number
  voiceLow?: number
  voiceMedian?: number
  voiceHigh?: number
  peakProbability?: number
  acceptedVoiceWindows?: number
  noiseFloor?: number
  lowNoise?: number
  peakNoise?: number
  attenuationLimit?: number
  zeroCrossingRate?: number
  spectralTilt?: number
  acceptedFrames?: number
  rejectedSpeechFrames?: number
  noiseVadMedian?: number
  noiseVadHigh?: number
}

type StoredVoiceProfile = {
  version: 41
  timestamp: number
  vadThreshold: number
  voiceLow: number
  voiceMedian: number
  voiceHigh: number
}

type StoredEnvironmentProfile = {
  version: number
  timestamp: number
  noiseFloor: number
  lowNoise: number
  peakNoise: number
  attenuationLimit: number
  zeroCrossingRate: number
  spectralTilt: number
  noiseVadMedian?: number
  noiseVadHigh?: number
}

type AudioDevices = {
  inputs: MediaDeviceInfo[]
  outputs: MediaDeviceInfo[]
}

type AudioDeviceChangeResult = AudioDevices & {
  inputDeviceId: string
  outputDeviceId: string
}

export type CalibrationFailureCode =
  | 'CALIBRATION_ENGINE_UNAVAILABLE'
  | 'CALIBRATION_NO_MIC'
  | 'CALIBRATION_BUSY'
  | 'CALIBRATION_TIMEOUT'
  | 'CALIBRATION_NEEDS_VOICE'
  | 'CALIBRATION_NEEDS_SILENCE'

export class CalibrationError extends Error {
  constructor(public readonly code: CalibrationFailureCode, public readonly detail = '') {
    super(detail ? `${code}: ${detail}` : code)
    this.name = 'CalibrationError'
  }
}

export function describeMediaError(error: unknown): string {
  if (error && typeof error === 'object' && 'name' in error) {
    const named = error as { name?: string, message?: string }
    return `${named.name || 'Error'}: ${named.message || ''}`.trim()
  }
  return error instanceof Error ? error.message : String(error)
}

export type MicrophoneErrorKind = 'micNoAccess' | 'micBusy' | 'micNotFound' | 'unknown'

export function classifyMicrophoneError(detail: string): MicrophoneErrorKind {
  if (/NotReadableError|TrackStartError|AbortError/i.test(detail)) return 'micBusy'
  if (/NotFoundError|DevicesNotFoundError|OverconstrainedError/i.test(detail)) return 'micNotFound'
  if (/NotAllowedError|PermissionDeniedError|SecurityError|MIC_ACCESS_FAILED/i.test(detail)) return 'micNoAccess'
  return 'unknown'
}

function withTimeout<T>(
  operation: Promise<T>,
  timeoutMs: number,
  message: string,
  onLate?: (value: T) => void
): Promise<T> {
  let timer: number | undefined
  let timedOut = false
  const guard = new Promise<never>((_, reject) => {
    timer = window.setTimeout(() => {
      timedOut = true
      reject(new Error(message))
    }, timeoutMs)
  })
  if (onLate) {
    operation.then(value => { if (timedOut) onLate(value) }).catch(() => { })
  }
  return Promise.race([operation, guard]).finally(() => {
    if (timer !== undefined) window.clearTimeout(timer)
  })
}

async function safeResumeContext(ctx: AudioContext | null | undefined, timeoutMs = 300): Promise<void> {
  if (!ctx || ctx.state !== 'suspended') return
  try {
    await Promise.race([
      ctx.resume(),
      new Promise<void>(resolve => setTimeout(resolve, timeoutMs))
    ])
  } catch { }
}

const SILENCE_SUPPRESSION_OFF = { voiceActivityDetection: false } as RTCOfferOptions
const SILENCE_SUPPRESSION_OFF_WITH_ICE_RESTART = {
  iceRestart: true,
  voiceActivityDetection: false
} as RTCOfferOptions

const ULTRA_PLAYOUT_DELAY_HINT_S = 0.02
const ULTRA_JITTER_MIN_MS = 7
const ULTRA_JITTER_MAX_MS = 140
const ULTRA_JITTER_HEADROOM_MS = 6
const ULTRA_JITTER_FACTOR = 2.2
const ULTRA_JITTER_ATTACK = 0.6
const ULTRA_JITTER_RELEASE = 0.25
const ULTRA_FRAME_MS_SAFE = 10
const ULTRA_FRAME_MS_FAST = 5
const ULTRA_FRAME_DOWNGRADE_LOSS = 0.05
const ULTRA_FRAME_DOWNGRADE_TICKS = 2
const ULTRA_FRAME_CLEAN_TICKS = 3
const ULTRA_FRAME_MIN_SWITCH_MS = 8000
const ULTRA_CONCEAL_BUMP_SAMPLES = 4800
const ULTRA_CONCEAL_BUMP_MS = 30
const ULTRA_CONCEAL_CEILING_MS = 70
const ULTRA_CONCEAL_DECAY = 0.5
const ULTRA_MIC_LATENCY_HINT_S = 0
const ULTRA_OUTPUT_LATENCY_HINT_S = 0
const ULTRA_REORDER_HOLD = 0
const ULTRA_CUSTOM_UNDERRUN_FALLBACK = 40
const ULTRA_PENDING_PREROLL_MAX = 40
const ULTRA_DC_LABEL = 'zabor-ultra-voice-v1'
const ULTRA_DC_ID = 4242
const ULTRA_DC_OPUS_FRAME_US = 5000
const ULTRA_DC_HEADER_BYTES = 8
const ULTRA_DC_MAX_BUFFERED_BYTES = 256
const ULTRA_DC_STALE_WINDOW_SAMPLES = 48000
const ULTRA_CUSTOM_AUDIO_DROUGHT_MS = 1200
const ULTRA_CUSTOM_MAX_FAILURES = 3
const ULTRA_HI_MAX_RESENDS = 10
const ULTRA_SEND_MAX_START_FAILURES = 3

type WebCodecsAudioData = {
  numberOfFrames: number
  numberOfChannels: number
  sampleRate: number
  format: string | null
  timestamp: number
  copyTo: (dest: ArrayBufferView, options: { planeIndex: number; format?: string }) => void
  close: () => void
}

type WebCodecsAudioDataCtor = new (init: {
  format: string
  sampleRate: number
  numberOfFrames: number
  numberOfChannels: number
  timestamp: number
  data: ArrayBufferView
}) => WebCodecsAudioData

type WebCodecsAudioDecoder = {
  state: string
  configure: (config: { codec: string; sampleRate: number; numberOfChannels: number }) => void
  decode: (chunk: unknown) => void
  close: () => void
}

type WebCodecsAudioDecoderCtor = new (init: {
  output: (data: WebCodecsAudioData) => void
  error: (reason: unknown) => void
}) => WebCodecsAudioDecoder

type WebCodecsEncodedAudioChunkCtor = new (init: {
  type: 'key' | 'delta'
  timestamp: number
  data: ArrayBuffer | ArrayBufferView
}) => unknown

type WebCodecsEncodedAudioChunk = {
  type: 'key' | 'delta'
  timestamp: number
  duration: number | null
  byteLength: number
  copyTo: (dest: ArrayBufferView) => void
}

type WebCodecsAudioEncoder = {
  state: string
  configure: (config: {
    codec: string
    sampleRate: number
    numberOfChannels: number
    bitrate?: number
    opus?: { frameDuration?: number; useinbandfec?: boolean; usedtx?: boolean; application?: string; complexity?: number }
  }) => void
  encode: (data: WebCodecsAudioData) => void
  flush: () => Promise<void>
  close: () => void
}

type WebCodecsAudioEncoderCtor = new (init: {
  output: (chunk: WebCodecsEncodedAudioChunk, metadata?: unknown) => void
  error: (reason: unknown) => void
}) => WebCodecsAudioEncoder

type MediaStreamTrackProcessorCtor = new (init: { track: MediaStreamTrack }) => {
  readable: ReadableStream<WebCodecsAudioData>
}

type UltraCodecGlobals = {
  AudioDecoder?: WebCodecsAudioDecoderCtor
  EncodedAudioChunk?: WebCodecsEncodedAudioChunkCtor
  AudioEncoder?: WebCodecsAudioEncoderCtor
  MediaStreamTrackProcessor?: MediaStreamTrackProcessorCtor
  AudioData?: WebCodecsAudioDataCtor
}

type UltraEncodedFrameMessage = {
  timestamp: number
  sequenceNumber?: number
  data: ArrayBuffer
}

type UltraJitterStatsMessage = {
  type: string
  bufferMs?: number
  targetMs?: number
  underruns?: number
}

function optimizeSDP(sdp: string, isRelayOnly = false, isUltraLowLatency = false, ultraPtimeMs = 10, isRemoteControl = false): string {
  let lines = sdp.split('\r\n')

  if (isRelayOnly) {
    lines = lines.filter(line => {
      if (line.startsWith('a=candidate:')) {
        return line.includes('typ relay')
      }
      return true
    })
  }

  const opusRegex = /a=rtpmap:(\d+)\s+opus\/48000\/2/i
  const audioMatch = sdp.match(opusRegex)
  if (audioMatch) {
    const pt = audioMatch[1]
    const ptime = isUltraLowLatency ? ultraPtimeMs : 20
    const minPtime = isUltraLowLatency ? ultraPtimeMs : 20
    const maxPtime = isUltraLowLatency ? 20 : 60
    const opusFmtp = `useinbandfec=1;usedtx=0;maxaveragebitrate=${OPUS_AUDIO_BITRATE};maxplaybackrate=48000;sprop-maxcapturerate=48000;stereo=0;sprop-stereo=0;cbr=0;ptime=${ptime};minptime=${minPtime};maxptime=${maxPtime}`
    let fmtpFound = false
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith(`a=fmtp:${pt}`)) {
        lines[i] = `a=fmtp:${pt} ${opusFmtp}`
        fmtpFound = true
        break
      }
    }
    if (!fmtpFound) {
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].startsWith(`a=rtpmap:${pt}`)) {
          lines.splice(i + 1, 0, `a=fmtp:${pt} ${opusFmtp}`)
          break
        }
      }
    }
    if (!isUltraLowLatency) {
      const hasNack = lines.some(l => l.startsWith(`a=rtcp-fb:${pt} nack`))
      if (!hasNack) {
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].startsWith(`a=fmtp:${pt}`) || lines[i].startsWith(`a=rtpmap:${pt}`)) {
            lines.splice(i + 1, 0, `a=rtcp-fb:${pt} nack`)
            break
          }
        }
      }
    }
    let audioSectionIdx = -1
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].startsWith('m=audio')) {
        audioSectionIdx = i
        break
      }
    }
    if (audioSectionIdx !== -1) {
      const comfortNoisePayloads = new Set<string>()
      for (const line of lines) {
        const comfortNoiseMatch = line.match(/^a=rtpmap:(\d+)\s+CN\/\d+/i)
        if (comfortNoiseMatch) comfortNoisePayloads.add(comfortNoiseMatch[1])
      }
      const mediaParts = lines[audioSectionIdx].split(' ')
      const payloads = mediaParts.slice(3).filter(payload => !comfortNoisePayloads.has(payload))
      lines[audioSectionIdx] = [...mediaParts.slice(0, 3), pt, ...payloads.filter(payload => payload !== pt)].join(' ')
      if (comfortNoisePayloads.size > 0) {
        lines = lines.filter(line => {
          const attributeMatch = line.match(/^a=(?:rtpmap|fmtp|rtcp-fb):(\d+)/)
          return !attributeMatch || !comfortNoisePayloads.has(attributeMatch[1])
        })
      }

      let audioSectionEnd = lines.length
      for (let i = audioSectionIdx + 1; i < lines.length; i++) {
        if (lines[i].startsWith('m=')) {
          audioSectionEnd = i
          break
        }
      }
      for (let i = audioSectionEnd - 1; i > audioSectionIdx; i--) {
        if (/^b=(AS|TIAS):/i.test(lines[i]) || /^a=(?:ptime|maxptime):/i.test(lines[i])) lines.splice(i, 1)
      }
      audioSectionEnd = lines.length
      for (let i = audioSectionIdx + 1; i < lines.length; i++) {
        if (lines[i].startsWith('m=')) {
          audioSectionEnd = i
          break
        }
      }
      let bandwidthInsertIndex = audioSectionEnd
      for (let i = audioSectionIdx + 1; i < audioSectionEnd; i++) {
        if (lines[i].startsWith('a=')) {
          bandwidthInsertIndex = i
          break
        }
      }
      lines.splice(
        bandwidthInsertIndex,
        0,
        `b=AS:${Math.ceil(OPUS_AUDIO_BITRATE / 1000)}`,
        `b=TIAS:${OPUS_AUDIO_BITRATE}`,
        `a=ptime:${ptime}`,
        `a=maxptime:${maxPtime}`
      )
    }
  }

  let videoSectionIdx = -1
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].startsWith('m=video')) {
      videoSectionIdx = i
      break
    }
  }

  if (videoSectionIdx !== -1) {
    const h264Payloads: string[] = []
    const fecPayloads: string[] = []
    const rtxCandidates: string[] = []
    const aptByPayload: Record<string, string> = {}
    const fmtpByPayload: Record<string, string> = {}
    const usedExtmapIds = new Set<number>()
    let hasPlayoutDelayExt = false
    let hasPlayoutDelayAttr = false

    for (let i = videoSectionIdx + 1; i < lines.length; i++) {
      if (lines[i].startsWith('m=')) break
      const extmapMatch = lines[i].match(/^a=extmap:(\d+)(?:\/[a-z]+)?\s+(\S+)/i)
      if (extmapMatch) {
        usedExtmapIds.add(parseInt(extmapMatch[1], 10))
        if (extmapMatch[2] === 'http://www.webrtc.org/experiments/rtp-hdrext/playout-delay') {
          hasPlayoutDelayExt = true
        }
      }
      if (lines[i].startsWith('a=playout-delay:')) {
        hasPlayoutDelayAttr = true
      }
      const rtpmapMatch = lines[i].match(/^a=rtpmap:(\d+)\s+([A-Za-z0-9-]+)\/90000/i)
      if (rtpmapMatch) {
        const pt = rtpmapMatch[1]
        const codec = rtpmapMatch[2].toLowerCase()
        if (codec === 'h264') h264Payloads.push(pt)
        else if (codec === 'rtx') rtxCandidates.push(pt)
        else if (codec === 'red' || codec === 'ulpfec') fecPayloads.push(pt)
      }
      const fmtpMatch = lines[i].match(/^a=fmtp:(\d+)\s+(.+)/i)
      if (fmtpMatch) {
        fmtpByPayload[fmtpMatch[1]] = fmtpMatch[2]
        const aptMatch = fmtpMatch[2].match(/apt=(\d+)/i)
        if (aptMatch) aptByPayload[fmtpMatch[1]] = aptMatch[1]
      }
    }

    // Prioritize H.264 Constrained Baseline (profile-level-id=42e01f / 42001f with packetization-mode=1)
    const getH264Score = (pt: string): number => {
      const fmtp = (fmtpByPayload[pt] || '').toLowerCase()
      const isPacketizationMode1 = fmtp.includes('packetization-mode=1')
      const isConstrainedBaseline1f = fmtp.includes('profile-level-id=42e01f') || fmtp.includes('profile-level-id=42001f')
      const isConstrainedBaseline = fmtp.includes('profile-level-id=42e0') || fmtp.includes('profile-level-id=4200')
      if (isConstrainedBaseline1f && isPacketizationMode1) return 100
      if (isConstrainedBaseline1f) return 80
      if (isConstrainedBaseline && isPacketizationMode1) return 60
      if (isConstrainedBaseline) return 40
      if (isPacketizationMode1) return 20
      return 10
    }
    h264Payloads.sort((a, b) => getH264Score(b) - getH264Score(a))

    let playoutDelayExtId = -1
    if (!hasPlayoutDelayExt) {
      for (let id = 1; id <= 14; id++) {
        if (!usedExtmapIds.has(id)) {
          playoutDelayExtId = id
          break
        }
      }
    }

    if (h264Payloads.length > 0) {
      const keptPayloads = new Set([...h264Payloads, ...fecPayloads])
      const rtxPayloads: string[] = []
      for (const pt of rtxCandidates) {
        const apt = aptByPayload[pt]
        if (apt && keptPayloads.has(apt)) {
          rtxPayloads.push(pt)
          keptPayloads.add(pt)
        }
      }
      const orderedPayloads = [...h264Payloads, ...rtxPayloads, ...fecPayloads]

      const filteredLines: string[] = []
      let skipVideoTracks = false

      for (let i = 0; i < lines.length; i++) {
        if (i === videoSectionIdx) {
          const parts = lines[i].split(' ')
          const newVideoLine = `${parts[0]} ${parts[1]} ${parts[2]} ${orderedPayloads.join(' ')}`
          filteredLines.push(newVideoLine)
          if (!hasPlayoutDelayExt && playoutDelayExtId !== -1) {
            filteredLines.push(`a=extmap:${playoutDelayExtId} http://www.webrtc.org/experiments/rtp-hdrext/playout-delay`)
          }
          if (isRemoteControl && !hasPlayoutDelayAttr) {
            filteredLines.push('a=playout-delay:0,0')
          }
          skipVideoTracks = true
          continue
        }
        if (skipVideoTracks && lines[i].startsWith('m=')) {
          skipVideoTracks = false
        }
        if (skipVideoTracks) {
          if (lines[i].startsWith('a=playout-delay:')) {
            if (isRemoteControl) {
              filteredLines.push('a=playout-delay:0,0')
            } else {
              filteredLines.push(lines[i])
            }
            continue
          }
          if (lines[i].startsWith('a=rtpmap:') || lines[i].startsWith('a=fmtp:') || lines[i].startsWith('a=rtcp-fb:')) {
            const ptMatch = lines[i].match(/^a=(?:rtpmap|fmtp|rtcp-fb):(\d+)/i)
            if (ptMatch && keptPayloads.has(ptMatch[1])) {
              filteredLines.push(lines[i])
            }
          } else {
            filteredLines.push(lines[i])
          }
        } else {
          filteredLines.push(lines[i])
        }
      }
      lines = filteredLines
    } else {
      const filteredLines: string[] = []
      let inVideoSection = false
      for (let i = 0; i < lines.length; i++) {
        if (i === videoSectionIdx) {
          filteredLines.push(lines[i])
          if (!hasPlayoutDelayExt && playoutDelayExtId !== -1) {
            filteredLines.push(`a=extmap:${playoutDelayExtId} http://www.webrtc.org/experiments/rtp-hdrext/playout-delay`)
          }
          if (isRemoteControl && !hasPlayoutDelayAttr) {
            filteredLines.push('a=playout-delay:0,0')
          }
          inVideoSection = true
          continue
        }
        if (inVideoSection && lines[i].startsWith('m=')) {
          inVideoSection = false
        }
        if (inVideoSection && lines[i].startsWith('a=playout-delay:')) {
          if (isRemoteControl) {
            filteredLines.push('a=playout-delay:0,0')
          } else {
            filteredLines.push(lines[i])
          }
          continue
        }
        filteredLines.push(lines[i])
      }
      lines = filteredLines
    }
  }

  return lines.join('\r\n')
}

function createSilentAudioStream(): MediaStream {
  const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
  const dst = ctx.createMediaStreamDestination()
  const osc = ctx.createOscillator()
  const gain = ctx.createGain()
  gain.gain.value = 0
  osc.connect(gain)
  gain.connect(dst)
  osc.start()
  return dst.stream
}

export class WebRTCManager {
  private static readonly CALIBRATION_SCHEMA_VERSION = 41
  private static readonly CALIBRATION_SCHEMA_KEY = 'zabor_mic_calibration_schema'
  private static readonly CALIBRATION_PROFILE_MAX_AGE_MS = 90 * 24 * 60 * 60 * 1000
  private localStream: MediaStream | null = null
  private rawStream: MediaStream | null = null
  private rawStreamIsFallback = false
  private activeRawDeviceId: string | null = null
  public localVideoStream: MediaStream | null = null
  private statsInterval: NodeJS.Timeout | null = null
  private streamGainNodes: Map<string, GainNode> = new Map()
  private streamSourceNodes: Map<string, MediaStreamAudioSourceNode> = new Map()
  private streamDelayNodes: Map<string, DelayNode> = new Map()
  private streamCaptureContext: AudioContext | null = null
  private streamCaptureNode: AudioWorkletNode | null = null
  private streamCaptureDestination: MediaStreamAudioDestinationNode | null = null
  private removeStreamAudioListener: (() => void) | null = null

  private streamSyncInterval: NodeJS.Timeout | null = null
  private streamSyncOffsetEma: Map<string, number> = new Map()
  private streamSyncSkew: Map<string, number> = new Map()
  private videoJitterTargetMs: Map<string, number> = new Map()
  private lastVideoPacketsLost: Map<string, number> = new Map()
  private lastVideoPacketsReceived: Map<string, number> = new Map()
  private lastVideoFreezeCount: Map<string, number> = new Map()
  private viewerStates: Map<string, 'watching' | 'preview'> = new Map()
  private viewInterestTimer: NodeJS.Timeout | null = null
  private reportedViewStates: Map<string, 'watching' | 'preview'> = new Map()
  private sfuPubConnection: RTCPeerConnection | null = null
  private sfuPubEpoch = 0
  private sfuPubActive = false
  private sfuPubPauseTimer: NodeJS.Timeout | null = null
  private sfuPubCloseTimer: NodeJS.Timeout | null = null
  private sfuPubWatchdogTimer: NodeJS.Timeout | null = null
  private pendingSfuPublish: { epoch: number; nodeId: string } | null = null
  private isStartingScreenShare = false
  private screenShareGeneration = 0
  private screenShareStartPromise: Promise<unknown> | null = null
  private sfuSubscriptionTasks = new Map<string, Promise<void>>()
  private sfuPublishTask: Promise<void> | null = null
  private mediaSessionGeneration = 0
  private microphoneGeneration = 0
  private mediaHealth = new MediaHealthTracker()
  private mediaHealthInFlight = false
  private diagnosticConnections = new WeakMap<RTCPeerConnection, number>()
  private nextDiagnosticConnection = 0
  private keyframeRequestedAt = new Map<string, number>()
  private remoteControlVersions = new Map<string, number>()
  private hostControlRevoked = false
  private p2pSwitchTasks = new Map<string, Promise<void>>()
  private sfuFallbackPeers: Set<string> = new Set()
  private sfuReadyPeers = new Set<string>()
  private sfuSubConnections: Map<string, RTCPeerConnection> = new Map()
  private sfuSubEpochs: Map<string, number> = new Map()
  private sfuSubWatchdogTimers: Map<string, NodeJS.Timeout> = new Map()
  private streamDeliveryModes: Map<string, { mode: 'p2p' | 'sfu'; epoch: number; nodeId?: string }> = new Map()
  private p2pStreamsBackup: Map<string, MediaStream> = new Map()
  private p2pAudioBackup: Map<string, { track: MediaStreamTrack; receiver?: RTCRtpReceiver; stream?: MediaStream }> = new Map()
  private sfuPreviewTearDownTimers: Map<string, NodeJS.Timeout> = new Map()

  private peerConnections: Map<string, RTCPeerConnection> = new Map()
  private lastPacketsLost: Map<string, number> = new Map()
  private lastPacketsSent: Map<string, number> = new Map()
  private lastFramesDropped: Map<string, number> = new Map()
  private lossLadderStep: Map<string, number> = new Map()
  private lossBreachCount: Map<string, number> = new Map()
  private lossCleanCount: Map<string, number> = new Map()
  private lossBaselineRtt: Map<string, number> = new Map()
  private appliedVideoProfiles: Map<string, string> = new Map()

  private pendingCandidates: Map<string, RTCIceCandidateInit[]> = new Map()

  private dcTimers: Map<string, NodeJS.Timeout> = new Map()

  private iceTimeoutTimers: Map<string, NodeJS.Timeout> = new Map()

  private retryCount: Map<string, number> = new Map()

  private rollbackCount: Map<string, number> = new Map()

  private iceRestartInFlight: Set<string> = new Set()

  private pendingRenegotiation: Set<string> = new Set()
  private pendingIceRestart: Set<string> = new Set()
  private peerSignalingQueues: Map<string, Promise<void>> = new Map()
  private isMakingOffer: Map<string, boolean> = new Map()
  private isSettingRemoteAnswerPending: Map<string, boolean> = new Map()
  private offerEpoch: Map<string, number> = new Map()
  private userVoiceTrackIds: Map<string, string> = new Map()
  private userStreamAudioTrackIds: Map<string, string> = new Map()
  private userVoiceStreamIds: Map<string, string> = new Map()
  private userScreenStreamIds: Map<string, string> = new Map()
  private audioHealthInterval: NodeJS.Timeout | null = null
  private lastAudioPacketTimes: Map<string, number> = new Map()
  private lastAudioConcealment: Map<string, number> = new Map()
  private ultraJitterTargetMs: Map<string, number> = new Map()
  private ultraFrameMs: Map<string, number> = new Map()
  private ultraFrameCleanTicks: Map<string, number> = new Map()
  private ultraFrameLastSwitchAt: Map<string, number> = new Map()
  private lastInboundLoss: Map<string, number> = new Map()
  private lastInboundReceived: Map<string, number> = new Map()
  private renegotiationStuckSince: Map<string, number> = new Map()
  private ultraRttMs: Map<string, number> = new Map()
  private ultraConcealRate: Map<string, number> = new Map()
  private ultraConcealBurstMs: Map<string, number> = new Map()
  private ultraFrameLossTicks: Map<string, number> = new Map()
  private peerLastSettledState: Map<string, 'connected' | 'disconnected' | 'failed'> = new Map()
  private lastSoftRefreshAt: Map<string, number> = new Map()

  private enqueueSignalingTask(userId: string, task: () => Promise<void>): Promise<void> {
    const generation = this.mediaSessionGeneration
    const currentQueue = this.peerSignalingQueues.get(userId) || Promise.resolve()
    const nextQueue = currentQueue
      .then(async () => {
        if (this.mediaSessionGeneration !== generation) return
        await task()
      })
      .catch(err => {
        console.error(`[WebRTC] Signaling task error for peer ${userId}:`, err)
      })
    this.peerSignalingQueues.set(userId, nextQueue)
    void nextQueue.finally(() => {
      if (this.peerSignalingQueues.get(userId) === nextQueue) this.peerSignalingQueues.delete(userId)
    })
    return nextQueue
  }

  private static readonly MAX_ICE_RETRIES = 4

  private static readonly MAX_ROLLBACKS = 3

  private static readonly ICE_TIMEOUT_MS = 15000
  private static readonly DISCONNECTED_GRACE_MS = 2500
  private static readonly FAST_ICE_TIE_BREAK_MS = 2000
  private static readonly PEER_RELEVANCE_WAIT_MS = 5000
  private static readonly PENDING_CANDIDATES_PER_PEER = 64
  private static readonly RENEGOTIATION_STUCK_MS = 8000
  private static readonly SOFT_REFRESH_COOLDOWN_MS = 1000

  private currentDeviceId = 'default'
  private currentStreamQuality: 'high' | 'medium' | 'low' | 'camera' = 'low'
  private currentOutputDeviceId = 'default'
  private noiseSuppression = localStorage.getItem(ULTRA_LOW_LATENCY_STORAGE_KEY) === 'true'
    ? false
    : localStorage.getItem(NOISE_SUPPRESSION_STORAGE_KEY) !== 'false'
  private activeGraphSignature: string | null = null

  private inputVolume = 100
  private outputVolume = 100
  private isDeafened = false

  private processedContext: AudioContext | null = null
  private processedSource: MediaStreamAudioSourceNode | null = null
  private micRumbleFilters: BiquadFilterNode[] = []
  private micOutputTap: AudioNode | null = null
  private micTestCapturePromises = new WeakMap<AudioContext, Promise<void>>()
  private micTestRun: Promise<MicTestClip> | null = null
  private micTestBuffer: AudioBuffer | null = null
  private micTestContext: AudioContext | null = null
  private micTestGain: GainNode | null = null
  private micTestSource: AudioBufferSourceNode | null = null
  private micTestPlaying = false
  private micTestOffset = 0
  private micTestStartedAt = 0
  private micTestGeneration = 0
  private micTestEndedListener: (() => void) | null = null
  private readonly peerConnectStartedAt = new Map<string, number>()
  private inputGainNode: GainNode | null = null
  private manualGateNode: AudioWorkletNode | null = null
  private audioProcessorError: string | null = null
  private calibratedPreGainNode: GainNode | null = null
  private micNode: AudioWorkletNode | null = null
  private micNodeReady = false
  private readonly micLevelSeeds = new Map<string, Record<string, number>>()
  private micEngineError: string | null = null
  private lastMicCaptureError: string | null = null
  private lastReportedMicError: string | null = null
  private vadWorker: Worker | null = null
  private webRtcVadSidecar: WebRtcVadSidecar | null = null
  private vadProbabilityHandler: ((data: {
    probability: number
    sequence?: number
    endFrameId?: number
    windowRms?: number
  }) => void) | null = null
  private vadWorkerInitPromise: Promise<void> | null = null
  private vadEpoch = 0
  private voiceProbeCollector: ((probability: number, windowRms: number) => void) | null = null

  private calibratedVadThreshold = DEFAULT_SILERO_THRESHOLD
  private calibratedNoiseFloor = 0.003
  private calibratedPreGainDb = 0
  private readonly RAW_MIC_BOOST = 1.7
  private calibratedVadTrackerSeed = DEFAULT_VAD_TRACKER_SEED
  private hasVoiceCalibration = false
  private calibrationDeviceId = 'default'
  private vadWorkerReady = false
  private calibrationInProgress = false
  private calibrationSuppressesSpeaking = false
  private localSpeakingState = false
  private thresholdMode = localStorage.getItem('zabor_threshold_mode') || 'auto'
  private manualThresholdValue = this.normalizeManualThreshold(parseFloat(localStorage.getItem('zabor_manual_threshold_value') || '-42'))
  private smartModel: SmartNoiseModel = localStorage.getItem(SMART_MODEL_STORAGE_KEY) === 'deepfilter'
    ? 'deepfilter'
    : 'rnnoise'
  private suppressionStrengthDb = this.normalizeSuppressionStrength(
    parseFloat(localStorage.getItem(SUPPRESSION_STRENGTH_STORAGE_KEY) || String(DEEPFILTER_SMART_DEFAULT_ATTEN))
  )
  private speechAnalyzerEnabled = localStorage.getItem(SPEECH_ANALYZER_STORAGE_KEY) !== 'false'
  private echoCancellationEnabled = localStorage.getItem(ECHO_CANCELLATION_STORAGE_KEY) === 'true'
  private calibrationForcesAnalyzer = false
  private activeStartPromise: Promise<boolean> | null = null

  private backgroundContext: AudioContext | null = null
  private backgroundSource: MediaStreamAudioSourceNode | null = null
  private backgroundAnalyser: AnalyserNode | null = null
  private backgroundMeterGain: GainNode | null = null
  private micMeterInterval: NodeJS.Timeout | null = null
  private micLevelDb = -100
  private micLevelListeners = new Set<(db: number) => void>()

  private rawAnalyserNode: AnalyserNode | null = null
  private silenceMonitorInterval: NodeJS.Timeout | null = null
  private silenceCounterMs = 0
  private isSilenceWarningActive = false
  private speakingIntervals: Map<string, SpeakingEntry> = new Map()

  private outputMixContext: AudioContext | null = null
  private outputPeakGuard: WaveShaperNode | null = null
  private outputBusGain: GainNode | null = null
  private ultraOutputContext: AudioContext | null = null
  private ultraOutputPeakGuard: WaveShaperNode | null = null
  private ultraOutputBusGain: GainNode | null = null
  private mixAudioElement: HTMLAudioElement | null = null
  private audioElements: Map<string, HTMLAudioElement> = new Map()
  private streamAudioElements: Map<string, HTMLAudioElement> = new Map()
  private userGainNodes: Map<string, GainNode> = new Map()
  private userLimiterNodes: Map<string, DynamicsCompressorNode> = new Map()
  private userPannerNodes: Map<string, StereoPannerNode> = new Map()
  private voiceSeatOrder: string[] = []
  private streamLimiterNodes: Map<string, DynamicsCompressorNode> = new Map()
  private userSourceNodes: Map<string, MediaStreamAudioSourceNode> = new Map()
  private ultraJitterNodes: Map<string, AudioWorkletNode> = new Map()
  private ultraJitterGains: Map<string, GainNode> = new Map()
  private ultraDecoders: Map<string, WebCodecsAudioDecoder> = new Map()
  private ultraReorderBuffers: Map<string, UltraEncodedFrameMessage[]> = new Map()
  private ultraLastDecodedTs: Map<string, number> = new Map()
  private ultraCustomUsers: Set<string> = new Set()
  private ultraCustomUnderruns: Map<string, number> = new Map()
  private ultraCustomBufferMs: Map<string, number> = new Map()
  private ultraCustomTargetMs: Map<string, number> = new Map()
  private ultraCustomSpeaking: Map<string, { lastSoundAt: number; speaking: boolean }> = new Map()
  private ultraCustomGotFrame: Set<string> = new Set()
  private ultraCustomHandedOver: Set<string> = new Set()
  private ultraCustomLastAudioAt: Map<string, number> = new Map()
  private ultraCustomFailCount: Map<string, number> = new Map()
  private ultraCustomFailed: Set<string> = new Set()
  private ultraHiResends: Map<string, number> = new Map()
  private ultraCustomEngaging: Set<string> = new Set()
  private ultraDataChannels: Map<string, RTCDataChannel> = new Map()
  public allowRemoteControl = false
  private rcDataChannels: Map<string, RTCDataChannel> = new Map()
  private activeRemoteViewerId: string | null = null
  public controllingStreamerId: string | null = null
  private hostFailSafeTimer: NodeJS.Timeout | null = null
  private lastHostFailSafeRefresh = 0
  private hostIdleTimer: NodeJS.Timeout | null = null
  private isHostActive = false
  private cleanupHostListeners: (() => void) | null = null
  private cachedScreenResolution: { width: number; height: number; x: number; y: number } | null = null
  private ultraSendTargets: Set<string> = new Set()
  private ultraSendEncoder: WebCodecsAudioEncoder | null = null
  private ultraSendReader: ReadableStreamDefaultReader<WebCodecsAudioData> | null = null
  private ultraSendClonedTrack: MediaStreamTrack | null = null
  private ultraSendTrackId: string | null = null
  private ultraSendGeneration = 0
  private ultraSendSeq = 0
  private ultraSendFrameCount = 0
  private ultraSentOk = 0
  private ultraSendStarting = false
  private ultraSendUnsupported = false
  private ultraSendStartFailures = 0
  private ultraSendLastError = ''
  private ultraRcvStats: Map<string, { msgs: number; str: number; bin: number; blob: number; view: number; sml: number; other: number }> = new Map()
  private ultraJitterModuleContext: AudioContext | null = null
  private ultraJitterLoadingContext: AudioContext | null = null
  private ultraJitterModulePromise: Promise<void> | null = null
  private pendingSettingsUpdate: { deviceId: string; useNS: boolean } | null = null
  private settingsUpdateTimer: NodeJS.Timeout | null = null
  private settingsWaiters: Array<{ resolve: () => void; reject: (err: any) => void }> = []
  private activeSettingsPromise: Promise<void> | null = null
  private isFlushingSettings = false
  private defaultInputFingerprint: string | null = null
  private defaultOutputFingerprint: string | null = null
  private deviceChangePromise: Promise<AudioDeviceChangeResult> | null = null

  private readonly config: RTCConfiguration = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun.cloudflare.com:3478' }
    ],
    bundlePolicy: 'max-bundle',
    iceCandidatePoolSize: 4
  }
  private static readonly PC_CONSTRAINTS = { optional: [{ googDscp: true }] }

  private turnServers: RTCIceServer[] = []
  private ownStunServers: RTCIceServer[] = []
  private relayOnlyIce = localStorage.getItem(RELAY_ONLY_STORAGE_KEY) === 'true'
  private ipPolicyReconciled = false
  private ultraLowLatency = localStorage.getItem(ULTRA_LOW_LATENCY_STORAGE_KEY) === 'true'
  private relayWarningShownAt = 0
  private turnExpiresAt = 0
  private turnTtlMs = 0
  private turnUserId: string | null = null
  private turnFetch: Promise<void> | null = null
  private turnRetryAfter = 0

  private static readonly TURN_REFRESH_MARGIN_MS = 60 * 60 * 1000
  private static readonly TURN_MIN_REFRESH_MARGIN_MS = 30_000
  private static readonly TURN_RETRY_COOLDOWN_MS = 30_000
  private static readonly FALLBACK_STUN_URL = 'stun:stun.cloudflare.com:3478'

  private deriveStunServers(servers: RTCIceServer[]): RTCIceServer[] {
    const byHost = new Map<string, string>()
    for (const server of servers) {
      const urls = Array.isArray(server.urls) ? server.urls : [server.urls]
      for (const url of urls) {
        if (typeof url !== 'string') continue
        const match = url.match(/^turn:([^?]+?)(?:\?transport=(\w+))?$/i)
        if (!match) continue
        const transport = match[2]?.toLowerCase()
        if (transport && transport !== 'udp') continue
        const host = match[1].replace(/:\d+$/, '')
        if (!byHost.has(host)) byHost.set(host, `stun:${match[1]}`)
      }
    }
    return [...byHost.values()].map(urls => ({ urls }))
  }

  private turnRefreshMargin(): number {
    if (this.turnTtlMs <= 0) return WebRTCManager.TURN_REFRESH_MARGIN_MS
    return Math.min(
      WebRTCManager.TURN_REFRESH_MARGIN_MS,
      Math.max(WebRTCManager.TURN_MIN_REFRESH_MARGIN_MS, this.turnTtlMs / 2)
    )
  }

  private async ensureIceServers(): Promise<void> {
    const userId = useAppStore.getState().currentUser?.id ?? null
    const sameUser = this.turnServers.length > 0 && this.turnUserId === userId
    const now = Date.now()
    if (sameUser && now < this.turnExpiresAt - this.turnRefreshMargin()) return
    if (sameUser && now < this.turnExpiresAt) {
      void this.refreshIceServers(userId)
      return
    }
    return this.refreshIceServers(userId)
  }

  private refreshIceServers(userId: string | null): Promise<void> {
    if (this.turnFetch) return this.turnFetch
    if (Date.now() < this.turnRetryAfter) return Promise.resolve()

    this.turnFetch = (async () => {
      try {
        const config = await signalRService.fetchIceServers()
        const servers = config?.iceServers?.filter(server => server?.urls?.length) ?? []
        if (servers.length > 0) {
          this.turnServers = servers
          this.ownStunServers = this.deriveStunServers(servers)
          this.turnExpiresAt = config!.expiresAtUnixMs
          this.turnTtlMs = config!.ttlSeconds > 0 ? config!.ttlSeconds * 1000 : 0
          this.turnUserId = userId
          this.turnRetryAfter = 0
        } else {
          this.turnRetryAfter = Date.now() + WebRTCManager.TURN_RETRY_COOLDOWN_MS
        }
      } catch {
        this.turnRetryAfter = Date.now() + WebRTCManager.TURN_RETRY_COOLDOWN_MS
      } finally {
        this.turnFetch = null
      }
    })()
    return this.turnFetch
  }

  private rtcConfig(): RTCConfiguration {
    if (this.relayOnlyIce) {
      if (this.turnServers.length === 0) this.warnRelayUnavailable()
      return {
        ...this.config,
        iceServers: [...this.turnServers],
        iceTransportPolicy: 'relay',
        iceCandidatePoolSize: 0
      }
    }
    if (this.turnServers.length === 0) return this.config
    if (this.ownStunServers.length === 0) {
      return { ...this.config, iceServers: [...(this.config.iceServers ?? []), ...this.turnServers] }
    }
    return {
      ...this.config,
      iceServers: [
        ...this.ownStunServers,
        { urls: WebRTCManager.FALLBACK_STUN_URL },
        ...this.turnServers
      ]
    }
  }

  private warnRelayUnavailable() {
    console.error('[WebRTC] relay-only mode is enabled but no TURN server is available, direct candidates stay disabled')
    if (Date.now() - this.relayWarningShownAt < 30_000) return
    this.relayWarningShownAt = Date.now()
    const message = i18n.t(
      'toasts.relayUnavailable',
      'скрытие IP включено, но сервер ретрансляции недоступен — соединение не будет установлено.'
    )
    useAppStore.getState().setSystemToast(message)
    setTimeout(() => {
      const store = useAppStore.getState()
      if (store.systemToast === message) store.setSystemToast(null)
    }, 6000)
  }

  public isRelayOnlyIce(): boolean {
    return this.relayOnlyIce
  }

  public setRelayOnlyIce(enabled: boolean) {
    if (this.relayOnlyIce === enabled) return
    this.relayOnlyIce = enabled
    localStorage.setItem(RELAY_ONLY_STORAGE_KEY, enabled ? 'true' : 'false')
    void window.windowControls?.setWebrtcRelayOnly(enabled)
    if (enabled) void this.ensureIceServers()
  }

  public isUltraLowLatency(): boolean {
    return this.ultraLowLatency
  }

  public setUltraLowLatency(enabled: boolean) {
    if (this.ultraLowLatency === enabled) return
    this.ultraLowLatency = enabled
    localStorage.setItem(ULTRA_LOW_LATENCY_STORAGE_KEY, enabled ? 'true' : 'false')

    if (enabled) {
      this.terminateVadWorker()
      this.ultraSendUnsupported = false
      this.ultraSendStartFailures = 0
      this.ultraSendLastError = ''
    } else {
      this.warmUpSmartNoiseSuppression()
    }

    if (this.localStream || this.rawStream) {
      void this.updateSettings(this.currentDeviceId, this.noiseSuppression)
    }

    this.ultraFrameMs.clear()
    this.ultraFrameCleanTicks.clear()
    this.ultraFrameLastSwitchAt.clear()
    this.ultraFrameLossTicks.clear()
    this.lastInboundLoss.clear()
    this.lastInboundReceived.clear()
    this.ultraJitterTargetMs.clear()
    this.ultraRttMs.clear()
    this.ultraConcealRate.clear()
    this.ultraConcealBurstMs.clear()
    this.ultraCustomFailed.clear()
    this.ultraCustomFailCount.clear()
    this.ultraCustomLastAudioAt.clear()
    this.ultraHiResends.clear()

    if (!enabled) {
      this.stopUltraSend()
      this.ultraSendTargets.clear()
      const customUsers = new Set([
        ...this.ultraCustomUsers,
        ...this.ultraDecoders.keys(),
        ...this.ultraJitterNodes.keys(),
        ...this.peerConnections.keys()
      ])
      for (const uid of customUsers) {
        this.teardownUltraCustomPlayout(uid)
      }
      this.ultraCustomHandedOver.clear()
      for (const uid of this.peerConnections.keys()) {
        this.updateRemoteVolume(uid)
      }
      if (this.ultraOutputContext && this.ultraOutputContext.state === 'running') {
        void this.ultraOutputContext.suspend().catch(() => {})
      }
    }

    this.applyPlayoutDelayHints()

    for (const [userId, el] of this.audioElements.entries()) {
      const voiceStream = el.srcObject as MediaStream | null
      const voiceTrack = voiceStream?.getAudioTracks()[0]
      if (voiceStream && voiceTrack) {
        const receiver = this.findVoiceReceiver(userId, voiceTrack.id)
        this.setupVoicePlayout(userId, voiceStream, voiceTrack, receiver)
      }
    }

    for (const [userId, pc] of this.peerConnections.entries()) {
      void this.renegotiatePeer(pc, userId)
    }

    if (enabled && this.canUseUltraCustomPlayout()) {
      for (const [userId, channel] of this.ultraDataChannels.entries()) {
        if (channel.readyState === 'open') {
          try { channel.send('hi'); this.ultraHiResends.set(userId, 1) } catch { }
          this.ensureUltraCustomPlayout(userId)
        }
      }
      for (const [userId, pc] of this.peerConnections.entries()) {
        if (this.allowRemoteControl) {
          this.ensureRemoteControlChannel(pc, userId)
        }
        this.ensureUltraSendChannel(pc, userId)
      }
      this.maybeStartUltraSend()
    }
  }

  private preferredPlayoutDelayHint(): number | null {
    return this.ultraLowLatency ? ULTRA_PLAYOUT_DELAY_HINT_S : null
  }

  private ultraPtimeFor(userId: string): number {
    return this.ultraFrameMs.get(userId) ?? ULTRA_FRAME_MS_FAST
  }

  private isolateReceiverLatency(receiver: RTCRtpReceiver) {
    if (!receiver.track || receiver.track.kind !== 'audio') return
    if ('jitterBufferTarget' in receiver) {
      try { (receiver as any).jitterBufferTarget = null } catch { }
    }
    if ('playoutDelayHint' in receiver) {
      try { (receiver as any).playoutDelayHint = null } catch { }
    }
  }

  private applyReceiverLatency(receiver: RTCRtpReceiver, targetMs?: number) {
    if (!receiver.track || receiver.track.kind !== 'audio') return
    if (!this.ultraLowLatency) {
      this.isolateReceiverLatency(receiver)
      return
    }
    const ms = targetMs ?? ULTRA_PLAYOUT_DELAY_HINT_S * 1000
    const hasTarget = 'jitterBufferTarget' in receiver
    if (hasTarget) {
      try { (receiver as any).jitterBufferTarget = ms } catch { }
    }
    if ('playoutDelayHint' in receiver) {
      try { (receiver as any).playoutDelayHint = hasTarget ? 0 : ms / 1000 } catch { }
    }
  }

  public applyVideoZeroPlayoutDelay(receiver: RTCRtpReceiver, remoteControl = false): void {
    if (!receiver.track || receiver.track.kind !== 'video') return
    if ('playoutDelayHint' in receiver) {
      try {
        if ((receiver as any).playoutDelayHint !== 0) {
          (receiver as any).playoutDelayHint = 0
        }
      } catch { }
    }
    if ('jitterBufferTarget' in receiver) {
      try {
        const target = remoteControl ? WebRTCManager.VIDEO_JITTER_RC_MS : WebRTCManager.VIDEO_JITTER_MIN_MS
        if ((receiver as any).jitterBufferTarget !== target) {
          (receiver as any).jitterBufferTarget = target
        }
      } catch { }
    }
  }

  public enforceVideoZeroPlayoutDelay(userId: string): void {
    const pcs = [this.peerConnections.get(userId), this.sfuSubConnections.get(userId)]
    for (const pc of pcs) {
      if (!pc || pc.connectionState === 'closed') continue
      for (const receiver of pc.getReceivers()) {
        if (receiver.track?.kind === 'video') {
          this.applyVideoZeroPlayoutDelay(receiver, this.controllingStreamerId === userId || this.activeRemoteViewerId === userId)
        }
      }
    }
  }

  private applyPlayoutDelayHints() {
    for (const [userId, pc] of this.peerConnections.entries()) {
      const voiceTrackId = this.userVoiceTrackIds.get(userId)
      try {
        for (const receiver of pc.getReceivers()) {
          if (!receiver.track || receiver.track.kind !== 'audio') continue
          if (voiceTrackId && receiver.track.id === voiceTrackId) {
            this.applyReceiverLatency(receiver, this.ultraJitterTargetMs.get(receiver.track.id))
          } else {
            this.isolateReceiverLatency(receiver)
          }
        }
      } catch { }
    }
  }

  private updateUltraJitterTarget(userId: string, jitterSeconds: number, concealBurst = false) {
    const voiceTrackId = this.userVoiceTrackIds.get(userId)
    if (!voiceTrackId) return
    const pc = this.peerConnections.get(userId)
    if (!pc) return
    const receiver = pc.getReceivers().find(r => r.track && r.track.kind === 'audio' && r.track.id === voiceTrackId)
    if (!receiver) return

    const measuredMs = Math.max(0, jitterSeconds * 1000)
    const prev = this.ultraJitterTargetMs.get(voiceTrackId) ?? ULTRA_PLAYOUT_DELAY_HINT_S * 1000
    const prevBurst = this.ultraConcealBurstMs.get(voiceTrackId) ?? 0
    const burstExtra = concealBurst
      ? Math.min(ULTRA_CONCEAL_CEILING_MS, Math.max(prevBurst, ULTRA_CONCEAL_BUMP_MS))
      : prevBurst * ULTRA_CONCEAL_DECAY
    this.ultraConcealBurstMs.set(voiceTrackId, burstExtra)

    const jitterWanted = ULTRA_JITTER_HEADROOM_MS + measuredMs * ULTRA_JITTER_FACTOR
    const wanted = Math.max(
      ULTRA_JITTER_MIN_MS,
      Math.min(ULTRA_JITTER_MAX_MS, jitterWanted + burstExtra)
    )
    const alpha = wanted > prev ? ULTRA_JITTER_ATTACK : ULTRA_JITTER_RELEASE
    const next = prev + (wanted - prev) * alpha
    this.ultraJitterTargetMs.set(voiceTrackId, next)
    this.applyReceiverLatency(receiver, next)
  }

  private maybeAdaptUltraFrame(userId: string, pc: RTCPeerConnection, packetsLost: number, packetsReceived: number, rttMs: number) {
    const prevLost = this.lastInboundLoss.get(userId) ?? packetsLost
    const prevReceived = this.lastInboundReceived.get(userId) ?? packetsReceived
    this.lastInboundLoss.set(userId, packetsLost)
    this.lastInboundReceived.set(userId, packetsReceived)

    const deltaLost = Math.max(0, packetsLost - prevLost)
    const deltaReceived = Math.max(0, packetsReceived - prevReceived)
    const totalDelta = deltaLost + deltaReceived
    const lossRatio = totalDelta > 0 ? deltaLost / totalDelta : 0

    const current = this.ultraFrameMs.get(userId) ?? ULTRA_FRAME_MS_FAST
    const now = performance.now()
    const lastSwitch = this.ultraFrameLastSwitchAt.get(userId) ?? 0
    const canSwitch = now - lastSwitch > ULTRA_FRAME_MIN_SWITCH_MS

    const lossy = lossRatio > ULTRA_FRAME_DOWNGRADE_LOSS
    if (lossy) {
      this.ultraFrameCleanTicks.set(userId, 0)
      const lossTicks = (this.ultraFrameLossTicks.get(userId) ?? 0) + 1
      this.ultraFrameLossTicks.set(userId, lossTicks)
      if (current !== ULTRA_FRAME_MS_SAFE && lossTicks >= ULTRA_FRAME_DOWNGRADE_TICKS && canSwitch) {
        this.ultraFrameMs.set(userId, ULTRA_FRAME_MS_SAFE)
        this.ultraFrameLastSwitchAt.set(userId, now)
        void this.renegotiatePeer(pc, userId)
      }
      return
    }

    this.ultraFrameLossTicks.set(userId, 0)
    const cleanTicks = (this.ultraFrameCleanTicks.get(userId) ?? 0) + 1
    this.ultraFrameCleanTicks.set(userId, cleanTicks)
    if (current !== ULTRA_FRAME_MS_FAST && cleanTicks >= ULTRA_FRAME_CLEAN_TICKS && canSwitch) {
      this.ultraFrameMs.set(userId, ULTRA_FRAME_MS_FAST)
      this.ultraFrameLastSwitchAt.set(userId, now)
      void this.renegotiatePeer(pc, userId)
    }
  }

  private getSmartGateParams(gainFactor: number) {
    return {
      thresholdMode: this.thresholdMode,
      manualThresholdValue: this.manualThresholdValue,
      vadThreshold: this.calibratedVadThreshold,
      vadTrackerSeed: this.calibratedVadTrackerSeed,
      vadFixedThreshold: VAD_CALIBRATION_ENABLED ? 0 : FIXED_SILERO_THRESHOLD,
      attenuationLimit: this.suppressionStrengthDb,
      adaptiveAttenuation: false,
      postFilterBeta: this.postFilterBetaForStrength(this.suppressionStrengthDb),
      noiseFloor: this.calibratedNoiseFloor,
      gainFactor,
      downstreamGain: this.effectiveInputGain()
    }
  }

  private postFilterBetaForStrength(strengthDb: number): number {
    const span = MAX_SUPPRESSION_STRENGTH_DB - MIN_SUPPRESSION_STRENGTH_DB
    const normalized = span > 0
      ? Math.max(0, Math.min(1, (strengthDb - MIN_SUPPRESSION_STRENGTH_DB) / span))
      : 0
    const shaped = normalized * normalized
    return DEEPFILTER_POST_FILTER_BETA +
      (DEEPFILTER_MAX_POST_FILTER_BETA - DEEPFILTER_POST_FILTER_BETA) * shaped
  }

  private getManualGateParams() {
    return { manualThresholdValue: this.manualThresholdValue }
  }

  private inputVolumeToGain(volume: number): number {
    const normalized = Math.max(0, Math.min(200, Number.isFinite(volume) ? volume : 100))
    return normalized / 100
  }

  private effectiveInputGain(): number {
    const base = this.inputVolumeToGain(this.inputVolume)
    return this.noiseSuppression ? base : base * this.RAW_MIC_BOOST
  }

  private normalizeManualThreshold(value: number): number {
    if (value >= 0) return -42
    return Math.max(-60, Math.min(-12, Number.isFinite(value) ? value : -42))
  }

  private normalizeSuppressionStrength(value: number): number {
    if (!Number.isFinite(value)) return DEEPFILTER_SMART_DEFAULT_ATTEN
    return Math.round(Math.max(MIN_SUPPRESSION_STRENGTH_DB, Math.min(MAX_SUPPRESSION_STRENGTH_DB, value)))
  }

  private isSmartMode(): boolean {
    return this.noiseSuppression && this.thresholdMode === 'auto'
  }

  private usesSmartWorklet(): boolean {
    if (this.noiseSuppression) {
      return true
    }
    return this.analyzerFeedsWorklet()
  }

  private micGraphSignature(): string {
    if (this.ultraLowLatency) {
      return 'ultra-low-latency'
    }
    if (this.noiseSuppression) {
      return this.thresholdMode === 'auto' ? `smart-${this.smartModel}` : 'manual-gate'
    }
    return this.analyzerFeedsWorklet() ? 'analyzer-only' : 'raw'
  }

  private hasSpeakingWorklet(): boolean {
    return Boolean(this.micNode || this.manualGateNode)
  }

  private calibrationStorageKey(deviceId: string): string {
    return `zabor_mic_calibration_v${WebRTCManager.CALIBRATION_SCHEMA_VERSION}:${encodeURIComponent(deviceId || 'default')}`
  }

  private migrateCalibrationStorage(): void {
    try {
      const currentVersion = Number(localStorage.getItem(WebRTCManager.CALIBRATION_SCHEMA_KEY)) || 0
      if (currentVersion === WebRTCManager.CALIBRATION_SCHEMA_VERSION) return

      for (let i = localStorage.length - 1; i >= 0; i--) {
        const key = localStorage.key(i)
        if (key?.startsWith('zabor_mic_calibration_v') ||
          key === 'zabor_calibrated_noise_floor' || key === 'zabor_calibrated_attenuation') {
          localStorage.removeItem(key)
        }
      }
      localStorage.setItem(WebRTCManager.CALIBRATION_SCHEMA_KEY, String(WebRTCManager.CALIBRATION_SCHEMA_VERSION))
    } catch (error) {
      console.warn('[WebRTC] Failed to migrate microphone calibration profiles', error)
    }
  }

  private readEnvironmentProfiles(deviceId = this.calibrationDeviceId): StoredEnvironmentProfile[] {
    try {
      const raw = localStorage.getItem(this.calibrationStorageKey(deviceId))
      const parsed = raw ? JSON.parse(raw) : null
      if (!Array.isArray(parsed?.profiles)) return []
      const oldestAllowedTimestamp = Date.now() - WebRTCManager.CALIBRATION_PROFILE_MAX_AGE_MS
      return parsed.profiles.filter((profile: StoredEnvironmentProfile) =>
        profile?.version === WebRTCManager.CALIBRATION_SCHEMA_VERSION &&
        Number.isFinite(profile.timestamp) && profile.timestamp >= oldestAllowedTimestamp &&
        Number.isFinite(profile.noiseFloor) && Number.isFinite(profile.attenuationLimit) &&
        Number.isFinite(profile.zeroCrossingRate) && Number.isFinite(profile.spectralTilt)
      )
    } catch {
      return []
    }
  }

  private environmentDistance(
    profile: StoredEnvironmentProfile,
    noiseFloor: number,
    lowNoise: number,
    peakNoise: number,
    zeroCrossingRate: number,
    spectralTilt: number
  ): number {
    const db = (value: number) => 20 * Math.log10(Math.max(1e-5, value))
    const profileSpread = profile.peakNoise / Math.max(1e-5, profile.lowNoise)
    const measuredSpread = peakNoise / Math.max(1e-5, lowNoise)
    return Math.abs(db(profile.noiseFloor) - db(noiseFloor)) +
      Math.abs(Math.log2(Math.max(0.25, profileSpread) / Math.max(0.25, measuredSpread))) * 2 +
      Math.abs(profile.zeroCrossingRate - zeroCrossingRate) * 20 +
      Math.abs(Math.log2(Math.max(0.05, profile.spectralTilt) / Math.max(0.05, spectralTilt))) * 2
  }

  private calculateAttenuationFromRoom(
    noiseFloor: number,
    lowNoise: number,
    peakNoise: number,
    noiseVadHigh = 0
  ): {
    attenuationLimit: number, requiredDb: number, speechLikeBonusDb: number,
    transientReliefDb: number, demandDb: number, shapedDb: number, roomDbfs: number
  } {
    const clamp01 = (value: number) => Math.max(0, Math.min(1, value))
    const roomDbfs = Math.max(
      20 * Math.log10(Math.max(1e-5, noiseFloor)),
      20 * Math.log10(Math.max(1e-5, peakNoise)) - 6
    )
    const measuredSnrDb = ASSUMED_SPEECH_LEVEL_DBFS - roomDbfs
    const requiredDb = TARGET_SPEECH_TO_NOISE_DB - measuredSnrDb

    const speechLikeBonusDb = 5 * clamp01((noiseVadHigh - 0.25) / 0.45)
    const stationarity = peakNoise / Math.max(1e-5, lowNoise)
    const transientReliefDb = clamp01((stationarity - 6) / 6)

    const demandDb = requiredDb + speechLikeBonusDb
    const shapedDb = demandDb <= SUPPRESSION_SOFT_KNEE_DB
      ? demandDb
      : SUPPRESSION_SOFT_KNEE_DB + (demandDb - SUPPRESSION_SOFT_KNEE_DB) * SUPPRESSION_ABOVE_KNEE_SLOPE

    const attenuationLimit = Math.max(DEEPFILTER_MIN_ATTEN, Math.min(
      SUPPRESSION_SOFT_KNEE_DB,
      Math.round(shapedDb - transientReliefDb)
    ))
    return { attenuationLimit, requiredDb, speechLikeBonusDb, transientReliefDb, demandDb, shapedDb, roomDbfs }
  }

  private loadCalibration(deviceId: string, deviceLabel = '') {
    this.migrateCalibrationStorage()
    const normalizedDeviceId = deviceId && deviceId !== 'default'
      ? deviceId
      : `default:${deviceLabel.trim().toLowerCase() || 'unknown'}`
    this.calibrationDeviceId = normalizedDeviceId
    this.calibratedVadThreshold = VAD_CALIBRATION_ENABLED ? DEFAULT_SILERO_THRESHOLD : FIXED_SILERO_THRESHOLD
    this.hasVoiceCalibration = false

    if (!VAD_CALIBRATION_ENABLED) {
      this.updateThresholds()
      return
    }

    try {
      const raw = localStorage.getItem(this.calibrationStorageKey(normalizedDeviceId))
      const profile = raw ? JSON.parse(raw) as StoredVoiceProfile : null
      if (
        profile?.version === WebRTCManager.CALIBRATION_SCHEMA_VERSION &&
        Number.isFinite(profile.vadThreshold)
      ) {
        this.calibratedVadThreshold = Number.isFinite(profile.voiceLow) && profile.voiceLow > 0
          ? vadThresholdFromVoiceLow(profile.voiceLow)
          : Math.max(VAD_CALIBRATION_MIN_THRESHOLD, Math.min(VAD_CALIBRATION_MAX_THRESHOLD, profile.vadThreshold))
        this.hasVoiceCalibration = true
      }
    } catch { }
    this.updateThresholds()
  }

  public resetMicCalibration() {
    this.calibratedVadThreshold = VAD_CALIBRATION_ENABLED ? DEFAULT_SILERO_THRESHOLD : FIXED_SILERO_THRESHOLD
    this.hasVoiceCalibration = false
    try {
      for (let i = localStorage.length - 1; i >= 0; i--) {
        const key = localStorage.key(i)
        if (key?.startsWith('zabor_mic_calibration_v') || key === 'zabor_calibrated_noise_floor' || key === 'zabor_calibrated_attenuation') {
          localStorage.removeItem(key)
        }
      }
      localStorage.setItem(WebRTCManager.CALIBRATION_SCHEMA_KEY, String(WebRTCManager.CALIBRATION_SCHEMA_VERSION))
    } catch { }
    this.updateThresholds()
  }

  private async loadDeepFilterAsset(rel: string): Promise<ArrayBuffer | null> {
    return getDeepFilterAsset(rel)
  }

  private analyzerFeedsWorklet(): boolean {
    return this.speechAnalyzerEnabled || this.calibrationForcesAnalyzer
  }

  private levelSeedKeys(): { preEngine: string; alc: string } {
    const device = this.currentDeviceId || 'default'
    return {
      preEngine: `pre:${device}`,
      alc: `alc:${device}:${this.noiseSuppression ? this.smartModel : 'raw'}`
    }
  }

  private mergeLevelSeed(key: string, state: Record<string, unknown>, fields: readonly string[]): void {
    const seed = { ...(this.micLevelSeeds.get(key) ?? {}) }
    let changed = false
    for (const field of fields) {
      const value = Number(state[field])
      if (Number.isFinite(value) && value > 0) {
        seed[field] = value
        changed = true
      }
    }
    if (changed) this.micLevelSeeds.set(key, seed)
  }

  private storeLevelSeed(state: Record<string, unknown>, keys: { preEngine: string; alc: string }): void {
    this.mergeLevelSeed(keys.preEngine, state, PRE_ENGINE_SEED_FIELDS)
    this.mergeLevelSeed(keys.alc, state, ALC_SEED_FIELDS)
  }

  private buildLevelSeed(keys: { preEngine: string; alc: string }): Record<string, number> | null {
    const merged = {
      ...(this.micLevelSeeds.get(keys.preEngine) ?? {}),
      ...(this.micLevelSeeds.get(keys.alc) ?? {})
    }
    return Object.keys(merged).length > 0 ? merged : null
  }

  private bindVadProbabilityHandler(micNode: AudioWorkletNode): void {
    this.vadProbabilityHandler = (data) => {
      if (this.micNode !== micNode) return
      micNode.port.postMessage({
        type: 'setSileroVadProbability',
        probability: data.probability,
        sequence: data.sequence,
        endFrameId: data.endFrameId,
        windowRms: data.windowRms
      })
    }
  }

  private applyAnalyzerToWorklet(): void {
    const micNode = this.micNode
    if (!micNode) return
    const me = useAppStore.getState().currentUser
    if (me) {
      useAppStore.getState().setSpeakingStatus(me.id, false)
      signalRService.setSpeakingState(false)
    }
    this.localSpeakingState = false
    if (!this.analyzerFeedsWorklet()) {
      micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
      this.vadProbabilityHandler = null
      return
    }
    this.bindVadProbabilityHandler(micNode)
    if (this.vadWorkerReady) {
      this.vadWorker?.postMessage({ type: 'reset' })
      micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: true })
      return
    }
    void this.ensureVadWorker()
      .then(() => {
        if (this.micNode !== micNode || !this.analyzerFeedsWorklet()) return
        this.vadWorker?.postMessage({ type: 'reset' })
        micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: true })
      })
      .catch(error => {
        if (this.micNode !== micNode) return
        this.audioProcessorError = `Silero VAD failed: ${error instanceof Error ? error.message : String(error)}`
        micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
        console.warn('[WebRTC] Silero VAD is unavailable; using voicing-based speech detection:', error)
      })
  }

  private ensureVadWorker(): Promise<void> {
    if (!this.analyzerFeedsWorklet()) return Promise.resolve()
    if (this.vadWorker && this.vadWorkerReady) return Promise.resolve()
    if (this.vadWorkerInitPromise) return this.vadWorkerInitPromise

    const startup = (async () => {
      const worker = new VadWorker()
      const wasmPath = new URL('./', window.location.href).href
      let resolveReady: (() => void) | null = null
      let rejectReady: ((error: Error) => void) | null = null
      const ready = new Promise<void>((resolve, reject) => {
        resolveReady = resolve
        rejectReady = reject
      })
      ready.catch(() => { })
      const readyTimeout = window.setTimeout(() => {
        rejectReady?.(new Error('Silero VAD initialization timed out'))
      }, VAD_WORKER_READY_TIMEOUT_MS)

      worker.onmessage = (event) => {
        const data = event.data
        if (data.type === 'probability') {
          this.vadWorkerReady = true
          const epoch = Number(data.epoch)
          if (Number.isFinite(epoch) && epoch !== this.vadEpoch) return
          this.voiceProbeCollector?.(Number(data.probability), Number(data.windowRms))
          this.vadProbabilityHandler?.(data)
        } else if (data.type === 'ready') {
          this.vadWorkerReady = true
          window.clearTimeout(readyTimeout)
          resolveReady?.()
          resolveReady = null
          rejectReady = null
          console.info('[WebRTC] Silero VAD Worker is ready', data.io ?? '')
        } else if (data.type === 'error') {
          console.error('[WebRTC] Silero VAD Worker error:', data.error)
          if (data.phase === 'initialization') {
            window.clearTimeout(readyTimeout)
            rejectReady?.(new Error(String(data.error)))
          }
        }
      }
      this.vadWorker = worker

      const model = await withTimeout(
        getSileroModel(),
        SILERO_MODEL_LOAD_TIMEOUT_MS,
        'Silero VAD model load timed out'
      )
      worker.postMessage({ type: 'init', model, wasmPath }, [model.buffer])
      await ready
    })()

    this.vadWorkerInitPromise = startup.then(() => {
      this.vadWorkerInitPromise = null
    }).catch(error => {
      this.terminateVadWorker()
      this.vadWorkerInitPromise = null
      throw error
    })
    return this.vadWorkerInitPromise
  }

  private terminateVadWorker() {
    this.vadProbabilityHandler = null
    this.vadWorkerReady = false
    this.vadWorkerInitPromise = null
    if (this.vadWorker) {
      try { this.vadWorker.terminate() } catch { }
      this.vadWorker = null
    }
  }

  public warmUpSmartNoiseSuppression(enabled = this.noiseSuppression): void {
    if (this.noiseSuppression && this.thresholdMode !== 'auto') return
    const needsAnalyzer = this.analyzerFeedsWorklet()
    if (!enabled && !needsAnalyzer) return
    void preloadNoiseAssets(enabled ? this.smartModel : 'analyzer')
      .then(() => this.ensureVadWorker())
      .catch(error => console.warn('[WebRTC] Smart noise suppression warm-up failed:', error))
  }

  public warmUpConnectivity(): void {
    void this.reconcileIpPolicyWithMain()
    const startedAt = performance.now()
    void this.ensureIceServers()
      .then(() => {
        console.log(`[WebRTC] ICE servers warmed up in ${Math.round(performance.now() - startedAt)}ms ` +
          `(${this.turnServers.length} entries)`)
      })
      .catch(error => console.warn('[WebRTC] ICE server warm-up failed:', error))
  }

  private async reconcileIpPolicyWithMain(): Promise<void> {
    if (this.ipPolicyReconciled) return
    this.ipPolicyReconciled = true
    try {
      const mainValue = await window.windowControls?.getWebrtcRelayOnly()
      if (mainValue !== undefined && mainValue !== this.relayOnlyIce) {
        await window.windowControls?.setWebrtcRelayOnly(this.relayOnlyIce)
      }
    } catch {}
  }

  private createPeakGuard(ctx: AudioContext, oversample: OverSampleType = '4x'): WaveShaperNode {
    const peakGuard = ctx.createWaveShaper()
    const peakCurve = new Float32Array(65_536)
    const linearLimit = 0.98
    const outputLimit = 0.995
    const softRange = 1 - linearLimit
    const normalization = 1 - Math.exp(-3)
    for (let i = 0; i < peakCurve.length; i++) {
      const sample = (i / (peakCurve.length - 1)) * 2 - 1
      const magnitude = Math.abs(sample)
      peakCurve[i] = magnitude <= linearLimit
        ? sample
        : Math.sign(sample) * (
          linearLimit +
          (outputLimit - linearLimit) *
          (1 - Math.exp(-3 * ((magnitude - linearLimit) / softRange))) /
          normalization
        )
    }
    peakGuard.curve = peakCurve
    peakGuard.oversample = oversample
    return peakGuard
  }

  private createRumbleGuards(ctx: AudioContext): BiquadFilterNode[] {
    const guards = RUMBLE_GUARD_QS.map(quality => {
      const guard = ctx.createBiquadFilter()
      guard.type = 'highpass'
      guard.frequency.value = RUMBLE_GUARD_HZ
      guard.Q.value = quality
      return guard
    })
    for (let index = 1; index < guards.length; index++) guards[index - 1].connect(guards[index])
    return guards
  }

  public getActiveVadBranch(): 'silero' | 'manual-gate' | 'webrtc-vad' {
    if (this.speechAnalyzerEnabled && !this.isManualGateMode()) {
      return 'silero'
    }
    if (this.isManualGateMode()) {
      return 'manual-gate'
    }
    return 'webrtc-vad'
  }

  private isManualGateMode(): boolean {
    return !this.ultraLowLatency && this.noiseSuppression && this.thresholdMode === 'manual'
  }

  private async updateVadBranch(): Promise<void> {
    try {
      const branch = this.getActiveVadBranch()
      const me = useAppStore.getState().currentUser
      const streamToTap = this.micOutputTap || this.rawStream || this.localStream

      if (branch === 'silero') {
        if (this.webRtcVadSidecar) {
          this.webRtcVadSidecar.stop()
        }
        if (this.micNode) {
          this.applyAnalyzerToWorklet()
        }
      } else if (branch === 'manual-gate') {
        if (this.webRtcVadSidecar) {
          this.webRtcVadSidecar.stop()
        }
        if (!this.calibrationForcesAnalyzer) {
          this.terminateVadWorker()
        }
      } else {
        if (!this.calibrationForcesAnalyzer) {
          this.terminateVadWorker()
        }
        if (this.micNode) {
          this.micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
        }
        if (streamToTap && this.processedContext && this.processedContext.state !== 'closed') {
          if (!this.webRtcVadSidecar) {
            this.webRtcVadSidecar = new WebRtcVadSidecar((isSpeaking) => {
              if (this.getActiveVadBranch() === 'webrtc-vad') {
                this.applyLocalSpeaking(isSpeaking)
              }
            })
          }
          const isMuted = me?.isMuted || me?.isServerMuted || false
          this.webRtcVadSidecar.setMuted(isMuted)
          await this.webRtcVadSidecar.start(this.processedContext, streamToTap)
        }
      }
    } catch (e) {
      console.warn('[WebRTC] updateVadBranch failed gracefully:', e)
    }
  }

  private applyLocalSpeaking(isSpeaking: boolean) {
    if (isSpeaking && this.calibrationSuppressesSpeaking) return
    const store = useAppStore.getState()
    const inActiveSession = Boolean(store.currentChannelId || store.currentCallUser)
    if (!inActiveSession && isSpeaking) return
    if ((store.currentUser?.isMuted || store.currentUser?.isServerMuted) && isSpeaking) return
    if (isSpeaking === this.localSpeakingState) return
    this.localSpeakingState = isSpeaking
    const me = store.currentUser
    if (!me) return
    store.setSpeakingStatus(me.id, isSpeaking)
    signalRService.setSpeakingState(isSpeaking)
  }

  private publishMicLevel(db: number) {
    if (!Number.isFinite(db)) return
    this.micLevelDb = db
    this.micLevelListeners.forEach(listener => listener(db))
  }

  private async createProcessedStream(rawStream: MediaStream): Promise<MediaStream> {
    if (this.ultraLowLatency) return this.createUltraLowLatencyProcessedStream(rawStream)
    if (!this.usesSmartWorklet()) return this.createManualProcessedStream(rawStream)
    return this.createSmartProcessedStream(rawStream, this.smartModel)
  }

  private async createUltraLowLatencyProcessedStream(rawStream: MediaStream): Promise<MediaStream> {
    await this.cleanupProcessedStream()
    this.audioProcessorError = null
    this.micEngineError = null

    // Create context only for UI meter
    const ctx = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' })
    this.processedContext = ctx
    if (ctx.sampleRate !== 48000) {
      console.warn(`[WebRTC] ULL AudioContext sampleRate is ${ctx.sampleRate}, expected 48000`)
    }
    await safeResumeContext(ctx)

    const source = ctx.createMediaStreamSource(rawStream)
    this.processedSource = source

    try {
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 256
      source.connect(analyser)
      this.rawAnalyserNode = analyser
    } catch (error) {
      console.warn('[WebRTC] Could not attach raw analyser:', error)
    }

    const tap = ctx.createGain()
    source.connect(tap)
    this.micOutputTap = tap

    this.localSpeakingState = false

    const rawTrack = rawStream.getAudioTracks()[0]
    if (rawTrack) rawTrack.contentHint = 'speech'

    return rawStream
  }

  private async createManualProcessedStream(rawStream: MediaStream): Promise<MediaStream> {
    await this.cleanupProcessedStream()
    this.audioProcessorError = null

    const ctx = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' })
    this.processedContext = ctx
    if (ctx.sampleRate !== 48000) {
      const detail = `AudioContext runs at ${ctx.sampleRate}Hz, 48000Hz required`
      console.error(`[WebRTC] Audio processing requires 48000Hz, got ${ctx.sampleRate}Hz`)
      this.audioProcessorError = detail
      await ctx.close().catch(() => { })
      this.processedContext = null
      return createSilentAudioStream()
    }
    await safeResumeContext(ctx)

    const destination = ctx.createMediaStreamDestination()
    const track = destination.stream.getAudioTracks()[0]
    if (track) track.contentHint = 'speech'
    const source = ctx.createMediaStreamSource(rawStream)
    this.processedSource = source
    const inputGain = ctx.createGain()
    inputGain.gain.value = this.effectiveInputGain()
    this.inputGainNode = inputGain
    const peakGuard = this.createPeakGuard(ctx)
    this.micOutputTap = peakGuard

    try {
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 256
      source.connect(analyser)
      this.rawAnalyserNode = analyser
    } catch (error) {
      console.warn('[WebRTC] Failed to create raw analyser node:', error)
    }

    const passthrough = () => {
      source.connect(inputGain)
      inputGain.connect(peakGuard)
      peakGuard.connect(destination)
      return destination.stream
    }

    if (!this.noiseSuppression) return passthrough()

    try {
      await ctx.audioWorklet.addModule(manualGateProcessorUrl)
      this.manualGateNode = new AudioWorkletNode(ctx, 'manual-gate-processor', {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1],
        channelCount: 1,
        channelCountMode: 'explicit'
      })
    } catch (error) {
      this.audioProcessorError = `Manual gate worklet failed: ${error instanceof Error ? error.message : String(error)}`
      console.error('[WebRTC] Failed to create the manual gate:', error)
      return passthrough()
    }

    const gateNode = this.manualGateNode
    gateNode.port.onmessage = (event) => {
      if (event.data.type === 'vad') {
        if (this.getActiveVadBranch() === 'manual-gate') {
          this.applyLocalSpeaking(Boolean(event.data.isSpeaking))
        }
      } else if (event.data.type === 'micLevelDb') {
        this.publishMicLevel(Number(event.data.db))
      }
    }

    const rumbleGuards = this.createRumbleGuards(ctx)
    this.micRumbleFilters = rumbleGuards

    const store = useAppStore.getState()
    const isMuted = Boolean(store.currentUser?.isMuted || store.currentUser?.isServerMuted)
    gateNode.port.postMessage({ type: 'setConfig', isMuted, ...this.getManualGateParams() })

    source.connect(rumbleGuards[0])
    rumbleGuards[rumbleGuards.length - 1].connect(inputGain)
    inputGain.connect(gateNode)
    gateNode.connect(peakGuard)
    peakGuard.connect(destination)
    this.localSpeakingState = false
    return destination.stream
  }

  private async createSmartProcessedStream(
    rawStream: MediaStream,
    model: SmartNoiseModel
  ): Promise<MediaStream> {
    this.micEngineError = null
    this.audioProcessorError = null

    const levelSeedKeys = this.levelSeedKeys()
    const processingEpoch = this.vadEpoch
    const ctx = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' })
    this.processedContext = ctx

    if (ctx.sampleRate !== 48000) {
      const detail = `AudioContext runs at ${ctx.sampleRate}Hz, 48000Hz required`
      console.error(`[WebRTC] Audio processing requires 48000Hz, got ${ctx.sampleRate}Hz`)
      this.micEngineError = detail
      this.audioProcessorError = detail
      await ctx.close().catch(() => { })
      this.processedContext = null
      return createSilentAudioStream()
    }

    await safeResumeContext(ctx)

    const destination = ctx.createMediaStreamDestination()
    const localTrack = destination.stream.getAudioTracks()[0]
    if (localTrack) localTrack.contentHint = 'speech'
    const moduleUrl = model === 'deepfilter' ? micPipelineDeepFilterUrl : micPipelineRnnoiseUrl
    const processorName = model === 'deepfilter' ? 'mic-pipeline-deepfilter' : 'mic-pipeline-rnnoise'

    try {
      const rustVoicingModule = await getRustVoicingModule()
      if (this.processedContext !== ctx || this.vadEpoch !== processingEpoch || ctx.state === 'closed') throw new DOMException('stale-mic-graph', 'AbortError')
      await ctx.audioWorklet.addModule(moduleUrl)
      if (this.processedContext !== ctx || this.vadEpoch !== processingEpoch || (ctx.state as AudioContextState) === 'closed') throw new DOMException('stale-mic-graph', 'AbortError')
      this.micNode = new AudioWorkletNode(ctx, processorName, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1],
        channelCount: 1,
        channelCountMode: 'explicit',
        channelInterpretation: 'speakers',
        processorOptions: { rustVoicingModule }
      })
      this.micNodeReady = false
      const me = useAppStore.getState().currentUser
      if (me) {
        this.clearVAD(me.id)
      }
    } catch (e) {
      if (this.processedContext !== ctx || e instanceof DOMException && e.name === 'AbortError') {
        if (ctx.state !== 'closed') await ctx.close().catch(() => {})
        throw e
      }
      this.micEngineError = `AudioWorklet module failed: ${e instanceof Error ? e.message : String(e)}`
      console.error(`[WebRTC] Failed to load ${processorName}`, e)
    }

    if (this.micNode) {
      const graphEpoch = this.vadEpoch
      this.micNode.port.onmessage = (event) => {
        if (event.data.type === 'dspRuntime') {
          console.info(`[WebRTC] Mic voicing runtime: ${String(event.data.runtime)}`)
        } else if (event.data.type === 'vad') {
          if (this.getActiveVadBranch() === 'silero' || this.getActiveVadBranch() === 'manual-gate') {
            this.applyLocalSpeaking(Boolean(event.data.isSpeaking))
          }
        } else if (event.data.type === 'audio16k') {
          if (this.vadWorker) {
            const audioFrame = event.data.audio as Float32Array
            this.vadWorker.postMessage({
              type: 'process',
              audioFrame,
              epoch: graphEpoch,
              sequence: event.data.sequence,
              endFrameId: event.data.endFrameId,
              windowRms: event.data.windowRms
            }, [audioFrame.buffer])
          }
        } else if (event.data.type === 'micLevelDb') {
          this.publishMicLevel(Number(event.data.db))
        } else if (event.data.type === 'levelState') {
          this.storeLevelSeed(event.data, levelSeedKeys)
        } else if (event.data.type === 'resetVad') {
          this.vadWorker?.postMessage({ type: 'reset' })
        } else if (event.data.type === 'fetchRequest') {
          const url = event.data.url as string
          const deliver = (buffer: ArrayBuffer | null) => {
            if (buffer) {
              this.micNode?.port.postMessage({ type: 'fetchResponse', url, buffer }, [buffer])
            } else {
              this.micNode?.port.postMessage({ type: 'fetchResponse', url, buffer: null })
            }
          }
          const localRel = url.startsWith(`${DEEPFILTER_LOCAL_BASE}/`)
            ? url.slice(DEEPFILTER_LOCAL_BASE.length + 1)
            : null
          if (localRel && DEEPFILTER_ASSETS.has(localRel)) {
            this.loadDeepFilterAsset(localRel)
              .then(deliver)
              .catch(err => {
                console.error('[WebRTC] DeepFilter asset load failed:', err)
                deliver(null)
              })
          } else {
            console.error('[WebRTC] Worklet asked for a non-bundled asset, refused:', url)
            deliver(null)
          }
        } else if (event.data.type === 'log') {
          console.log('[WebRTC Worklet Log]:', event.data.message)
        } else if (event.data.type === 'ready') {
          this.micNodeReady = true
          this.micEngineError = null
          console.log(`[WebRTC Worklet Log]: ${processorName} is ready.`)
        }
      }

      this.micNode.port.onmessageerror = (event) => {
        console.error('[WebRTC] Mic pipeline worklet could not deserialize a message:', event)
      }

      const initialStore = useAppStore.getState()
      this.micNode.port.postMessage({
        type: 'setConfig',
        noiseSuppression: this.noiseSuppression,
        sileroVadEnabled: false,
        isMuted: Boolean(initialStore.currentUser?.isMuted || initialStore.currentUser?.isServerMuted)
      })
      const levelSeed = this.buildLevelSeed(levelSeedKeys)
      if (levelSeed) {
        this.micNode.port.postMessage({ type: 'setLevelSeed', ...levelSeed })
      }

      const micNodeForAssets = this.micNode
      const sendPayload = (payload: DeepFilterPayload) => {
        micNodeForAssets.port.postMessage({
          type: 'loadWasm',
          assetBase: DEEPFILTER_LOCAL_BASE,
          wasmBytes: payload.wasmBytes,
          modelBytes: payload.modelBytes
        }, [payload.wasmBytes, payload.modelBytes])
      }
      if (this.noiseSuppression) {
        const payload = model === 'deepfilter' ? getDeepFilterPayload() : null
        if (payload) {
          sendPayload(payload)
        } else {
          micNodeForAssets.port.postMessage({ type: 'loadWasm', assetBase: DEEPFILTER_LOCAL_BASE })
          if (model === 'deepfilter') {
            void preloadNoiseAssets('deepfilter')
              .then(() => {
                if (this.micNode !== micNodeForAssets || this.micNodeReady) return
                const late = getDeepFilterPayload()
                if (late) sendPayload(late)
              })
              .catch(error => console.warn('[WebRTC] Late DeepFilter payload delivery failed:', error))
          }
        }
      }

      const micNode = this.micNode
      this.bindVadProbabilityHandler(micNode)

      const attachSileroVad = () => {
        if (this.micNode !== micNode) return
        if (!this.analyzerFeedsWorklet() || !this.vadWorkerReady) {
          micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
          return
        }
        this.vadWorker?.postMessage({ type: 'reset' })
        micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: true })
      }

      if (!this.analyzerFeedsWorklet()) {
        micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
      } else if (this.vadWorkerReady) {
        attachSileroVad()
      } else {
        micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
        void this.ensureVadWorker()
          .then(attachSileroVad)
          .catch(e => {
            if (this.micNode !== micNode) return
            this.vadProbabilityHandler = null
            this.audioProcessorError = `Silero VAD failed: ${e instanceof Error ? e.message : String(e)}`
            micNode.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
            console.warn(`[WebRTC] Silero VAD is unavailable; using voicing-based speech detection: ${e instanceof Error ? e.message : String(e)}`)
          })
      }

      this.localSpeakingState = false
    }

    const source = ctx.createMediaStreamSource(rawStream)
    this.processedSource = source

    const highpass1 = ctx.createBiquadFilter()
    highpass1.type = 'highpass'
    highpass1.frequency.value = 60
    highpass1.Q.value = 0.707

    const rumbleGuards = this.createRumbleGuards(ctx)
    this.micRumbleFilters = rumbleGuards

    const peakGuard = this.createPeakGuard(ctx)
    this.micOutputTap = peakGuard

    const inputGain = ctx.createGain()
    const calibratedPreGain = ctx.createGain()
    calibratedPreGain.gain.value = Math.pow(10, this.calibratedPreGainDb / 20)
    this.calibratedPreGainNode = calibratedPreGain
    const gainFactor = this.inputVolumeToGain(this.inputVolume)

    inputGain.gain.value = this.effectiveInputGain()
    this.inputGainNode = inputGain

    try {
      const rawAnalyser = ctx.createAnalyser()
      rawAnalyser.fftSize = 256
      source.connect(rawAnalyser)
      this.rawAnalyserNode = rawAnalyser
    } catch (e) {
      console.warn('[WebRTC] Failed to create raw analyser node for silence monitoring:', e)
    }

    if (this.micNode) {
      this.micNode.port.postMessage({
        type: 'setCalibratedParams',
        ...this.getSmartGateParams(gainFactor),
      })
      if (this.noiseSuppression) {
        source.connect(rumbleGuards[0])
        rumbleGuards[rumbleGuards.length - 1].connect(this.micNode)
      } else {
        source.connect(this.micNode)
      }
      this.micNode.connect(calibratedPreGain)
      calibratedPreGain.connect(inputGain)
    } else {
      source.connect(inputGain)
      inputGain.gain.value = this.noiseSuppression ? 0 : gainFactor
      inputGain.connect(highpass1)
    }

    if (this.micNode) inputGain.connect(peakGuard)
    else highpass1.connect(peakGuard)
    peakGuard.connect(destination)

    return destination.stream
  }

  private cleanupProcessedStreamSourceOnly() {
    this.stopSilenceMonitor()
    if (this.inputGainNode) {
      try { this.inputGainNode.disconnect() } catch { }
      this.inputGainNode = null
    }
    if (this.micNode) {
      try { this.micNode.disconnect() } catch { }
    }
    if (this.manualGateNode) {
      try { this.manualGateNode.disconnect() } catch { }
    }
    if (this.processedSource) {
      try { this.processedSource.disconnect() } catch { }
      this.processedSource = null
    }
    for (const guard of this.micRumbleFilters) {
      try { guard.disconnect() } catch { }
    }
    this.micRumbleFilters = []
    if (this.micOutputTap) {
      try { this.micOutputTap.disconnect() } catch { }
      this.micOutputTap = null
    }
    if (this.rawAnalyserNode) {
      try { this.rawAnalyserNode.disconnect() } catch { }
      this.rawAnalyserNode = null
    }
  }

  private async cleanupProcessedStream(): Promise<void> {
    this.cleanupProcessedStreamSourceOnly()
    if (this.micNode) {
      try { this.micNode.port.postMessage({ type: 'dispose' }) } catch { }
      try { this.micNode.port.close() } catch { }
      this.micNode = null
    }
    if (this.manualGateNode) {
      try { this.manualGateNode.port.close() } catch { }
      this.manualGateNode = null
    }
    if (this.webRtcVadSidecar) {
      this.webRtcVadSidecar.stop()
      this.webRtcVadSidecar = null
    }
    this.voiceProbeCollector = null
    this.micNodeReady = false
    const ctxToClose = this.processedContext
    this.processedContext = null
    if (ctxToClose && ctxToClose.state !== 'closed') {
      try { await ctxToClose.close() } catch { }
    }
    this.activeGraphSignature = null
    this.vadEpoch++
    this.vadProbabilityHandler = null
    this.vadWorker?.postMessage({ type: 'reset' })
    const me = useAppStore.getState().currentUser
    if (me) {
      this.clearVAD(me.id)
      useAppStore.getState().setSpeakingStatus(me.id, false)
      signalRService.setSpeakingState(false)
    }
    this.localSpeakingState = false
  }

  public setInputVolume(volume: number) {
    this.inputVolume = Math.max(0, Math.min(200, Number.isFinite(volume) ? volume : 100))
    const gainFactor = this.inputVolumeToGain(this.inputVolume)
    const effectiveGain = this.effectiveInputGain()

    if (this.inputGainNode) {
      this.inputGainNode.gain.value = effectiveGain
    }
    if (this.backgroundMeterGain) {
      this.backgroundMeterGain.gain.value = effectiveGain
    }
    if (this.micNode) {
      this.micNode.port.postMessage({
        type: 'setCalibratedParams',
        ...this.getSmartGateParams(gainFactor)
      })
    }
  }

  public setMicThresholdParams(mode: 'auto' | 'manual', manualValue: number) {
    const normalizedThreshold = this.normalizeManualThreshold(manualValue)
    const modeChanged = this.thresholdMode !== mode
    localStorage.setItem('zabor_threshold_mode', mode)
    localStorage.setItem('zabor_manual_threshold_value', normalizedThreshold.toString())
    this.thresholdMode = mode
    this.manualThresholdValue = normalizedThreshold
    this.updateThresholds()
    if (modeChanged) this.warmUpSmartNoiseSuppression()
    if (modeChanged && this.localStream) {
      void this.updateSettings(this.currentDeviceId, this.noiseSuppression)
    } else if (modeChanged) {
      void this.updateVadBranch()
    }
  }

  private updateThresholds() {
    const gainFactor = this.inputVolumeToGain(this.inputVolume)

    if (this.micNode) {
      this.micNode.port.postMessage({
        type: 'setCalibratedParams',
        ...this.getSmartGateParams(gainFactor)
      })
    }
    if (this.manualGateNode) {
      this.manualGateNode.port.postMessage({
        type: 'setCalibratedParams',
        ...this.getManualGateParams()
      })
    }
  }

  public setOutputVolume(volume: number) {
    this.outputVolume = volume
    this.userGainNodes.forEach((_, userId) => this.updateRemoteVolume(userId))
    this.streamGainNodes.forEach((_, userId) => this.updateRemoteStreamVolume(userId))
    if (this.ultraLowLatency) this.audioElements.forEach((_, userId) => this.updateRemoteVolume(userId))
    if (this.micTestGain) this.micTestGain.gain.value = this.micTestVolume()
  }

  public setDeafened(deafened: boolean) {
    this.isDeafened = deafened
    const targetGain = deafened ? 0 : Math.pow(10, PLAYBACK_MAKEUP_GAIN_DB / 20)
    if (this.outputBusGain) {
      if (this.outputMixContext && this.outputMixContext.state === 'running') {
        this.outputBusGain.gain.setTargetAtTime(targetGain, this.outputMixContext.currentTime, 0.015)
      } else {
        this.outputBusGain.gain.value = targetGain
      }
    }
    if (this.ultraOutputBusGain) {
      if (this.ultraOutputContext && this.ultraOutputContext.state === 'running') {
        this.ultraOutputBusGain.gain.setTargetAtTime(targetGain, this.ultraOutputContext.currentTime, 0.015)
      } else {
        this.ultraOutputBusGain.gain.value = targetGain
      }
    }
    if (this.mixAudioElement) {
      this.mixAudioElement.muted = deafened
    }
    if (this.ultraLowLatency) {
      this.audioElements.forEach((el) => {
        try { el.muted = true } catch { }
      })
      this.ultraCustomUsers.forEach(uid => this.updateUltraCustomGain(uid))
    }
  }

  private updateRemoteVolume(userId: string) {
    if (this.ultraCustomUsers.has(userId)) {
      this.updateUltraCustomGain(userId)
    }
    const store = useAppStore.getState()
    const isActive = store.activeStreamId === userId
    const streamGainNode = this.streamGainNodes.get(userId)
    if (streamGainNode) {
      const streamVol = isActive ? (store.streamVolumes[userId] ?? 100) : 0
      const targetStreamGain = Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (streamVol / 100)))
      if (this.outputMixContext && this.outputMixContext.state === 'running') {
        streamGainNode.gain.setTargetAtTime(targetStreamGain, this.outputMixContext.currentTime, 0.015)
      } else {
        streamGainNode.gain.value = targetStreamGain
      }
    }

    const gainNode = this.userGainNodes.get(userId)
    if (gainNode) {
      const vol = store.userVolumes[userId] ?? 100
      const targetGain = this.ultraCustomHandedOver.has(userId)
        ? 0
        : Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (vol / 100)))
      if (this.outputMixContext && this.outputMixContext.state === 'running') {
        gainNode.gain.setTargetAtTime(targetGain, this.outputMixContext.currentTime, 0.015)
      } else {
        gainNode.gain.value = targetGain
      }
    }

    if (this.ultraLowLatency && !this.userGainNodes.has(userId)) {
      const el = this.audioElements.get(userId)
      if (el) {
        el.muted = true
      }
    }
  }

  public isNoiseSuppressionEnabled(): boolean {
    return this.noiseSuppression
  }

  public setNoiseSuppression(enabled: boolean) {
    if (!this.ultraLowLatency) {
      localStorage.setItem(NOISE_SUPPRESSION_STORAGE_KEY, enabled ? 'true' : 'false')
    }
    if (this.noiseSuppression === enabled) return
    this.noiseSuppression = enabled
    if (this.inputGainNode) {
      this.inputGainNode.gain.value = this.effectiveInputGain()
    }
    if (this.backgroundMeterGain) {
      this.backgroundMeterGain.gain.value = this.effectiveInputGain()
    }
    this.warmUpSmartNoiseSuppression(enabled)
    if (this.localStream) void this.updateSettings(this.currentDeviceId, enabled)
    else void this.updateVadBranch()
  }

  public getSmartNoiseModel(): SmartNoiseModel {
    return this.smartModel
  }

  public setSmartNoiseModel(model: SmartNoiseModel) {
    if (model !== 'deepfilter' && model !== 'rnnoise') return
    if (this.smartModel === model) return
    this.smartModel = model
    localStorage.setItem(SMART_MODEL_STORAGE_KEY, model)
    this.warmUpSmartNoiseSuppression()
    if (this.localStream) void this.updateSettings(this.currentDeviceId, this.noiseSuppression)
  }

  public getSuppressionStrength(): number {
    return this.suppressionStrengthDb
  }

  public isSpeechAnalyzerEnabled(): boolean {
    return this.speechAnalyzerEnabled
  }

  public setSpeechAnalyzerEnabled(enabled: boolean) {
    if (this.speechAnalyzerEnabled === enabled) return
    const previousSignature = this.micGraphSignature()
    this.speechAnalyzerEnabled = enabled
    localStorage.setItem(SPEECH_ANALYZER_STORAGE_KEY, enabled ? 'true' : 'false')
    if (enabled) this.warmUpSmartNoiseSuppression()
    if (this.micGraphSignature() === previousSignature) {
      if (this.micNode) {
        this.applyAnalyzerToWorklet()
        if (!enabled && !this.calibrationForcesAnalyzer) this.terminateVadWorker()
      } else if (!enabled && !this.calibrationForcesAnalyzer) {
        this.terminateVadWorker()
      }
      void this.updateVadBranch()
      return
    }
    if (!enabled && !this.calibrationForcesAnalyzer) {
      this.micNode?.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
      this.terminateVadWorker()
    }
    if (this.localStream) void this.updateSettings(this.currentDeviceId, this.noiseSuppression)
  }

  public isEchoCancellationEnabled(): boolean {
    return this.echoCancellationEnabled
  }

  public setEchoCancellationEnabled(enabled: boolean) {
    if (this.echoCancellationEnabled === enabled) return
    this.echoCancellationEnabled = enabled
    localStorage.setItem(ECHO_CANCELLATION_STORAGE_KEY, enabled ? 'true' : 'false')
    if (this.localStream || this.rawStream) {
      void this.updateSettings(this.currentDeviceId, this.noiseSuppression)
    }
  }

  public setSuppressionStrength(db: number) {
    const normalized = this.normalizeSuppressionStrength(db)
    if (normalized === this.suppressionStrengthDb) return
    this.suppressionStrengthDb = normalized
    localStorage.setItem(SUPPRESSION_STRENGTH_STORAGE_KEY, normalized.toString())
    this.updateThresholds()
  }

  private setupVAD(stream: MediaStream, userId: string, isLocal: boolean) {
    this.clearVAD(userId)

    if (isLocal) {
      return
    }

    try {
      let wasSpeaking = false
      let lastSoundAt = 0
      const releaseHoldMs = 200
      const check = () => {
        const pc = this.peerConnections.get(userId)
        if (!pc) return
        const voiceTrackId = this.userVoiceTrackIds.get(userId)
        const streamAudioTrackId = this.userStreamAudioTrackIds.get(userId)
        const audioReceivers = pc.getReceivers().filter(r => r.track && r.track.kind === 'audio')
        const receiver =
          (voiceTrackId ? audioReceivers.find(r => r.track!.id === voiceTrackId) : undefined)
          ?? audioReceivers.find(r => r.track!.id !== streamAudioTrackId)
          ?? audioReceivers[0]
        if (!receiver) return
        try {
          const syncSources = receiver.getSynchronizationSources()
          if (syncSources && syncSources.length > 0) {
            const latestSource = syncSources[0]
            const currentPlayoutLevel = latestSource.audioLevel
            if (currentPlayoutLevel !== undefined) {
              const now = Date.now()
              if (currentPlayoutLevel > 0.001) lastSoundAt = now
              const isRemoteSpeaking = now - lastSoundAt <= releaseHoldMs
              if (isRemoteSpeaking !== wasSpeaking) {
                wasSpeaking = isRemoteSpeaking
                useAppStore.getState().setSpeakingStatus(userId, isRemoteSpeaking)
              }
            }
          }
        } catch { }
      }
      const timer = setInterval(check, 20)
      this.speakingIntervals.set(userId, { timer, stream, nodes: [] })
    } catch (e) {
      console.error('[VAD] setup failed', e)
    }
  }

  private clearVAD(userId: string) {
    const entry = this.speakingIntervals.get(userId)
    if (entry) {
      clearInterval(entry.timer)
      entry.nodes.forEach(n => { try { n.disconnect() } catch { } })
      this.speakingIntervals.delete(userId)
    }
    const store = useAppStore.getState()
    store.setSpeakingStatus(userId, false)
    if (store.currentUser?.id === userId) {
      this.localSpeakingState = false
      signalRService.setSpeakingState(false)
    }
  }

  private toCleanAudioDevice(device: MediaDeviceInfo): MediaDeviceInfo {
    const cleanLabel = (device.label || '').replace(/^(Default|Communications|По умолчанию|Связь)[\s:\-]+/i, '').trim()
    return {
      deviceId: device.deviceId,
      kind: device.kind,
      label: cleanLabel,
      groupId: device.groupId,
      toJSON: () => ({ deviceId: device.deviceId, kind: device.kind, label: cleanLabel, groupId: device.groupId })
    } as MediaDeviceInfo
  }

  private filterAndDeduplicateDevices(devices: MediaDeviceInfo[]): MediaDeviceInfo[] {
    const result: MediaDeviceInfo[] = []
    const seenDeviceIds = new Set<string>()

    const validDevices = devices.filter(d =>
      d.deviceId &&
      d.deviceId !== 'default' &&
      d.deviceId !== 'communications'
    )

    const sortedDevices = [...validDevices].sort((a, b) => {
      const aHasPrefix = /^(Default|Communications|По умолчанию|Связь)[\s:\-]+/i.test(a.label || '')
      const bHasPrefix = /^(Default|Communications|По умолчанию|Связь)[\s:\-]+/i.test(b.label || '')
      if (aHasPrefix && !bHasPrefix) return 1
      if (!aHasPrefix && bHasPrefix) return -1
      return 0
    })

    for (const dev of sortedDevices) {
      if (!seenDeviceIds.has(dev.deviceId)) {
        seenDeviceIds.add(dev.deviceId)
        result.push(this.toCleanAudioDevice(dev))
      }
    }

    if (result.length === 0) {
      return devices.filter(device => device.deviceId).map(device => this.toCleanAudioDevice(device))
    }

    return result
  }

  private getDefaultDeviceFingerprint(devices: MediaDeviceInfo[], kind: MediaDeviceKind): string | null {
    const devicesOfKind = devices.filter(device => device.kind === kind)
    const device = devicesOfKind.find(item => item.deviceId === 'default')
      ?? devicesOfKind.find(item => item.deviceId === 'communications')
      ?? devicesOfKind[0]
    if (!device) return null
    return `${device.groupId}|${device.label}`
  }

  private toAudioDevices(devices: MediaDeviceInfo[]): AudioDevices {
    return {
      inputs: this.filterAndDeduplicateDevices(devices.filter(device => device.kind === 'audioinput')),
      outputs: this.filterAndDeduplicateDevices(devices.filter(device => device.kind === 'audiooutput'))
    }
  }

  public async getAudioDevices(): Promise<AudioDevices> {
    try {
      const enumerate = async (): Promise<MediaDeviceInfo[]> => {
        try {
          return await withTimeout(
            navigator.mediaDevices.enumerateDevices(),
            3000,
            'ENUMERATE_DEVICES_TIMEOUT'
          )
        } catch {
          return []
        }
      }

      let devices = await enumerate()
      const hasLabels = devices.some(d => d.kind === 'audioinput' && Boolean(d.label))

      if (!hasLabels && !this.rawStream?.getAudioTracks().some(track => track.readyState === 'live')) {
        try {
          await withTimeout(
            this.startBackgroundMic(),
            3000,
            'BACKGROUND_MIC_TIMEOUT'
          )
          devices = await enumerate()
        } catch { }
      }

      this.defaultInputFingerprint ??= this.getDefaultDeviceFingerprint(devices, 'audioinput')
      this.defaultOutputFingerprint ??= this.getDefaultDeviceFingerprint(devices, 'audiooutput')
      return this.toAudioDevices(devices)
    } catch (error) {
      console.error('[WebRTC] Failed to enumerate audio devices:', error)
      return { inputs: [], outputs: [] }
    }
  }

  public setInputDevice(deviceId: string) {
    const prevDeviceId = this.currentDeviceId
    this.currentDeviceId = deviceId
    if (this.localStream && prevDeviceId !== deviceId) {
      void this.updateSettings(deviceId, this.noiseSuppression)
    }
  }

  public subscribeMicLevel(listener: (db: number) => void): () => void {
    this.micLevelListeners.add(listener)
    listener(this.micLevelDb)
    return () => this.micLevelListeners.delete(listener)
  }

  private stopBackgroundMeter() {
    if (this.micMeterInterval) {
      clearInterval(this.micMeterInterval)
      this.micMeterInterval = null
    }
    if (this.backgroundSource) {
      try { this.backgroundSource.disconnect() } catch { }
      this.backgroundSource = null
    }
    if (this.backgroundMeterGain) {
      try { this.backgroundMeterGain.disconnect() } catch { }
      this.backgroundMeterGain = null
    }
    this.backgroundAnalyser = null
    if (this.backgroundContext && this.backgroundContext.state !== 'closed') {
      this.backgroundContext.close().catch(() => { })
    }
    this.backgroundContext = null
  }

  private startBackgroundMeter() {
    this.stopBackgroundMeter()
    if (!this.rawStream?.getAudioTracks().some(track => track.readyState === 'live')) return

    const context = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' })
    const source = context.createMediaStreamSource(this.rawStream)
    const analyser = context.createAnalyser()
    analyser.fftSize = 512
    analyser.smoothingTimeConstant = 0
    const meterGain = context.createGain()
    meterGain.gain.value = this.inputVolumeToGain(this.inputVolume)
    source.connect(meterGain)
    meterGain.connect(analyser)
    const silentOutput = context.createGain()
    silentOutput.gain.value = 0
    analyser.connect(silentOutput)
    silentOutput.connect(context.destination)
    this.backgroundContext = context
    this.backgroundSource = source
    this.backgroundAnalyser = analyser
    this.backgroundMeterGain = meterGain
    if (context.state === 'suspended') context.resume().catch(() => { })

    const samples = new Float32Array(analyser.fftSize)
    let smoothedDb = -100
    this.micMeterInterval = setInterval(() => {
      if (!this.backgroundAnalyser) return
      this.backgroundAnalyser.getFloatTimeDomainData(samples)
      let sumSquares = 0
      for (let i = 0; i < samples.length; i++) sumSquares += samples[i] * samples[i]
      const rms = Math.sqrt(sumSquares / samples.length)
      const measuredDb = Math.max(-100, Math.min(0, 20 * Math.log10(Math.max(rms, 0.000001))))
      const smoothing = measuredDb > smoothedDb ? 0.55 : 0.18
      smoothedDb += (measuredDb - smoothedDb) * smoothing
      this.micLevelDb = smoothedDb
      this.micLevelListeners.forEach(listener => listener(smoothedDb))
    }, 50)
  }

  private buildMicConstraints(deviceId?: string, echoCancellation = true): MediaTrackConstraints {
    const useWebRtcNoiseSuppression = !this.ultraLowLatency && this.noiseSuppression && this.thresholdMode === 'manual'
    const useEchoCancellation = !this.ultraLowLatency && echoCancellation
    const constraints: MediaTrackConstraints = {
      channelCount: 1,
      echoCancellation: useEchoCancellation,
      noiseSuppression: useWebRtcNoiseSuppression,
      autoGainControl: false,
      sampleRate: { ideal: 48000 },
      ...(this.ultraLowLatency ? { latency: { ideal: ULTRA_MIC_LATENCY_HINT_S } } : {}),
      // @ts-ignore
      googAutoGainControl: false,
      googAutoGainControl2: false,
      googNoiseSuppression: useWebRtcNoiseSuppression,
      googNoiseSuppression2: useWebRtcNoiseSuppression,
      googTypingNoiseDetection: false,
      googHighpassFilter: false,
      googEchoCancellation: useEchoCancellation,
      googEchoCancellation2: useEchoCancellation,
      googAudioMirroring: false
    }
    if (deviceId && deviceId !== 'default') constraints.deviceId = { exact: deviceId }
    return constraints
  }

  private async captureMicAttempt(
    label: string,
    run: (echoCancellation: boolean) => Promise<MediaStream>
  ): Promise<MediaStream> {
    const capture = (echoCancellation: boolean) => withTimeout(
      run(echoCancellation),
      MIC_CAPTURE_TIMEOUT_MS,
      `MIC_CAPTURE_TIMEOUT: ${label}`,
      late => late.getTracks().forEach(track => track.stop())
    )

    const wantsEchoCancellation = this.echoCancellationEnabled
    const stream = await capture(wantsEchoCancellation)
    if (!wantsEchoCancellation) {
      return stream
    }

    const settings = stream.getAudioTracks()[0]?.getSettings() ?? {}
    const hitchhikers: string[] = []
    if (settings.autoGainControl === true) hitchhikers.push('AGC')
    const expectsNoiseSuppression = this.noiseSuppression && this.thresholdMode === 'manual'
    if (settings.noiseSuppression === true && !expectsNoiseSuppression) hitchhikers.push('noise suppression')

    if (hitchhikers.length === 0) {
      if (settings.echoCancellation !== true) {
        console.log(`[WebRTC] Echo cancellation unavailable on ${label}; capturing without it`)
      }
      return stream
    }

    console.warn(
      `[WebRTC] ${label} switched on ${hitchhikers.join(' + ')} together with echo ` +
      `cancellation; recapturing with AEC off so the voice stays unprocessed`
    )
    stream.getTracks().forEach(track => track.stop())
    return capture(false)
  }

  private async captureRawMicStream(): Promise<MediaStream> {
    const requestedDeviceId = this.currentDeviceId
    const attempts: Array<{
      label: string,
      keepsSelection: boolean,
      run: (echoCancellation: boolean) => Promise<MediaStream>
    }> = []

    if (requestedDeviceId && requestedDeviceId !== 'default') {
      attempts.push({
        label: `selected device ${requestedDeviceId}`,
        keepsSelection: true,
        run: echoCancellation => navigator.mediaDevices.getUserMedia({
          audio: this.buildMicConstraints(requestedDeviceId, echoCancellation),
          video: false
        })
      })
    }
    attempts.push({
      label: 'system default',
      keepsSelection: requestedDeviceId === 'default',
      run: echoCancellation => navigator.mediaDevices.getUserMedia({
        audio: this.buildMicConstraints(undefined, echoCancellation),
        video: false
      })
    })
    attempts.push({
      label: 'first available input',
      keepsSelection: false,
      run: async echoCancellation => {
        const devices = await navigator.mediaDevices.enumerateDevices()
        const inputs = devices.filter(device => device.kind === 'audioinput' && device.deviceId)
        const input = inputs.find(device => device.deviceId !== 'default' && device.deviceId !== 'communications')
          ?? inputs[0]
        if (!input) throw new DOMException('No audio input devices found', 'NotFoundError')
        return navigator.mediaDevices.getUserMedia({
          audio: this.buildMicConstraints(input.deviceId, echoCancellation),
          video: false
        })
      }
    })

    let firstError: unknown = null
    for (const attempt of attempts) {
      try {
        const stream = await this.captureMicAttempt(attempt.label, attempt.run)
        if (!attempt.keepsSelection) {
          this.currentDeviceId = 'default'
          console.warn(`[WebRTC] Microphone "${requestedDeviceId}" unavailable, captured via ${attempt.label}`)
        }
        this.activeRawDeviceId = this.currentDeviceId
        this.lastMicCaptureError = null
        this.lastReportedMicError = null
        return stream
      } catch (error) {
        firstError ??= error
        console.warn(`[WebRTC] Microphone capture failed (${attempt.label}):`, error)
        const errName = (error as any)?.name
        if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError') {
          break
        }
      }
    }

    this.lastMicCaptureError = describeMediaError(firstError)
    throw firstError instanceof Error
      ? firstError
      : new Error(`MIC_ACCESS_FAILED: ${this.lastMicCaptureError}`)
  }

  private reportMicCaptureError(error: unknown): void {
    const detail = describeMediaError(error)
    this.lastMicCaptureError = detail
    if (this.lastReportedMicError === detail) return
    this.lastReportedMicError = detail

    const store = useAppStore.getState()
    const kind = classifyMicrophoneError(detail)
    const toastMsg = kind === 'micBusy'
      ? i18n.t('toasts.micBusy', 'микрофон занят другим приложением.')
      : kind === 'micNotFound'
        ? i18n.t('toasts.micNotFound', 'микрофон не найден. подключите устройство и попробуйте снова.')
        : kind === 'micNoAccess'
          ? i18n.t('toasts.micNoAccess', 'нет доступа к микрофону. проверьте разрешения в ОС.')
          : i18n.t('toasts.audioError', { message: detail, defaultValue: `ошибка аудио: ${detail}` })
    store.setSystemToast(toastMsg)
    setTimeout(() => {
      const currentStore = useAppStore.getState()
      if (currentStore.systemToast === toastMsg) currentStore.setSystemToast(null)
    }, 4000)
  }

  public async startBackgroundMic(deviceId?: string): Promise<boolean> {
    if (deviceId !== undefined) this.currentDeviceId = deviceId
    const targetDeviceId = deviceId || this.currentDeviceId || 'default'
    if (this.rawStream?.getAudioTracks().some(track => track.readyState === 'live')) {
      if (this.activeRawDeviceId !== null && (this.activeRawDeviceId || 'default') !== targetDeviceId) {
        this.rawStream.getTracks().forEach(t => t.stop())
        this.rawStream = null
        this.activeRawDeviceId = null
      } else {
        if (!this.localStream) this.startBackgroundMeter()
        return true
      }
    }

    try {
      this.rawStream = await this.captureRawMicStream()
      this.rawStreamIsFallback = false
      const rawTrack = this.rawStream.getAudioTracks()[0]
      const settings = rawTrack?.getSettings()
      this.loadCalibration(settings?.deviceId || this.currentDeviceId, rawTrack?.label || '')
      this.startBackgroundMeter()
      return true
    } catch (error) {
      console.error('[WebRTC] Failed to initialize background microphone:', error)
      this.reportMicCaptureError(error)
      if (!this.rawStream) {
        this.rawStream = createSilentAudioStream()
        this.rawStreamIsFallback = true
      }
      return false
    }
  }

  public setOutputDevice(deviceId: string) {
    this.currentOutputDeviceId = deviceId || 'default'
    void this.applyOutputDevice()
  }

  public async handleAudioDeviceChange(): Promise<AudioDeviceChangeResult> {
    if (this.deviceChangePromise) return this.deviceChangePromise

    const reconcile = async (): Promise<AudioDeviceChangeResult> => {
      let devices: MediaDeviceInfo[] = []
      try {
        devices = await withTimeout(
          navigator.mediaDevices.enumerateDevices(),
          3000,
          'ENUMERATE_DEVICES_TIMEOUT'
        )
      } catch {
        devices = []
      }
      const availableInputs = new Set(
        devices.filter(device => device.kind === 'audioinput').map(device => device.deviceId)
      )
      const availableOutputs = new Set(
        devices.filter(device => device.kind === 'audiooutput').map(device => device.deviceId)
      )

      const previousInputFingerprint = this.defaultInputFingerprint
      const previousOutputFingerprint = this.defaultOutputFingerprint
      const nextInputFingerprint = this.getDefaultDeviceFingerprint(devices, 'audioinput')
      const nextOutputFingerprint = this.getDefaultDeviceFingerprint(devices, 'audiooutput')
      this.defaultInputFingerprint = nextInputFingerprint
      this.defaultOutputFingerprint = nextOutputFingerprint

      const selectedInputMissing = this.currentDeviceId !== 'default' && !availableInputs.has(this.currentDeviceId)
      const selectedOutputMissing = this.currentOutputDeviceId !== 'default' && !availableOutputs.has(this.currentOutputDeviceId)
      if (selectedInputMissing) this.currentDeviceId = 'default'
      if (selectedOutputMissing) this.currentOutputDeviceId = 'default'

      const rawTrack = this.rawStream?.getAudioTracks()[0]
      const defaultInput = devices.find(device => device.kind === 'audioinput' && device.deviceId === 'default')
      const capturedGroupId = rawTrack?.getSettings().groupId
      const capturedWrongDefault = this.currentDeviceId === 'default' && Boolean(
        rawTrack && defaultInput?.groupId && capturedGroupId && defaultInput.groupId !== capturedGroupId
      )
      const defaultInputChanged = this.currentDeviceId === 'default' && previousInputFingerprint !== null &&
        nextInputFingerprint !== previousInputFingerprint
      const captureEnded = Boolean(this.rawStream && (!rawTrack || rawTrack.readyState !== 'live'))

      if (this.rawStream && (this.rawStreamIsFallback || selectedInputMissing || defaultInputChanged || capturedWrongDefault || captureEnded)) {
        await this.updateSettings(this.currentDeviceId, this.noiseSuppression)
      }

      const defaultOutputChanged = this.currentOutputDeviceId === 'default' &&
        previousOutputFingerprint !== null && nextOutputFingerprint !== previousOutputFingerprint
      if (selectedOutputMissing || defaultOutputChanged) await this.applyOutputDevice()

      return {
        ...this.toAudioDevices(devices),
        inputDeviceId: this.currentDeviceId,
        outputDeviceId: this.currentOutputDeviceId
      }
    }

    this.deviceChangePromise = reconcile()
    try {
      return await this.deviceChangePromise
    } finally {
      this.deviceChangePromise = null
    }
  }

  public isFallbackMic(): boolean {
    return this.rawStreamIsFallback
  }

  public async retryMicCaptureIfFallback(): Promise<boolean> {
    if (!this.rawStreamIsFallback) return false
    try {
      await this.updateSettings(this.currentDeviceId, this.noiseSuppression)
      return !this.rawStreamIsFallback
    } catch {
      return false
    }
  }

  private async applyOutputDevice() {
    const sinkId = this.currentOutputDeviceId === 'default' ? '' : this.currentOutputDeviceId

    if (this.outputMixContext && typeof (this.outputMixContext as any).setSinkId === 'function') {
      try {
        await (this.outputMixContext as any).setSinkId(sinkId)
      } catch (error) {
        console.warn(`[WebRTC] Failed to select output device "${sinkId}" on outputMixContext`, error)
      }
    }

    await this.applyUltraOutputSink()

    if (this.micTestContext) await this.applyMicTestSink(this.micTestContext)

    if (this.ultraLowLatency) {
      for (const [, el] of this.audioElements.entries()) {
        await this.applyVoiceElementSink(el)
      }
    }

    const audioElement = this.mixAudioElement
    if (!audioElement) return
    const setSinkId = (audioElement as HTMLAudioElement & {
      setSinkId?: (id: string) => Promise<void>
    }).setSinkId

    if (typeof setSinkId === 'function') {
      try {
        await setSinkId.call(audioElement, sinkId)
      } catch (error) {
        console.warn(`[WebRTC] Failed to select output device "${sinkId}"`, error)
        if (sinkId !== '') {
          this.currentOutputDeviceId = 'default'
          try {
            await setSinkId.call(audioElement, '')
          } catch (fallbackError) {
            console.warn('[WebRTC] Failed to select the default output device', fallbackError)
          }
        }
      }
    }

    if (this.outputMixContext?.state === 'suspended') {
      await safeResumeContext(this.outputMixContext)
    }
    if (this.ultraOutputContext?.state === 'suspended') {
      await safeResumeContext(this.ultraOutputContext)
    }
    await audioElement.play().catch(error => {
      console.warn('[WebRTC] mixAudioElement play failed:', error)
    })
  }

  public getCalibrationDiagnostics() {
    const rawTrack = this.rawStream?.getAudioTracks()[0]
    const rawSettings = rawTrack?.getSettings()
    return {
      inputDeviceId: this.currentDeviceId,
      outputDeviceId: this.currentOutputDeviceId,
      calibrationProfileKey: this.calibrationDeviceId,
      noiseSuppression: this.noiseSuppression,
      ultraLowLatency: this.ultraLowLatency,
      thresholdMode: this.thresholdMode,
      smartModel: this.smartModel,
      suppressionStrengthDb: this.suppressionStrengthDb,
      speechAnalyzerEnabled: this.speechAnalyzerEnabled,
      hasMicNode: Boolean(this.micNode),
      micNodeReady: this.micNodeReady,
      micEngineError: this.micEngineError,
      hasManualGateNode: Boolean(this.manualGateNode),
      audioProcessorError: this.audioProcessorError,
      sileroVadThreshold: this.calibratedVadThreshold,
      vadWorkerReady: this.vadWorkerReady,
      micCaptureError: this.lastMicCaptureError,
      processedContextState: this.processedContext?.state ?? null,
      processedContextSampleRate: this.processedContext?.sampleRate ?? null,
      capturedDeviceId: rawSettings?.deviceId ?? null,
      capturedSampleRate: rawSettings?.sampleRate ?? null,
      capturedChannelCount: rawSettings?.channelCount ?? null,
      capturedEchoCancellation: rawSettings?.echoCancellation ?? null,
      capturedAutoGainControl: rawSettings?.autoGainControl ?? null,
      capturedNoiseSuppression: rawSettings?.noiseSuppression ?? null,
      rawTrackLabel: rawTrack?.label ?? null,
      rawTrackState: rawTrack?.readyState ?? null,
      rawTrackEnabled: rawTrack?.enabled ?? null,
      rawTrackMuted: rawTrack?.muted ?? null,
      localTrackEnabled: this.localStream?.getAudioTracks()[0]?.enabled ?? null
    }
  }

  private activeCalibrationEngine(): SmartNoiseModel | 'manual' {
    if (!this.isSmartMode()) return 'manual'
    return this.smartModel
  }

  private postEngineConfig(config: Record<string, unknown>) {
    this.micNode?.port.postMessage({ type: 'setConfig', ...config })
    this.manualGateNode?.port.postMessage({ type: 'setConfig', ...config })
  }

  public isCalibrationAvailable(): boolean {
    return VAD_CALIBRATION_ENABLED && !this.ultraLowLatency
  }

  public async calibrateMic(durationMs = 4500, onStarted?: () => void): Promise<CalibrationResult> {
    if (!VAD_CALIBRATION_ENABLED) {
      throw new CalibrationError(
        'CALIBRATION_ENGINE_UNAVAILABLE',
        'Voice calibration is disabled, the VAD threshold is fixed'
      )
    }
    const wasInActiveSession = Boolean(useAppStore.getState().currentChannelId || useAppStore.getState().currentCallUser)
    const engine = this.activeCalibrationEngine()

    if (engine === 'manual') {
      throw new CalibrationError(
        'CALIBRATION_ENGINE_UNAVAILABLE',
        'Calibration requires smart noise suppression'
      )
    }

    const me = useAppStore.getState().currentUser
    const wasMuted = Boolean(me?.isMuted || me?.isServerMuted)
    let muteLifted = false
    const analyzerWasOff = !this.speechAnalyzerEnabled
    if (analyzerWasOff) this.calibrationForcesAnalyzer = true

    try {
      await withTimeout(
        this.prepareCalibrationEngine(),
        CALIBRATION_PREPARE_TIMEOUT_MS,
        `Calibration preparation timed out (${engine})`
      )

      if (wasMuted) {
        this.calibrationSuppressesSpeaking = true
        muteLifted = true
        this.postEngineConfig({ isMuted: false })
      }

      onStarted?.()
      return await this.calibrateViaVadWorker(durationMs)
    } catch (error) {
      if (error instanceof CalibrationError) throw error
      throw new CalibrationError(
        'CALIBRATION_TIMEOUT',
        error instanceof Error ? error.message : String(error)
      )
    } finally {
      if (analyzerWasOff) {
        this.calibrationForcesAnalyzer = false
        this.micNode?.port.postMessage({ type: 'setConfig', sileroVadEnabled: false })
        this.terminateVadWorker()
      }
      if (muteLifted) {
        const currentUser = useAppStore.getState().currentUser
        const stillMuted = Boolean(currentUser?.isMuted || currentUser?.isServerMuted)
        this.postEngineConfig({ isMuted: stillMuted })
        this.calibrationSuppressesSpeaking = false
        if (stillMuted && this.localSpeakingState) {
          this.localSpeakingState = false
          if (currentUser) {
            useAppStore.getState().setSpeakingStatus(currentUser.id, false)
            signalRService.setSpeakingState(false)
          }
        }
      }
      if (!wasInActiveSession) {
        await withTimeout(
          this.enterBackgroundMode(),
          CALIBRATION_CLEANUP_TIMEOUT_MS,
          'Background microphone restore timed out'
        ).catch(error => console.warn('[WebRTC] Calibration cleanup:', error))
      }
    }
  }

  private async prepareCalibrationEngine(): Promise<void> {
    if (!this.micNode) {
      try {
        if (this.localStream) {
          await this.updateSettings(this.currentDeviceId, this.noiseSuppression)
        } else {
          await this.startLocalStream(this.currentDeviceId, this.noiseSuppression, true)
        }
      } catch (error) {
        const detail = describeMediaError(error)
        console.error('[WebRTC] Calibration could not start the microphone:', detail)
        throw new CalibrationError('CALIBRATION_NO_MIC', detail)
      }
    }

    if (this.lastMicCaptureError) {
      throw new CalibrationError('CALIBRATION_NO_MIC', this.lastMicCaptureError)
    }

    await this.ensureVadWorker().catch(error => {
      console.warn('[WebRTC] Calibration could not start Silero VAD:', error)
    })
    if (this.vadWorkerReady) {
      this.micNode?.port.postMessage({ type: 'setConfig', sileroVadEnabled: true })
    }

    await this.waitForCalibrationReady()
  }

  private async waitForCalibrationReady(timeoutMs = 8000): Promise<void> {
    const startedAt = Date.now()
    const hasNode = () => Boolean(this.micNode)
    const isReady = () => hasNode() && this.vadWorkerReady

    while (!isReady() && Date.now() - startedAt < timeoutMs) {
      if (!hasNode() || this.audioProcessorError) break
      await new Promise(resolve => setTimeout(resolve, 100))
    }
    if (!isReady()) {
      throw new CalibrationError('CALIBRATION_ENGINE_UNAVAILABLE', this.audioProcessorError || (hasNode()
        ? 'Silero voice detection did not become ready'
        : 'Audio worklet node is unavailable'))
    }
  }

  private calibrateViaVadWorker(durationMs = 4500): Promise<CalibrationResult> {
    return new Promise((resolve, reject) => {
      if (!this.micNode || !this.vadWorkerReady) {
        reject(new CalibrationError(
          'CALIBRATION_ENGINE_UNAVAILABLE',
          this.audioProcessorError || 'Silero voice detection is not ready'
        ))
        return
      }
      if (this.calibrationInProgress) {
        reject(new CalibrationError('CALIBRATION_BUSY', 'Microphone calibration is already running'))
        return
      }
      if (!this.rawStream?.getAudioTracks().some(track => track.readyState === 'live' && track.enabled)) {
        reject(new CalibrationError('CALIBRATION_NO_MIC', this.lastMicCaptureError || 'The microphone track is not live'))
        return
      }

      const previousThreshold = this.calibratedVadThreshold
      const previousCalibrationState = this.hasVoiceCalibration
      const restorePreviousProfile = () => {
        this.calibratedVadThreshold = previousThreshold
        this.hasVoiceCalibration = previousCalibrationState
        this.updateThresholds()
      }

      this.calibrationInProgress = true
      const probabilities: number[] = []
      let peakProbability = 0
      const settleUntil = Date.now() + 150
      const collector = (probability: number, windowRms: number) => {
        if (Date.now() < settleUntil) return
        if (!Number.isFinite(probability) || !Number.isFinite(windowRms)) return
        if (windowRms < 0.0006 || probability < 0.4) return
        if (probabilities.length >= 512) return
        probabilities.push(probability)
        peakProbability = Math.max(peakProbability, probability)
      }
      this.voiceProbeCollector = collector

      window.setTimeout(() => {
        this.calibrationInProgress = false
        if (this.voiceProbeCollector !== collector) {
          reject(new CalibrationError(
            'CALIBRATION_ENGINE_UNAVAILABLE',
            this.micEngineError || 'The audio graph was rebuilt during calibration'
          ))
          return
        }
        this.voiceProbeCollector = null

        const values = probabilities.slice().sort((a, b) => a - b)
        const percentile = (p: number) => values.length
          ? values[Math.min(values.length - 1, Math.floor((values.length - 1) * p))]
          : 0
        const voiceLow = percentile(0.1)
        const voiceMedian = percentile(0.5)
        const voiceHigh = percentile(0.9)

        if (values.length < MIN_VOICE_CALIBRATION_WINDOWS || peakProbability < 0.4) {
          restorePreviousProfile()
          reject(new CalibrationError(
            'CALIBRATION_NEEDS_VOICE',
            `accepted ${values.length} voice windows, peak ${peakProbability.toFixed(3)}`
          ))
          return
        }

        this.calibratedVadThreshold = vadThresholdFromVoiceLow(voiceLow)
        this.hasVoiceCalibration = true
        this.updateThresholds()
        console.info('[WebRTC] DeepFilter voice calibration', {
          vadThreshold: Number(this.calibratedVadThreshold.toFixed(4)),
          voiceLow: Number(voiceLow.toFixed(4)),
          voiceMedian: Number(voiceMedian.toFixed(4)),
          voiceHigh: Number(voiceHigh.toFixed(4)),
          peakProbability: Number(peakProbability.toFixed(4)),
          acceptedVoiceWindows: values.length
        })

        try {
          const profile: StoredVoiceProfile = {
            version: WebRTCManager.CALIBRATION_SCHEMA_VERSION,
            timestamp: Date.now(),
            vadThreshold: this.calibratedVadThreshold,
            voiceLow,
            voiceMedian,
            voiceHigh
          }
          localStorage.setItem(this.calibrationStorageKey(this.calibrationDeviceId), JSON.stringify(profile))
        } catch (error) {
          console.error('Failed to save Silero calibration data', error)
        }

        resolve({
          vadThreshold: this.calibratedVadThreshold,
          voiceLow,
          voiceMedian,
          voiceHigh,
          peakProbability,
          acceptedVoiceWindows: values.length
        })
      }, durationMs)
    })
  }

  public async prewarmLocalStream(): Promise<boolean> {
    if (this.localStream && this.localStream.getAudioTracks().length > 0 && this.localStream.getAudioTracks().every(t => t.readyState === 'live')) {
      return true
    }
    return this.startLocalStream(undefined, undefined, false)
  }

  private setMonitorWhileMuted(enabled: boolean) {
    this.micNode?.port.postMessage({ type: 'setConfig', monitorWhileMuted: enabled })
    this.manualGateNode?.port.postMessage({ type: 'setConfig', monitorWhileMuted: enabled })
  }

  private async ensureMicTestCaptureModule(ctx: AudioContext): Promise<void> {
    if (ctx.state === 'closed') return
    let promise = this.micTestCapturePromises.get(ctx)
    if (!promise) {
      promise = ctx.audioWorklet.addModule(micTestCaptureProcessorUrl).catch(err => {
        this.micTestCapturePromises.delete(ctx)
        throw err
      })
      this.micTestCapturePromises.set(ctx, promise)
    }
    await promise
  }

  private ensureMicTestPlayback(sampleRate: number): { ctx: AudioContext; gain: GainNode } {
    let ctx = this.micTestContext
    if (ctx && ctx.state !== 'closed' && this.micTestGain) {
      if (ctx.state === 'suspended') void ctx.resume().catch(() => { })
      return { ctx, gain: this.micTestGain }
    }

    this.releaseMicTestPlayback()
    try {
      ctx = new AudioContext({ sampleRate, latencyHint: 'interactive' })
    } catch (error) {
      console.warn(`[WebRTC] Mic test playback could not use ${sampleRate} Hz, falling back to default:`, error)
      ctx = new AudioContext({ latencyHint: 'interactive' })
    }
    this.micTestContext = ctx
    const gain = ctx.createGain()
    gain.gain.value = this.micTestVolume()
    gain.connect(ctx.destination)
    this.micTestGain = gain
    void this.applyMicTestSink(ctx)
    if (ctx.state === 'suspended') void ctx.resume().catch(() => { })

    return { ctx, gain }
  }

  private micTestVolume(): number {
    return Math.max(0, Math.min(2, this.outputVolume / 100))
  }

  private releaseMicTestPlayback() {
    this.detachMicTestSource()
    if (this.micTestGain) {
      try { this.micTestGain.disconnect() } catch { }
      this.micTestGain = null
    }
    if (this.micTestContext) {
      const ctx = this.micTestContext
      this.micTestContext = null
      void ctx.close().catch(() => { })
    }
  }

  private detachMicTestSource() {
    const source = this.micTestSource
    this.micTestSource = null
    if (!source) return
    source.onended = null
    try { source.stop() } catch { }
    try { source.disconnect() } catch { }
  }

  private async applyMicTestSink(ctx: AudioContext) {
    const target = ctx as AudioContext & { setSinkId?: (id: string) => Promise<void> }
    if (typeof target.setSinkId !== 'function') return
    const sinkId = this.currentOutputDeviceId === 'default' ? '' : this.currentOutputDeviceId
    try {
      await target.setSinkId(sinkId)
    } catch (error) {
      console.warn('[WebRTC] Mic test could not select the output device:', error)
    }
  }

  public isMicTestRecording(): boolean {
    return this.micTestRun !== null
  }

  public async prepareMicTest(): Promise<void> {
    let ctx: AudioContext | null = null
    try {
      if (!await this.prewarmLocalStream()) return
      ctx = this.processedContext
      if (!ctx || ctx.state === 'closed') return
      await this.ensureMicTestCaptureModule(ctx)
    } catch (error) {
      const currentCtx = this.processedContext
      if (currentCtx && currentCtx !== ctx && currentCtx.state !== 'closed') {
        try {
          await this.ensureMicTestCaptureModule(currentCtx)
          return
        } catch { }
      }
      const isAbort =
        (error instanceof DOMException && (error.name === 'AbortError' || error.code === 20)) ||
        (error instanceof Error && error.name === 'AbortError')
      if (isAbort || !currentCtx || currentCtx.state === 'closed') {
        return
      }
      console.warn('[WebRTC] Mic test could not warm up:', error)
    }
  }

  public async recordMicTest(onArmed?: () => void, durationMs = MIC_TEST_DURATION_MS): Promise<MicTestClip> {
    if (this.micTestRun) return this.micTestRun
    this.micTestRun = this.runMicTest(durationMs, onArmed)
    try {
      return await this.micTestRun
    } finally {
      this.micTestRun = null
    }
  }

  private async runMicTest(durationMs: number, onArmed?: () => void): Promise<MicTestClip> {
    this.pauseMicTest()
    this.micTestBuffer = null
    const generation = this.micTestGeneration

    const started = await this.prewarmLocalStream()
    const ctx = this.processedContext
    const tap = this.micOutputTap
    if (!started || !ctx || !tap || ctx.state === 'closed') throw new Error('MIC_TEST_NO_MIC')
    await safeResumeContext(ctx)

    await this.ensureMicTestCaptureModule(ctx)
    const capture = new AudioWorkletNode(ctx, 'mic-test-capture-processor', {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [1],
      channelCount: 1,
      channelCountMode: 'explicit'
    })
    const sink = ctx.createMediaStreamDestination()
    capture.connect(sink)

    let timeout: ReturnType<typeof setTimeout> | null = null
    const captured = new Promise<Float32Array<ArrayBuffer>>((resolve, reject) => {
      capture.port.onmessage = event => {
        if (event.data?.type === 'captured') resolve(event.data.pcm as Float32Array<ArrayBuffer>)
      }
      capture.onprocessorerror = () => reject(new Error('MIC_TEST_CAPTURE_FAILED'))
      timeout = setTimeout(() => reject(new Error('MIC_TEST_TIMEOUT')), durationMs + MIC_TEST_CAPTURE_GRACE_MS)
    })

    try {
      tap.connect(capture)
      this.setMonitorWhileMuted(true)
      await new Promise(resolve => setTimeout(resolve, MIC_TEST_MONITOR_SETTLE_MS))
      if (generation !== this.micTestGeneration) throw new Error('MIC_TEST_CANCELLED')
      onArmed?.()
      await new Promise(resolve => setTimeout(resolve, MIC_TEST_PIPELINE_FLUSH_MS))
      if (generation !== this.micTestGeneration) throw new Error('MIC_TEST_CANCELLED')
      capture.port.postMessage({
        type: 'start',
        samples: Math.round((durationMs / 1000) * ctx.sampleRate)
      })
      const pcm = await captured
      if (generation !== this.micTestGeneration) throw new Error('MIC_TEST_CANCELLED')
      if (pcm.length === 0) throw new Error('MIC_TEST_EMPTY')

      let peak = 0
      for (let i = 0; i < pcm.length; i++) {
        const magnitude = pcm[i] < 0 ? -pcm[i] : pcm[i]
        if (magnitude > peak) peak = magnitude
      }

      const playback = this.ensureMicTestPlayback(ctx.sampleRate)
      const buffer = playback.ctx.createBuffer(1, pcm.length, ctx.sampleRate)
      buffer.copyToChannel(pcm, 0)
      this.micTestBuffer = buffer
      this.micTestOffset = 0

      return {
        durationSeconds: buffer.duration,
        peakDb: Math.round(20 * Math.log10(Math.max(peak, 1e-6)))
      }
    } catch (error) {
      if (generation !== this.micTestGeneration) throw new Error('MIC_TEST_CANCELLED')
      throw error
    } finally {
      if (timeout) clearTimeout(timeout)
      this.setMonitorWhileMuted(false)
      capture.port.onmessage = null
      capture.onprocessorerror = null
      try { capture.port.postMessage({ type: 'stop' }) } catch { }
      try { tap.disconnect(capture) } catch { }
      try { capture.disconnect() } catch { }
      for (const track of sink.stream.getTracks()) {
        try { track.stop() } catch { }
      }
    }
  }

  public onMicTestEnded(listener: (() => void) | null) {
    this.micTestEndedListener = listener
  }

  public getMicTestDuration(): number {
    return this.micTestBuffer?.duration ?? 0
  }

  public isMicTestPlaying(): boolean {
    return this.micTestPlaying
  }

  public getMicTestPosition(): number {
    const buffer = this.micTestBuffer
    if (!buffer) return 0
    if (!this.micTestPlaying || !this.micTestContext) return Math.min(this.micTestOffset, buffer.duration)
    const elapsed = this.micTestContext.currentTime - this.micTestStartedAt
    return Math.max(0, Math.min(buffer.duration, elapsed))
  }

  public playMicTest(offsetSeconds?: number): boolean {
    const buffer = this.micTestBuffer
    if (!buffer) return false

    const playback = this.ensureMicTestPlayback(buffer.sampleRate)
    this.detachMicTestSource()

    const requested = offsetSeconds === undefined ? this.micTestOffset : offsetSeconds
    const offset = requested >= buffer.duration - 0.02 ? 0 : Math.max(0, requested)

    const source = playback.ctx.createBufferSource()
    source.buffer = buffer
    source.connect(playback.gain)
    playback.gain.gain.value = this.micTestVolume()
    source.onended = () => {
      if (this.micTestSource !== source) return
      this.micTestSource = null
      this.micTestPlaying = false
      this.micTestOffset = buffer.duration
      this.micTestEndedListener?.()
    }

    this.micTestSource = source
    this.micTestOffset = offset
    this.micTestStartedAt = playback.ctx.currentTime - offset
    this.micTestPlaying = true
    source.start(0, offset)
    return true
  }

  public pauseMicTest() {
    if (!this.micTestPlaying) return
    this.micTestOffset = this.getMicTestPosition()
    this.micTestPlaying = false
    this.detachMicTestSource()
  }

  public seekMicTest(seconds: number) {
    const buffer = this.micTestBuffer
    if (!buffer) return
    const target = Math.max(0, Math.min(buffer.duration - MIC_TEST_SEEK_TAIL_S, seconds))
    if (this.micTestPlaying) {
      this.playMicTest(target)
      return
    }
    this.micTestOffset = target
  }

  public disposeMicTest() {
    this.micTestGeneration++
    this.micTestPlaying = false
    this.micTestOffset = 0
    this.micTestBuffer = null
    this.releaseMicTestPlayback()
    this.setMonitorWhileMuted(false)
  }

  public async startLocalStream(deviceId?: string, useNS?: boolean, forceRestart = false): Promise<boolean> {
    const generation = this.microphoneGeneration
    if (deviceId !== undefined) this.currentDeviceId = deviceId
    if (useNS !== undefined) this.noiseSuppression = useNS

    if (this.activeStartPromise) {
      if (!forceRestart) {
        return this.activeStartPromise
      }
      try {
        await this.activeStartPromise
      } catch { }
    }

    const run = async () => {
      const startedAt = performance.now()
      const laps: string[] = []
      let lapAt = startedAt
      const lap = (label: string) => {
        const now = performance.now()
        laps.push(`${label} ${Math.round(now - lapAt)}ms`)
        lapAt = now
      }
      const targetDeviceId = deviceId || this.currentDeviceId || 'default'
      if (
        !forceRestart &&
        !this.rawStreamIsFallback &&
        this.activeRawDeviceId !== null &&
        (this.activeRawDeviceId || 'default') === targetDeviceId &&
        this.activeGraphSignature === this.micGraphSignature() &&
        this.localStream &&
        this.localStream.getAudioTracks().length > 0 &&
        this.localStream.getAudioTracks().every(t => t.readyState === 'live')
      ) {
        this.initOutputMixer()
        await safeResumeContext(this.processedContext)
        this.startSilenceMonitor()
        const me = useAppStore.getState().currentUser
        void this.updateVadBranch().catch(() => {})
        const isMuted = me?.isMuted || me?.isServerMuted || false
        this.toggleMute(isMuted)
        console.log(`[WebRTC] startLocalStream reused existing stream in ${Math.round(performance.now() - startedAt)}ms`)
        return true
      }

      try {
        this.initOutputMixer()
        this.stopBackgroundMeter()
        if (this.rawStream) {
          this.rawStream.getTracks().forEach(t => t.stop())
          this.rawStream = null
          this.activeRawDeviceId = null
        }
        if (this.localStream) {
          this.localStream.getTracks().forEach(t => t.stop())
          this.localStream = null
        }
        await this.cleanupProcessedStream()
        lap('cleanup')

        let raw: MediaStream
        try {
          raw = await this.captureRawMicStream()
          this.rawStreamIsFallback = false
        } catch (error) {
          this.reportMicCaptureError(error)
          raw = createSilentAudioStream()
          this.rawStreamIsFallback = true
          this.activeRawDeviceId = null
        }
        lap('getUserMedia')

        this.rawStream = raw
        if (this.microphoneGeneration !== generation) {
          raw.getTracks().forEach(track => track.stop())
          this.rawStream = null
          throw new DOMException('Microphone session cancelled', 'AbortError')
        }
        if (!this.rawStreamIsFallback && !this.activeRawDeviceId) {
          this.activeRawDeviceId = targetDeviceId
        }
        const rawTrack = raw.getAudioTracks()[0]
        if (rawTrack) {
          rawTrack.contentHint = 'speech'
          const settings = rawTrack.getSettings()
          this.loadCalibration(settings.deviceId || this.currentDeviceId, rawTrack.label)
          console.info('[WebRTC] Microphone settings', {
            deviceId: settings.deviceId,
            sampleRate: settings.sampleRate,
            channelCount: settings.channelCount,
            echoCancellation: settings.echoCancellation,
            noiseSuppression: settings.noiseSuppression,
            autoGainControl: settings.autoGainControl
          })
        }

        this.localStream = await this.createProcessedStream(raw)
        if (this.microphoneGeneration !== generation) {
          this.localStream.getTracks().forEach(track => track.stop())
          this.localStream = null
          await this.cleanupProcessedStream()
          throw new DOMException('Microphone session cancelled', 'AbortError')
        }
        this.activeGraphSignature = this.micGraphSignature()
        lap('graph')

        const localTrack = this.localStream.getAudioTracks()[0]
        if (localTrack) {
          localTrack.contentHint = 'speech'
        }

        await safeResumeContext(this.processedContext)

        this.startSilenceMonitor()

        const me = useAppStore.getState().currentUser
        void this.updateVadBranch().catch(() => {})

        const isMuted = me?.isMuted || me?.isServerMuted || false
        this.toggleMute(isMuted)
        lap('meters')

        console.log(`[WebRTC] startLocalStream ${Math.round(performance.now() - startedAt)}ms: ${laps.join(', ')}`)
        return true
      } catch (e) {
        throw new Error(`MIC_ACCESS_FAILED: ${describeMediaError(e)}`)
      }
    }

    this.activeStartPromise = run()
    try {
      return await this.activeStartPromise
    } finally {
      this.activeStartPromise = null
    }
  }

  public async updateSettings(deviceId: string, useNS: boolean): Promise<void> {
    this.currentDeviceId = deviceId
    this.noiseSuppression = useNS
    this.pendingSettingsUpdate = { deviceId, useNS }

    return new Promise<void>((resolve, reject) => {
      this.settingsWaiters.push({ resolve, reject })
      if (this.settingsUpdateTimer) {
        clearTimeout(this.settingsUpdateTimer)
      }
      this.settingsUpdateTimer = setTimeout(() => {
        this.settingsUpdateTimer = null
        void this.flushSettingsQueue()
      }, 30)
    })
  }

  private async flushSettingsQueue(): Promise<void> {
    if (this.isFlushingSettings) return
    this.isFlushingSettings = true
    try {
      while (this.pendingSettingsUpdate || this.settingsWaiters.length > 0) {
        if (this.settingsUpdateTimer) {
          clearTimeout(this.settingsUpdateTimer)
          this.settingsUpdateTimer = null
        }
        const target = this.pendingSettingsUpdate
        this.pendingSettingsUpdate = null
        const waiters = this.settingsWaiters
        this.settingsWaiters = []

        if (!target) {
          for (const w of waiters) {
            try { w.resolve() } catch { }
          }
          continue
        }

        try {
          const promise = this.executeUpdateSettings(target.deviceId, target.useNS)
          this.activeSettingsPromise = promise
          await promise
          for (const w of waiters) {
            try { w.resolve() } catch { }
          }
        } catch (err) {
          console.error('[WebRTC] executeUpdateSettings failed in flushSettingsQueue:', err)
          for (const w of waiters) {
            try { w.resolve() } catch { }
          }
        } finally {
          this.activeSettingsPromise = null
        }
      }
    } finally {
      this.isFlushingSettings = false
    }
  }

  private async executeUpdateSettings(deviceId: string, useNS: boolean): Promise<void> {
    if (this.localStream) {
      try {
        const oldAudioTrack = this.localStream.getAudioTracks()[0]
        await this.startLocalStream(deviceId, useNS, true)
        const screenAudioTracks = this.localVideoStream ? this.localVideoStream.getAudioTracks() : []
        for (const pc of this.peerConnections.values()) {
          const micTransceiver = pc.getTransceivers().find(t =>
            t.receiver.track.kind === 'audio' &&
            (!t.sender.track || !screenAudioTracks.includes(t.sender.track))
          )
          const sender = pc.getSenders().find(s => s.track && s.track === oldAudioTrack)
            ?? pc.getSenders().find(s => s.track && s.track.kind === 'audio' && !screenAudioTracks.includes(s.track))
            ?? micTransceiver?.sender
          const newTrack = this.localStream?.getAudioTracks()[0]
          if (sender && newTrack) {
            await sender.replaceTrack(newTrack).catch(err => {
              console.warn('[WebRTC] replaceTrack failed in executeUpdateSettings:', err)
            })
            this.configureAudioSender(sender)
          }
        }
        if (this.ultraLowLatency) this.restartUltraSend()
      } catch (e) {
        throw e
      }
    } else if (this.rawStream) {
      this.rawStream.getTracks().forEach(track => track.stop())
      this.rawStream = null
      this.activeRawDeviceId = null
      this.stopBackgroundMeter()
      await this.startBackgroundMic(deviceId)
    }
  }

  public async setNoiseSuppressionMode(mode: 'auto' | 'manual') {
    this.thresholdMode = mode
    localStorage.setItem('zabor_threshold_mode', mode)
    if (this.localStream) await this.updateSettings(this.currentDeviceId, this.noiseSuppression)
    else await this.updateVadBranch()
  }

  public stopLocalStream() {
    this.microphoneGeneration++
    const me = useAppStore.getState().currentUser
    if (me) this.clearVAD(me.id)
    this.stopSilenceMonitor()
    if (this.localStream) { this.localStream.getTracks().forEach(t => t.stop()); this.localStream = null }
    if (this.rawStream) { this.rawStream.getTracks().forEach(t => t.stop()); this.rawStream = null; this.activeRawDeviceId = null }
    this.stopBackgroundMeter()
    this.cleanupProcessedStream()
    this.leaveAll()
  }

  public async enterBackgroundMode(): Promise<void> {
    const me = useAppStore.getState().currentUser
    if (me) this.clearVAD(me.id)
    this.stopSilenceMonitor()
    this.applyLocalSpeaking(false)
    this.leaveAll()

    const hasLiveLocalStream = Boolean(
      this.localStream &&
      this.localStream.getAudioTracks().length > 0 &&
      this.localStream.getAudioTracks().every(track => track.readyState === 'live') &&
      this.processedContext &&
      this.processedContext.state !== 'closed'
    )

    if (!hasLiveLocalStream) {
      if (this.localStream) {
        this.localStream.getTracks().forEach(track => track.stop())
        this.localStream = null
      }
      await this.cleanupProcessedStream()

      if (this.rawStream?.getAudioTracks().some(track => track.readyState === 'live')) {
        this.startBackgroundMeter()
      } else {
        await this.startBackgroundMic()
      }
    }
  }

  private startSilenceMonitor() {
    this.stopSilenceMonitor();
    this.silenceCounterMs = 0;
    this.isSilenceWarningActive = false;

    if (!this.rawAnalyserNode) return;

    const bufferLength = this.rawAnalyserNode.fftSize;
    const dataArray = new Float32Array(bufferLength);

    this.silenceMonitorInterval = setInterval(() => {
      const store = useAppStore.getState();
      const me = store.currentUser;

      if (!me || me.isMuted || me.isServerMuted) {
        this.silenceCounterMs = 0;
        return;
      }

      if (this.rawAnalyserNode) {
        try {
          this.rawAnalyserNode.getFloatTimeDomainData(dataArray);
          let sumSquares = 0;
          for (let i = 0; i < bufferLength; i++) {
            sumSquares += dataArray[i] * dataArray[i];
          }
          const rms = Math.sqrt(sumSquares / bufferLength);

          if (rms < 0.0002) {
            this.silenceCounterMs += 200;
          } else {
            this.silenceCounterMs = 0;
          }

          if (this.silenceCounterMs >= 15000 && !this.isSilenceWarningActive) {
            this.isSilenceWarningActive = true;
            const toastMsg = i18n.t('toasts.micNotHearing', 'вас не слышно, проверьте микрофон');
            store.setSystemToast(toastMsg);

            setTimeout(() => {
              const currentStore = useAppStore.getState();
              if (currentStore.systemToast === toastMsg) {
                currentStore.setSystemToast(null);
              }
              this.isSilenceWarningActive = false;
            }, 4000);

            this.silenceCounterMs = 0;
          }
        } catch (e) {
          console.warn('[WebRTC] Silence monitor error:', e);
        }
      }
    }, 200);
  }

  private stopSilenceMonitor() {
    if (this.silenceMonitorInterval) {
      clearInterval(this.silenceMonitorInterval);
      this.silenceMonitorInterval = null;
    }
    this.silenceCounterMs = 0;
    this.isSilenceWarningActive = false;
    this.rawAnalyserNode = null;
  }

  public toggleMute(isMuted: boolean) {
    if (this.micNode) {
      this.micNode.port.postMessage({ type: 'setConfig', isMuted: isMuted })
    }
    if (this.manualGateNode) {
      this.manualGateNode.port.postMessage({ type: 'setConfig', isMuted })
    }
    if (this.webRtcVadSidecar) {
      this.webRtcVadSidecar.setMuted(isMuted)
    }
    if (isMuted) {
      this.applyLocalSpeaking(false)
    }
    if (this.localStream) {
      this.localStream.getAudioTracks().forEach(t => { t.enabled = !isMuted })
    }
    if (this.ultraSendClonedTrack) { try { this.ultraSendClonedTrack.enabled = !isMuted } catch { } }
  }

  public setUserVolume(userId: string, volume: number) {
    useAppStore.getState().setUserVolume(userId, Math.max(0, Math.min(200, volume)))
    this.updateRemoteVolume(userId)
  }

  public setUserVolumeRealtime(userId: string, volume: number) {
    const clamped = Math.max(0, Math.min(200, volume))
    const level = Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (clamped / 100)))
    const gainNode = this.userGainNodes.get(userId)
    if (gainNode) {
      const target = this.ultraCustomHandedOver.has(userId) ? 0 : level
      if (this.outputMixContext && this.outputMixContext.state === 'running') {
        gainNode.gain.setTargetAtTime(target, this.outputMixContext.currentTime, 0.015)
      } else {
        gainNode.gain.value = target
      }
    }
    const jitterGain = this.ultraJitterGains.get(userId)
    if (jitterGain) {
      if (this.ultraOutputContext && this.ultraOutputContext.state === 'running') {
        jitterGain.gain.setTargetAtTime(level, this.ultraOutputContext.currentTime, 0.015)
      } else {
        jitterGain.gain.value = level
      }
    }
  }

  private initOutputMixer() {
    if (this.outputMixContext) {
      if (this.outputMixContext.state === 'suspended') this.outputMixContext.resume().catch(() => { })
      this.startAudioHealthMonitoring()
      return
    }
    try {
      this.outputMixContext = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' })
    } catch (e) {
      console.warn('[WebRTC] Failed to create outputMixContext at 48000Hz, falling back to default:', e)
      this.outputMixContext = new AudioContext({ latencyHint: 'interactive' })
    }
    if (this.outputMixContext.state === 'suspended') {
      this.outputMixContext.resume().catch(() => { })
    }
    this.startAudioHealthMonitoring()
    this.outputBusGain = this.outputMixContext.createGain()
    this.outputBusGain.gain.value = this.isDeafened ? 0 : Math.pow(10, PLAYBACK_MAKEUP_GAIN_DB / 20)

    this.outputPeakGuard = this.createPeakGuard(this.outputMixContext, this.ultraLowLatency ? 'none' : '4x')
    this.outputBusGain.connect(this.outputPeakGuard)

    const ctx = this.outputMixContext
    const hasContextSink = typeof (ctx as any).setSinkId === 'function'

    if (hasContextSink) {
      this.outputPeakGuard.connect(ctx.destination)
    } else {
      const dest = ctx.createMediaStreamDestination()
      const destTrack = dest.stream.getAudioTracks()[0]
      if (destTrack) destTrack.contentHint = 'music'
      this.outputPeakGuard.connect(dest)

      this.mixAudioElement = new Audio()
      this.mixAudioElement.autoplay = true
      this.mixAudioElement.srcObject = dest.stream
      this.mixAudioElement.muted = this.isDeafened
    }
    void this.applyOutputDevice()
  }

  private createPlaybackLimiter(
    thresholdDb: number,
    kneeDb: number,
    ratio: number,
    attackS: number,
    releaseS: number
  ): DynamicsCompressorNode {
    const limiter = this.outputMixContext!.createDynamicsCompressor()
    limiter.threshold.value = thresholdDb
    limiter.knee.value = kneeDb
    limiter.ratio.value = ratio
    limiter.attack.value = attackS
    limiter.release.value = releaseS
    return limiter
  }

  private applyVoiceSeats() {
    const ctx = this.outputMixContext
    if (!ctx) return
    this.voiceSeatOrder = this.voiceSeatOrder.filter(id => this.userPannerNodes.has(id))
    const seats = this.voiceSeatOrder
    const span = Math.max(1, seats.length - 1)
    const now = ctx.currentTime
    seats.forEach((id, index) => {
      const panner = this.userPannerNodes.get(id)
      if (!panner) return
      const position = seats.length < 2 ? 0 : ((index / span) * 2 - 1) * PLAYBACK_VOICE_SPREAD
      panner.pan.cancelScheduledValues(now)
      panner.pan.setTargetAtTime(position, now, PLAYBACK_SEAT_GLIDE_S)
    })
  }

  private async applyVoiceElementSink(el: HTMLAudioElement) {
    const sinkId = this.currentOutputDeviceId === 'default' ? '' : this.currentOutputDeviceId
    const setSinkId = (el as HTMLAudioElement & { setSinkId?: (id: string) => Promise<void> }).setSinkId
    if (typeof setSinkId !== 'function') return
    try {
      await setSinkId.call(el, sinkId)
    } catch {
      if (sinkId !== '') { try { await setSinkId.call(el, '') } catch { } }
    }
  }

  private teardownVoiceGraph(userId: string) {
    try { this.userSourceNodes.get(userId)?.disconnect() } catch { }
    try { this.userGainNodes.get(userId)?.disconnect() } catch { }
    try { this.userLimiterNodes.get(userId)?.disconnect() } catch { }
    try { this.userPannerNodes.get(userId)?.disconnect() } catch { }
    this.userSourceNodes.delete(userId)
    this.userGainNodes.delete(userId)
    this.userLimiterNodes.delete(userId)
    this.userPannerNodes.delete(userId)
  }

  private setupUltraElementPlayout(userId: string, stream: MediaStream) {
    let voicePull = this.audioElements.get(userId)
    if (!voicePull) {
      voicePull = new Audio()
      voicePull.autoplay = true
      this.audioElements.set(userId, voicePull)
    }
    if (voicePull.srcObject !== stream) voicePull.srcObject = stream
    voicePull.muted = true
    void this.applyVoiceElementSink(voicePull)
    void voicePull.play().catch(() => { })

    if (!this.outputMixContext) {
      this.initOutputMixer()
    }

    const track = stream.getAudioTracks()[0]
    if (track && this.outputMixContext && !this.userGainNodes.has(userId)) {
      const source = this.outputMixContext.createMediaStreamSource(new MediaStream([track]))
      const gain = this.outputMixContext.createGain()
      const store = useAppStore.getState()
      const vol = store.userVolumes[userId] ?? 100
      const targetGain = (this.ultraLowLatency && this.ultraCustomHandedOver.has(userId))
        ? 0
        : Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (vol / 100)))
      gain.gain.value = targetGain

      const panner = new StereoPannerNode(this.outputMixContext, { pan: 0 })
      const limiter = this.createPlaybackLimiter(PLAYBACK_VOICE_LIMIT_DB, 2, 20, 0.002, 0.060)
      source.connect(limiter)
      limiter.connect(gain)
      this.userLimiterNodes.set(userId, limiter)
      gain.connect(panner)
      panner.connect(this.outputBusGain!)

      this.userSourceNodes.set(userId, source)
      this.userGainNodes.set(userId, gain)
      this.userPannerNodes.set(userId, panner)
      if (!this.voiceSeatOrder.includes(userId)) this.voiceSeatOrder.push(userId)
      this.applyVoiceSeats()
    }
    this.updateRemoteVolume(userId)
  }

  private findVoiceReceiver(userId: string, trackId: string): RTCRtpReceiver | undefined {
    const pc = this.peerConnections.get(userId)
    if (!pc) return undefined
    return pc.getReceivers().find(r => r.track && r.track.kind === 'audio' && r.track.id === trackId)
  }

  private canUseUltraCustomPlayout(): boolean {
    if (!this.ultraLowLatency) return false
    const g = globalThis as unknown as UltraCodecGlobals
    return typeof g.AudioDecoder === 'function'
      && typeof g.EncodedAudioChunk === 'function'
      && !!this.outputMixContext
  }

  private canSendUltraFrames(): boolean {
    if (!this.ultraLowLatency) return false
    if (this.ultraSendUnsupported) return false
    const g = globalThis as unknown as UltraCodecGlobals
    return typeof g.AudioEncoder === 'function'
      && typeof g.MediaStreamTrackProcessor === 'function'
  }

  private ensureUltraCustomPlayout(userId: string): void {
    if (!this.canUseUltraCustomPlayout()) return
    if (this.ultraCustomFailed.has(userId)) return
    if (this.ultraDecoders.has(userId) || this.ultraCustomEngaging.has(userId)) return
    this.ultraCustomEngaging.add(userId)
    if (!this.ultraReorderBuffers.has(userId)) this.ultraReorderBuffers.set(userId, [])
    if (!this.ultraCustomSpeaking.has(userId)) this.ultraCustomSpeaking.set(userId, { lastSoundAt: 0, speaking: false })
    this.ultraCustomUnderruns.set(userId, 0)
    this.ultraCustomBufferMs.set(userId, 0)
    this.ultraCustomUsers.add(userId)
    void this.engageUltraCustomPlayout(userId).finally(() => this.ultraCustomEngaging.delete(userId))
  }

  private attachUltraDataChannel(userId: string, channel: RTCDataChannel): void {
    try { channel.binaryType = 'arraybuffer' } catch { }
    const previous = this.ultraDataChannels.get(userId)
    if (previous && previous !== channel) {
      try { previous.onopen = previous.onclose = previous.onerror = previous.onmessage = null; previous.close() } catch { }
    }
    this.ultraDataChannels.set(userId, channel)
    const handleOpen = () => {
      if (this.ultraDataChannels.get(userId) !== channel) return
      this.ultraCustomFailed.delete(userId)
      this.ultraCustomFailCount.delete(userId)
      this.ultraHiResends.set(userId, 0)
      if (this.canUseUltraCustomPlayout()) {
        try { channel.send('hi'); this.ultraHiResends.set(userId, 1) } catch { }
      }
    }
    channel.onopen = handleOpen
    channel.onclose = () => {
      if (this.ultraDataChannels.get(userId) === channel) this.ultraDataChannels.delete(userId)
      this.ultraSendTargets.delete(userId)
      if (this.ultraSendTargets.size === 0) this.stopUltraSend()
      this.fallbackUltraCustomPlayout(userId)
    }
    channel.onerror = () => this.fallbackUltraCustomPlayout(userId)
    channel.onmessage = (event: MessageEvent) => this.onUltraChannelMessage(userId, event.data)
    if (channel.readyState === 'open') handleOpen()
  }

  private onUltraChannelMessage(userId: string, data: unknown): void {
    const rcv = this.ultraRcv(userId)
    rcv.msgs++
    if (typeof data === 'string') {
      rcv.str++
      if (data === 'hi') { this.ultraSendTargets.add(userId); this.maybeStartUltraSend() }
      return
    }
    if (data instanceof ArrayBuffer) {
      rcv.bin++
      this.handleUltraBinary(userId, data)
      return
    }
    if (ArrayBuffer.isView(data)) {
      rcv.view++
      const view = data as ArrayBufferView
      this.handleUltraBinary(userId, view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength) as ArrayBuffer)
      return
    }
    if (typeof Blob !== 'undefined' && data instanceof Blob) {
      rcv.blob++
      void data.arrayBuffer().then(buf => this.handleUltraBinary(userId, buf)).catch(() => { })
      return
    }
    rcv.other++
  }

  private handleUltraBinary(userId: string, buffer: ArrayBuffer): void {
    if (buffer.byteLength <= ULTRA_DC_HEADER_BYTES) { this.ultraRcv(userId).sml++; return }
    if (!this.canUseUltraCustomPlayout()) return
    if (!this.ultraSendTargets.has(userId)) { this.ultraSendTargets.add(userId); this.maybeStartUltraSend() }
    this.ensureUltraCustomPlayout(userId)
    const header = new DataView(buffer)
    const timestamp = header.getUint32(0, true)
    const sequenceNumber = header.getUint32(4, true)
    const payload = buffer.slice(ULTRA_DC_HEADER_BYTES)
    this.onUltraEncodedFrame(userId, { timestamp, sequenceNumber, data: payload })
  }

  private ultraRcv(userId: string): { msgs: number; str: number; bin: number; blob: number; view: number; sml: number; other: number } {
    let s = this.ultraRcvStats.get(userId)
    if (!s) { s = { msgs: 0, str: 0, bin: 0, blob: 0, view: 0, sml: 0, other: 0 }; this.ultraRcvStats.set(userId, s) }
    return s
  }

  private ensureUltraOutputContext(): AudioContext | null {
    if (this.ultraOutputContext) {
      if (this.ultraOutputContext.state === 'suspended') this.ultraOutputContext.resume().catch(() => { })
      return this.ultraOutputContext
    }
    let ctx: AudioContext
    try {
      ctx = new AudioContext({ sampleRate: 48000, latencyHint: ULTRA_OUTPUT_LATENCY_HINT_S })
    } catch (e) {
      console.warn('[WebRTC] Failed to create ultraOutputContext at 48000Hz, falling back to default:', e)
      try {
        ctx = new AudioContext({ latencyHint: ULTRA_OUTPUT_LATENCY_HINT_S })
      } catch (err) {
        console.warn('[WebRTC] Failed to create ultraOutputContext:', err)
        return null
      }
    }
    this.ultraOutputContext = ctx
    if (ctx.state === 'suspended') ctx.resume().catch(() => { })
    const bus = ctx.createGain()
    bus.gain.value = this.isDeafened ? 0 : Math.pow(10, PLAYBACK_MAKEUP_GAIN_DB / 20)
    const guard = this.createPeakGuard(ctx, 'none')
    bus.connect(guard)
    guard.connect(ctx.destination)
    this.ultraOutputBusGain = bus
    this.ultraOutputPeakGuard = guard
    void this.applyUltraOutputSink()
    return ctx
  }

  private async applyUltraOutputSink(): Promise<void> {
    const ctx = this.ultraOutputContext as (AudioContext & { setSinkId?: (id: string) => Promise<void> }) | null
    if (!ctx || typeof ctx.setSinkId !== 'function') return
    const sinkId = this.currentOutputDeviceId === 'default' ? '' : this.currentOutputDeviceId
    try {
      await ctx.setSinkId(sinkId)
    } catch (error) {
      console.warn(`[WebRTC] Failed to select output device "${sinkId}" on ultraOutputContext`, error)
    }
  }

  private async engageUltraCustomPlayout(userId: string): Promise<void> {
    const ctx = this.ensureUltraOutputContext()
    const g = globalThis as unknown as UltraCodecGlobals
    const DecoderCtor = g.AudioDecoder
    if (!ctx || ctx.state === 'closed' || !DecoderCtor || !this.ultraCustomUsers.has(userId)) {
      this.fallbackUltraCustomPlayout(userId)
      return
    }

    try {
      if (this.ultraJitterModuleContext !== ctx) {
        if (!this.ultraJitterModulePromise || this.ultraJitterLoadingContext !== ctx) {
          this.ultraJitterLoadingContext = ctx
          this.ultraJitterModulePromise = ctx.audioWorklet.addModule(ultraJitterProcessorUrl).then(() => {
            this.ultraJitterModuleContext = ctx
            this.ultraJitterLoadingContext = null
          }).catch(err => {
            if (this.ultraJitterLoadingContext === ctx) {
              this.ultraJitterLoadingContext = null
              this.ultraJitterModulePromise = null
            }
            if (this.ultraJitterModuleContext === ctx) {
              this.ultraJitterModuleContext = null
            }
            throw err
          })
        }
        await this.ultraJitterModulePromise
      }
      if (!this.ultraLowLatency || !this.ultraCustomUsers.has(userId) || !this.peerConnections.has(userId) || !this.ultraCustomEngaging.has(userId)) {
        this.fallbackUltraCustomPlayout(userId)
        return
      }

      const node = new AudioWorkletNode(ctx, 'ultra-jitter-processor', {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [1]
      })
      const gain = ctx.createGain()
      node.connect(gain)
      gain.connect(this.ultraOutputBusGain ?? ctx.destination)
      node.port.onmessage = (event: MessageEvent<UltraJitterStatsMessage>) => this.onUltraJitterStats(userId, event.data)
      this.ultraJitterNodes.set(userId, node)
      this.ultraJitterGains.set(userId, gain)

      const decoder = new DecoderCtor({
        output: (data) => this.onUltraDecodedAudio(userId, data),
        error: () => this.fallbackUltraCustomPlayout(userId)
      })
      decoder.configure({ codec: 'opus', sampleRate: 48000, numberOfChannels: 1 })
      this.ultraDecoders.set(userId, decoder)

      this.updateUltraCustomGain(userId)
      if (ctx.state === 'suspended') void ctx.resume().catch(() => { })
      this.drainUltraReorder(userId)
    } catch {
      this.fallbackUltraCustomPlayout(userId)
    }
  }

  private drainUltraReorder(userId: string) {
    const pending = this.ultraReorderBuffers.get(userId)
    const decoder = this.ultraDecoders.get(userId)
    if (!pending || !decoder) return
    while (pending.length > ULTRA_REORDER_HOLD) {
      const next = pending.shift()
      if (next) this.decodeUltraChunk(userId, next.timestamp >>> 0, next.data)
    }
  }

  private onUltraEncodedFrame(userId: string, frame: UltraEncodedFrameMessage) {
    const pending = this.ultraReorderBuffers.get(userId)
    if (!pending) return
    this.ultraCustomGotFrame.add(userId)
    pending.push(frame)
    pending.sort((a, b) => ((a.timestamp >>> 0) - (b.timestamp >>> 0)))
    if (!this.ultraDecoders.has(userId)) {
      while (pending.length > ULTRA_PENDING_PREROLL_MAX) pending.shift()
      return
    }
    while (pending.length > ULTRA_REORDER_HOLD) {
      const next = pending.shift()
      if (next) this.decodeUltraChunk(userId, next.timestamp >>> 0, next.data)
    }
  }

  private decodeUltraChunk(userId: string, rtpTimestamp: number, data: ArrayBuffer) {
    const decoder = this.ultraDecoders.get(userId)
    if (!decoder || decoder.state !== 'configured') return
    const g = globalThis as unknown as UltraCodecGlobals
    const ChunkCtor = g.EncodedAudioChunk
    if (!ChunkCtor) return
    const lastTs = this.ultraLastDecodedTs.get(userId)
    if (lastTs !== undefined) {
      const diff = (rtpTimestamp - lastTs) | 0
      if (diff <= 0 && diff > -ULTRA_DC_STALE_WINDOW_SAMPLES) return
    }
    this.ultraLastDecodedTs.set(userId, rtpTimestamp)
    try {
      const timestampUs = Math.round((rtpTimestamp / 48000) * 1e6)
      decoder.decode(new ChunkCtor({ type: 'key', timestamp: timestampUs, data }))
    } catch {
      this.fallbackUltraCustomPlayout(userId)
    }
  }

  private onUltraDecodedAudio(userId: string, data: WebCodecsAudioData) {
    const node = this.ultraJitterNodes.get(userId)
    try {
      const frames = data.numberOfFrames
      const channels = Math.min(2, data.numberOfChannels || 1)
      if (node && frames > 0) {
        if (channels === 1) {
          const mono = new Float32Array(frames)
          data.copyTo(mono, { planeIndex: 0, format: 'f32-planar' })
          this.trackUltraSpeaking(userId, mono)
          node.port.postMessage({ type: 'audio', buffer: mono.buffer, channels: 1 }, [mono.buffer])
        } else {
          const left = new Float32Array(frames)
          const right = new Float32Array(frames)
          data.copyTo(left, { planeIndex: 0, format: 'f32-planar' })
          data.copyTo(right, { planeIndex: 1, format: 'f32-planar' })
          this.trackUltraSpeaking(userId, left)
          const interleaved = new Float32Array(frames * 2)
          for (let i = 0; i < frames; i++) {
            interleaved[i * 2] = left[i]
            interleaved[i * 2 + 1] = right[i]
          }
          node.port.postMessage({ type: 'audio', buffer: interleaved.buffer, channels: 2 }, [interleaved.buffer])
        }
        this.ultraCustomLastAudioAt.set(userId, Date.now())
        this.commitUltraCustomHandover(userId)
      }
    } catch { } finally {
      try { data.close() } catch { }
    }
  }

  private trackUltraSpeaking(userId: string, samples: Float32Array) {
    const state = this.ultraCustomSpeaking.get(userId)
    if (!state) return
    let peak = 0
    for (let i = 0; i < samples.length; i += 2) {
      const magnitude = Math.abs(samples[i])
      if (magnitude > peak) peak = magnitude
    }
    const now = Date.now()
    if (peak > 0.002) state.lastSoundAt = now
    const speaking = now - state.lastSoundAt <= 180
    if (speaking !== state.speaking) {
      state.speaking = speaking
      useAppStore.getState().setSpeakingStatus(userId, speaking)
    }
  }

  private onUltraJitterStats(userId: string, message: UltraJitterStatsMessage) {
    if (!message || message.type !== 'stats') return
    this.ultraCustomBufferMs.set(userId, message.bufferMs ?? 0)
    this.ultraCustomTargetMs.set(userId, message.targetMs ?? 0)
    const total = message.underruns ?? 0
    const previous = this.ultraCustomUnderruns.get(userId) ?? 0
    this.ultraCustomUnderruns.set(userId, total)
    if (total - previous >= ULTRA_CUSTOM_UNDERRUN_FALLBACK) this.fallbackUltraCustomPlayout(userId)
  }

  private commitUltraCustomHandover(userId: string) {
    if (this.ultraCustomHandedOver.has(userId)) return
    this.ultraCustomHandedOver.add(userId)
    this.ultraCustomFailCount.set(userId, 0)
    const el = this.audioElements.get(userId)
    if (el) { try { el.muted = true; el.pause() } catch { } }
    this.clearVAD(userId)
    this.updateRemoteVolume(userId)
  }

  private fallbackUltraCustomPlayout(userId: string) {
    if (!this.ultraCustomUsers.has(userId)) return
    const fails = (this.ultraCustomFailCount.get(userId) ?? 0) + 1
    this.ultraCustomFailCount.set(userId, fails)
    if (fails >= ULTRA_CUSTOM_MAX_FAILURES) this.ultraCustomFailed.add(userId)
    this.teardownUltraCustomPlayout(userId)
    const el = this.audioElements.get(userId)
    const stream = el?.srcObject as MediaStream | null
    const track = stream?.getAudioTracks()[0]
    if (this.ultraLowLatency && stream && track) {
      this.setupUltraElementPlayout(userId, stream)
      this.setupVAD(stream, userId, false)
    }
    this.updateRemoteVolume(userId)
  }

  private teardownUltraCustomPlayout(userId: string) {
    this.ultraCustomEngaging.delete(userId)
    if (!this.ultraCustomUsers.has(userId)
      && !this.ultraJitterNodes.has(userId)
      && !this.ultraDecoders.has(userId)) return

    const decoder = this.ultraDecoders.get(userId)
    if (decoder) { try { if (decoder.state !== 'closed') decoder.close() } catch { } ; this.ultraDecoders.delete(userId) }

    const node = this.ultraJitterNodes.get(userId)
    if (node) {
      try { node.port.onmessage = null; node.port.postMessage({ type: 'reset' }); node.disconnect() } catch { }
      this.ultraJitterNodes.delete(userId)
    }

    const gain = this.ultraJitterGains.get(userId)
    if (gain) {
      try {
        if (this.ultraOutputContext && this.ultraOutputContext.state === 'running') {
          const now = this.ultraOutputContext.currentTime
          gain.gain.cancelScheduledValues(now)
          gain.gain.setValueAtTime(gain.gain.value, now)
          gain.gain.linearRampToValueAtTime(0, now + 0.005)
          setTimeout(() => { try { gain.disconnect() } catch { } }, 10)
        } else {
          gain.disconnect()
        }
      } catch {
        try { gain.disconnect() } catch { }
      }
      this.ultraJitterGains.delete(userId)
    }

    this.ultraReorderBuffers.delete(userId)
    this.ultraLastDecodedTs.delete(userId)
    this.ultraCustomUnderruns.delete(userId)
    this.ultraCustomBufferMs.delete(userId)
    this.ultraCustomTargetMs.delete(userId)
    this.ultraCustomSpeaking.delete(userId)
    this.ultraCustomGotFrame.delete(userId)
    this.ultraCustomHandedOver.delete(userId)
    this.ultraCustomUsers.delete(userId)
  }

  private updateUltraCustomGain(userId: string) {
    const gain = this.ultraJitterGains.get(userId)
    if (!gain) return
    const store = useAppStore.getState()
    const vol = store.userVolumes[userId] ?? 100
    const target = Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (vol / 100)))
    if (this.ultraOutputContext && this.ultraOutputContext.state === 'running') {
      gain.gain.setTargetAtTime(target, this.ultraOutputContext.currentTime, 0.015)
    } else {
      gain.gain.value = target
    }
  }

  public ensureRemoteControlChannel(pc: RTCPeerConnection, userId: string): RTCDataChannel | null {
    if (pc.connectionState === 'closed') return null
    const existing = this.rcDataChannels.get(userId)
    if (existing && (existing.readyState === 'open' || existing.readyState === 'connecting')) return existing
    try {
      const channel = pc.createDataChannel(RC_DC_LABEL, {
        ordered: true,
        negotiated: true,
        id: RC_DC_ID
      })
      this.attachRemoteControlChannel(userId, channel)
      return channel
    } catch (e) {
      console.warn('[WebRTC] Failed to create remote control channel for', userId, e)
      return null
    }
  }

  public ensureRemoteControlChannelForStreamer(streamerId: string): RTCDataChannel | null {
    const pc = this.peerConnections.get(streamerId)
    if (!pc) return null
    return this.ensureRemoteControlChannel(pc, streamerId)
  }

  public attachRemoteControlChannel(userId: string, channel: RTCDataChannel): void {
    try { channel.binaryType = 'arraybuffer' } catch { }
    const previous = this.rcDataChannels.get(userId)
    if (previous && previous !== channel) {
      try {
        previous.onopen = previous.onclose = previous.onerror = previous.onmessage = null
        previous.close()
      } catch { }
    }
    this.rcDataChannels.set(userId, channel)

    channel.onopen = () => {
      const isControlling =
        this.controllingStreamerId === userId ||
        (useAppStore.getState().isRemoteControlling && useAppStore.getState().activeStreamId === userId)
      if (isControlling) {
        try {
          channel.send(RemoteControlProtocol.encodeSignal(RC_OP_START))
        } catch { }
      }
    }

    channel.onclose = () => {
      if (this.rcDataChannels.get(userId) === channel) {
        this.rcDataChannels.delete(userId)
      }
      this.handleRemoteControlDisconnect(userId)
      const pc = this.peerConnections.get(userId)
      if (pc && pc.connectionState !== 'closed' && pc.connectionState !== 'failed') {
        try {
          this.ensureRemoteControlChannel(pc, userId)
        } catch { }
      }
    }

    channel.onerror = (e) => {
      const err = (e as any)?.error
      if (err?.name !== 'OperationError' && !String(err?.message || '').includes('Close called')) {
        console.warn('[WebRTC] Remote control channel error for', userId, e)
      }
      if (channel.readyState === 'closed') {
        this.handleRemoteControlDisconnect(userId)
      }
    }

    channel.onmessage = (event: MessageEvent) => {
      this.onRemoteControlMessage(userId, event.data)
    }
  }

  public requestSenderKeyFrame(): void {
    try {
      for (const pc of this.peerConnections.values()) {
        for (const sender of pc.getSenders()) {
          if (sender.track?.kind === 'video') {
            try {
              (sender as any).generateKeyFrame?.()
            } catch { }
          }
        }
      }
    } catch { }
  }

  public handleRemoteControlDisconnect(userId: string): void {
    if (this.activeRemoteViewerId === userId) {
      this.resetControlState()
      this.activeRemoteViewerId = null
    }
    if (this.controllingStreamerId === userId) {
      this.controllingStreamerId = null
      const st = useAppStore.getState()
      if (st.isRemoteControlling && st.activeStreamId === userId) {
        st.setRemoteControlState({
          isControlling: false,
          isHostActive: false
        })
      }
    }
  }

  public resetControlState(permanent = false): void {
    this.hostControlRevoked = permanent
    try {
      window.windowControls.remoteControlReset()
      window.windowControls.remoteControlShowHostCursor?.()
    } catch { }

    if (this.hostFailSafeTimer) {
      clearTimeout(this.hostFailSafeTimer)
      this.hostFailSafeTimer = null
    }
    if (this.hostIdleTimer) {
      clearTimeout(this.hostIdleTimer)
      this.hostIdleTimer = null
    }

    const previousControllerId = this.activeRemoteViewerId
    this.isHostActive = false
    this.activeRemoteViewerId = null
    if (previousControllerId && this.sfuReadyPeers.has(previousControllerId)) {
      void this.setP2PScreenSenderActiveForPeer(previousControllerId, false)
    }
    try {
      window.windowControls.remoteControlHidePill?.()
    } catch { }

    const st = useAppStore.getState()
    st.setRemoteControlState({
      isHostActive: st.isRemoteControlling ? st.isHostActive : false,
      isRevoked: st.isRemoteControlling ? st.isRemoteControlRevoked : permanent,
      activeControllerId: null
    })

    const signal = permanent ? RC_OP_HOST_REVOKED : RC_OP_RESET
    if (previousControllerId) {
      const ch = this.rcDataChannels.get(previousControllerId)
      if (ch && ch.readyState === 'open') {
        try {
          ch.send(RemoteControlProtocol.encodeSignal(signal))
        } catch { }
      }
    }
  }

  public revokeRemoteControl(): void {
    this.resetControlState(true)
  }

  public startHostRemoteControl(): void {
    try {
      window.windowControls.remoteControlStart()
    } catch { }

    try {
      window.windowControls.remoteControlGetScreen().then((sc) => {
        this.cachedScreenResolution = sc
      }).catch(() => { })
    } catch { }

    if (!this.cleanupHostListeners) {
      const unsubActivity = window.windowControls.onRemoteControlHostActivity(() => {
        this.triggerHostActivity()
      })
      const unsubPanic = window.windowControls.onRemoteControlPanicRevoke(() => {
        this.revokeRemoteControl()
      })

      this.cleanupHostListeners = () => {
        unsubActivity()
        unsubPanic()
      }
    }
  }

  public stopHostRemoteControl(): void {
    this.resetControlState(false)
    this.cachedScreenResolution = null
    try {
      window.windowControls.remoteControlStop()
      window.windowControls.remoteControlShowHostCursor?.()
    } catch { }

    if (this.cleanupHostListeners) {
      this.cleanupHostListeners()
      this.cleanupHostListeners = null
    }
  }

  public triggerHostActivity(): void {
    if (!this.localVideoStream || !this.allowRemoteControl || !this.activeRemoteViewerId) {
      return
    }

    this.isHostActive = true
    try {
      window.windowControls.remoteControlShowHostCursor?.()
    } catch { }

    const targetViewerId = this.activeRemoteViewerId
    const ch = this.rcDataChannels.get(targetViewerId)
    if (ch && ch.readyState === 'open') {
      try {
        ch.send(RemoteControlProtocol.encodeSignal(RC_OP_HOST_ACTIVE))
      } catch { }
    }

    const st = useAppStore.getState()
    st.setRemoteControlState({
      isHostActive: st.isRemoteControlling ? st.isHostActive : true,
      activeControllerId: st.currentUser?.id || null
    })

    if (this.hostIdleTimer) clearTimeout(this.hostIdleTimer)
    this.hostIdleTimer = setTimeout(() => {
      this.isHostActive = false
      if (this.activeRemoteViewerId) {
        try {
          window.windowControls.remoteControlHideHostCursor?.()
        } catch { }
        const activeCh = this.rcDataChannels.get(this.activeRemoteViewerId)
        if (activeCh && activeCh.readyState === 'open') {
          try {
            activeCh.send(RemoteControlProtocol.encodeSignal(RC_OP_HOST_IDLE))
          } catch { }
        }
      }
      const state = useAppStore.getState()
      if (!state.isRemoteControlling) state.setRemoteControlState({ isHostActive: false })
    }, 2000)
  }

  private resolveRemoteUserName(userId: string): string {
    const st = useAppStore.getState()
    const currentChannelId = st.currentChannelId
    const channelMembers = currentChannelId ? st.channelUsersMap[currentChannelId] || [] : []
    const allUsers = [
      ...(st.voiceUsers || []),
      ...(st.friends || []),
      ...channelMembers,
      ...(st.currentCallUser ? [st.currentCallUser] : [])
    ]
    const u = allUsers.find((x) => x?.id === userId)
    return u?.displayName || 'viewer'
  }

  private onRemoteControlMessage(userId: string, data: unknown): void {
    let buffer: ArrayBufferLike | null = null
    if (data instanceof ArrayBuffer) {
      buffer = data
    } else if (ArrayBuffer.isView(data)) {
      buffer = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength)
    }
    if (!buffer || buffer.byteLength === 0) return

    const dv = new DataView(buffer)
    const op = dv.getUint8(0)
    if (op === RC_OP_KEYFRAME_REQUEST) {
      if (this.localVideoStream && this.isPeerRelevant(userId)) void this.refreshVideoSender(userId)
      return
    }
    const isControllingThisUser =
      this.controllingStreamerId === userId ||
      (useAppStore.getState().isRemoteControlling && useAppStore.getState().activeStreamId === userId)
    if ([RC_OP_HOST_ACTIVE, RC_OP_HOST_IDLE, RC_OP_HOST_REVOKED, RC_OP_BUSY].includes(op) && !isControllingThisUser) return

    // 1. Host status signals directed to viewers - ALWAYS handle as viewer updates
    if (op === RC_OP_HOST_ACTIVE) {
      useAppStore.getState().setRemoteControlState({ isHostActive: true })
      return
    }
    if (op === RC_OP_HOST_IDLE) {
      useAppStore.getState().setRemoteControlState({ isHostActive: false })
      return
    }
    if (op === RC_OP_HOST_REVOKED) {
      useAppStore.getState().setRemoteControlState({
        isControlling: false,
        isHostActive: false,
        isRevoked: true
      })
      if (this.controllingStreamerId === userId) {
        this.controllingStreamerId = null
      }
      return
    }
    if (op === RC_OP_BUSY) {
      useAppStore.getState().setRemoteControlState({
        isControlling: false,
        isHostActive: false
      })
      if (this.controllingStreamerId === userId) {
        this.controllingStreamerId = null
      }
      const busyMsg = i18n.t('stream.controlBusy', 'управление сейчас занято')
      useAppStore.getState().setSystemToast?.(busyMsg)
      setTimeout(() => {
        if (useAppStore.getState().systemToast === busyMsg) {
          useAppStore.getState().setSystemToast?.(null)
        }
      }, 3000)
      return
    }

    // 2. Check if we are actively attempting to control or controlling this streamer
    if (isControllingThisUser && (op === RC_OP_ACCEPT || op === RC_OP_START && (this.remoteControlVersions.get(userId) ?? 1) < 2)) {
      // Host has accepted our control request and sent an ACK
      void this.switchViewerToP2PForRemoteControl(userId)
      this.enforceVideoZeroPlayoutDelay(userId)
      return
    }

    if (isControllingThisUser && (op === RC_OP_RESET || op === RC_OP_STOP)) {
      useAppStore.getState().setRemoteControlState({
        isControlling: false,
        isHostActive: false
      })
      if (this.controllingStreamerId === userId) {
        this.controllingStreamerId = null
      }
      this.scheduleStreamViewInterestReport()
      return
    }

    // 3. Host branch: someone wants to control our stream or send input to us
    if (op === RC_OP_START) {
      if (this.controllingStreamerId && useAppStore.getState().isRemoteControlling) {
        const channel = this.rcDataChannels.get(userId)
        if (channel?.readyState === 'open') channel.send(RemoteControlProtocol.encodeSignal(RC_OP_BUSY))
        return
      }
      if (!this.localVideoStream || !this.allowRemoteControl || this.hostControlRevoked) {
        // We do not permit remote control on our stream; reject politely without closing the SCTP data channel!
        const ch = this.rcDataChannels.get(userId)
        if (ch && ch.readyState === 'open') {
          try {
            ch.send(RemoteControlProtocol.encodeSignal(RC_OP_HOST_REVOKED))
          } catch { }
        }
        return
      }

      // Concurrency lock: If another viewer is already controlling, reject this viewer with BUSY
      if (this.activeRemoteViewerId && this.activeRemoteViewerId !== userId) {
        const ch = this.rcDataChannels.get(userId)
        if (ch && ch.readyState === 'open') {
          try {
            ch.send(RemoteControlProtocol.encodeSignal(RC_OP_BUSY))
          } catch { }
        }
        return
      }

      this.activeRemoteViewerId = userId
      this.sfuReadyPeers.delete(userId)
      this.isHostActive = false
      if (this.hostIdleTimer) {
        clearTimeout(this.hostIdleTimer)
        this.hostIdleTimer = null
      }
      this.startHostRemoteControl()
      void this.setP2PScreenSenderActiveForPeer(userId, true)
      this.requestSenderKeyFrame()
      try {
        window.windowControls.remoteControlHideHostCursor?.()
      } catch { }
      const ctrlName = this.resolveRemoteUserName(userId)
      useAppStore.getState().setRemoteControlState({
        activeControllerId: userId,
        isHostActive: false
      })
      try {
        window.windowControls.remoteControlShowPill?.({
          controllerName: ctrlName,
          isControlling: true
        })
      } catch { }
      this.refreshHostFailSafe(userId)
      const ch = this.rcDataChannels.get(userId)
      if (ch && ch.readyState === 'open') {
        try {
          ch.send(RemoteControlProtocol.encodeSignal((this.remoteControlVersions.get(userId) ?? 1) >= 2 ? RC_OP_ACCEPT : RC_OP_START))
        } catch { }
      }
      return
    }

    // For any subsequent input or host controls: verify we are host and allow remote control
    if (!this.localVideoStream || !this.allowRemoteControl) {
      return
    }

    if (op === RC_OP_PING) {
      if (!this.cachedScreenResolution) {
        try {
          window.windowControls.remoteControlGetScreen().then((sc) => {
            this.cachedScreenResolution = sc
          }).catch(() => { })
        } catch { }
      }
      if (this.activeRemoteViewerId === userId) {
        this.refreshHostFailSafe(userId)
      }
      return
    }

    if (op === RC_OP_RESET || op === RC_OP_STOP) {
      if (this.activeRemoteViewerId === userId) {
        this.resetControlState()
      }
      return
    }

    // Concurrency lock for input events
    if (this.activeRemoteViewerId && this.activeRemoteViewerId !== userId) {
      return
    }

    // Physical mouse movement by host takes precedence over remote viewer
    if (this.isHostActive && op !== RC_OP_MOUSE_UP && op !== RC_OP_KEY_UP) return
    if (!this.activeRemoteViewerId || this.hostControlRevoked) return

    const now = Date.now()
    if (now - this.lastHostFailSafeRefresh > 2000) {
      this.lastHostFailSafeRefresh = now
      this.refreshHostFailSafe(userId)
    }

    switch (op) {
      case RC_OP_MOVE: {
        if (buffer.byteLength < 9) break
        const xNorm = dv.getFloat32(1, true)
        const yNorm = dv.getFloat32(5, true)
        if (xNorm >= 0 && xNorm <= 1 && yNorm >= 0 && yNorm <= 1) {
          try {
            window.windowControls.remoteControlMoveNormalized?.(xNorm, yNorm)
          } catch { }
        }
        break
      }
      case RC_OP_MOUSE_DOWN:
      case RC_OP_MOUSE_UP: {
        if (buffer.byteLength < 2) break
        const btn = dv.getUint8(1)
        const isDown = op === RC_OP_MOUSE_DOWN
        try {
          window.windowControls.remoteControlMouseButton(btn, isDown)
        } catch { }
        break
      }
      case RC_OP_WHEEL: {
        if (buffer.byteLength < 5) break
        const deltaY = dv.getInt16(1, true)
        const deltaX = dv.getInt16(3, true)
        try {
          window.windowControls.remoteControlMouseWheel(deltaY, deltaX)
        } catch { }
        break
      }
      case RC_OP_KEY_DOWN:
      case RC_OP_KEY_UP: {
        if (buffer.byteLength < 3) break
        const vk = dv.getUint16(1, true)
        const modifiers = buffer.byteLength >= 4 ? dv.getUint8(3) : 0
        const isDown = op === RC_OP_KEY_DOWN
        const modObj = {
          shift: (modifiers & 1) !== 0,
          ctrl: (modifiers & 2) !== 0,
          alt: (modifiers & 4) !== 0,
          win: (modifiers & 8) !== 0
        }
        if (isShortcutSafe(vk, modObj)) {
          try {
            window.windowControls.remoteControlKey(vk, isDown)
          } catch { }
        }
        break
      }
    }
  }

  private refreshHostFailSafe(userId: string): void {
    if (this.hostFailSafeTimer) clearTimeout(this.hostFailSafeTimer)
    this.hostFailSafeTimer = setTimeout(() => {
      if (this.activeRemoteViewerId === userId) {
        this.resetControlState()
      }
    }, 15000)
  }

  public sendViewerMove(streamerId: string, xNorm: number, yNorm: number): void {
    let ch = this.rcDataChannels.get(streamerId)
    if (!ch || ch.readyState === 'closed') {
      ch = this.ensureRemoteControlChannelForStreamer(streamerId) || undefined
    }
    if (ch && ch.readyState === 'open') {
      if (ch.bufferedAmount > 2048) {
        return
      }
      try {
        ch.send(RemoteControlProtocol.encodeMove(xNorm, yNorm))
      } catch { }
    }
  }

  public sendViewerMouseButton(streamerId: string, button: number, down: boolean): void {
    let ch = this.rcDataChannels.get(streamerId)
    if (!ch || ch.readyState === 'closed') {
      ch = this.ensureRemoteControlChannelForStreamer(streamerId) || undefined
    }
    if (ch && ch.readyState === 'open') {
      try {
        ch.send(RemoteControlProtocol.encodeMouseButton(button, down))
      } catch { }
    }
  }

  public sendViewerMouseWheel(streamerId: string, deltaY: number, deltaX = 0): void {
    let ch = this.rcDataChannels.get(streamerId)
    if (!ch || ch.readyState === 'closed') {
      ch = this.ensureRemoteControlChannelForStreamer(streamerId) || undefined
    }
    if (ch && ch.readyState === 'open') {
      try {
        ch.send(RemoteControlProtocol.encodeMouseWheel(deltaY, deltaX))
      } catch { }
    }
  }

  public sendViewerKey(streamerId: string, vk: number, down: boolean, modifiers = 0): void {
    let ch = this.rcDataChannels.get(streamerId)
    if (!ch || ch.readyState === 'closed') {
      ch = this.ensureRemoteControlChannelForStreamer(streamerId) || undefined
    }
    if (ch && ch.readyState === 'open') {
      try {
        ch.send(RemoteControlProtocol.encodeKey(vk, down, modifiers))
      } catch { }
    }
  }

  public sendViewerSignal(streamerId: string, opcode: number): void {
    if (opcode === RC_OP_START) {
      if (this.activeRemoteViewerId) this.resetControlState()
      this.controllingStreamerId = streamerId
    } else if (opcode === RC_OP_STOP || opcode === RC_OP_RESET) {
      if (this.controllingStreamerId === streamerId) {
        this.controllingStreamerId = null
      }
    }
    let ch = this.rcDataChannels.get(streamerId)
    if (!ch || ch.readyState === 'closed') {
      ch = this.ensureRemoteControlChannelForStreamer(streamerId) || undefined
    }
    if (ch) {
      if (ch.readyState === 'open') {
        try {
          ch.send(RemoteControlProtocol.encodeSignal(opcode))
        } catch { }
      } else if (ch.readyState === 'connecting') {
        const sendOnOpen = () => {
          ch?.removeEventListener('open', sendOnOpen)
          try {
            ch?.send(RemoteControlProtocol.encodeSignal(opcode))
          } catch { }
        }
        ch.addEventListener('open', sendOnOpen)
      }
    }
  }

  private ensureUltraSendChannel(pc: RTCPeerConnection, userId: string): void {
    if (!this.ultraLowLatency) return
    const existing = this.ultraDataChannels.get(userId)
    if (existing && (existing.readyState === 'open' || existing.readyState === 'connecting')) return
    if (!this.canSendUltraFrames() && !this.canUseUltraCustomPlayout()) return
    try {
      const channel = pc.createDataChannel(ULTRA_DC_LABEL, {
        ordered: false,
        maxRetransmits: 0,
        negotiated: true,
        id: ULTRA_DC_ID
      })
      this.attachUltraDataChannel(userId, channel)
    } catch { }
  }

  private acceptUltraChannelFromOffer(pc: RTCPeerConnection, userId: string): void {
    const existing = this.ultraDataChannels.get(userId)
    if (existing && (existing.readyState === 'open' || existing.readyState === 'connecting')) return
    try {
      const channel = pc.createDataChannel(ULTRA_DC_LABEL, {
        ordered: false,
        maxRetransmits: 0,
        negotiated: true,
        id: ULTRA_DC_ID
      })
      this.attachUltraDataChannel(userId, channel)
    } catch { }
  }

  private maybeStartUltraSend(): void {
    if (!this.ultraLowLatency) return
    if (this.ultraSendTargets.size === 0) return
    if (!this.canSendUltraFrames()) return
    if (this.ultraSendEncoder || this.ultraSendStarting) return
    void this.startUltraSend()
  }

  private async startUltraSend(): Promise<void> {
    if (this.ultraSendStarting || this.ultraSendEncoder) return
    const track = this.localStream?.getAudioTracks()[0]
    if (!track || track.readyState !== 'live') return
    const g = globalThis as unknown as UltraCodecGlobals
    const EncoderCtor = g.AudioEncoder
    const ProcessorCtor = g.MediaStreamTrackProcessor
    if (!EncoderCtor || !ProcessorCtor) return
    this.ultraSendStarting = true
    this.ultraSendFrameCount = 0
    this.ultraSentOk = 0
    const generation = ++this.ultraSendGeneration
    try {
      const clone = track.clone()
      this.ultraSendClonedTrack = clone
      this.ultraSendTrackId = track.id
      const processor = new ProcessorCtor({ track: clone })
      const reader = processor.readable.getReader()
      this.ultraSendReader = reader
      const encoder = new EncoderCtor({
        output: (chunk) => this.broadcastUltraFrame(chunk),
        error: (e: unknown) => {
          if (this.ultraSendGeneration !== generation) return
          this.ultraSendLastError = this.ultraErrText(e)
          if (this.ultraSendFrameCount === 0) this.noteUltraSendStartFailure()
          this.stopUltraSend()
        }
      })
      this.ultraSendEncoder = encoder
      encoder.configure({
        codec: 'opus',
        sampleRate: 48000,
        numberOfChannels: 1,
        bitrate: ULTRA_OPUS_BITRATE,
        opus: { frameDuration: ULTRA_DC_OPUS_FRAME_US, useinbandfec: false, usedtx: false, application: 'lowdelay', complexity: 10 }
      })
      this.ultraSendStarting = false
      void this.pumpUltraSend(reader, encoder, generation)
    } catch (e) {
      this.ultraSendStarting = false
      this.ultraSendLastError = this.ultraErrText(e)
      this.noteUltraSendStartFailure()
      this.teardownUltraSendInternals()
    }
  }

  private ultraErrText(e: unknown): string {
    if (e && typeof e === 'object' && 'name' in e) {
      const n = (e as { name?: string }).name ?? 'Error'
      const m = (e as { message?: string }).message ?? ''
      return `${n}:${m}`.replace(/\s+/g, ' ').slice(0, 90)
    }
    return String(e).slice(0, 90)
  }

  private noteUltraSendStartFailure(): void {
    this.ultraSendStartFailures++
    if (this.ultraSendStartFailures >= ULTRA_SEND_MAX_START_FAILURES) this.ultraSendUnsupported = true
  }

  private async pumpUltraSend(
    reader: ReadableStreamDefaultReader<WebCodecsAudioData>,
    encoder: WebCodecsAudioEncoder,
    generation: number
  ): Promise<void> {
    try {
      while (this.ultraSendGeneration === generation) {
        const { value, done } = await reader.read()
        if (done) break
        if (!value) continue
        if (this.ultraSendGeneration !== generation) { try { value.close() } catch { } ; break }
        try {
          if (encoder.state === 'configured') {
            if (value.numberOfChannels === 1) {
              encoder.encode(value)
            } else {
              const mono = this.downmixUltraFrameToMono(value)
              if (mono) { try { encoder.encode(mono) } finally { try { mono.close() } catch { } } }
            }
          }
        } finally {
          try { value.close() } catch { }
        }
      }
    } catch { } finally {
      if (this.ultraSendGeneration === generation) this.stopUltraSend()
    }
  }

  private downmixUltraFrameToMono(value: WebCodecsAudioData): WebCodecsAudioData | null {
    const AudioDataCtor = (globalThis as unknown as UltraCodecGlobals).AudioData
    if (!AudioDataCtor) return null
    try {
      const frames = value.numberOfFrames
      const dst = new Float32Array(frames)
      value.copyTo(dst, { planeIndex: 0, format: 'f32-planar' })
      return new AudioDataCtor({
        format: 'f32-planar',
        sampleRate: value.sampleRate,
        numberOfFrames: frames,
        numberOfChannels: 1,
        timestamp: value.timestamp,
        data: dst
      })
    } catch {
      return null
    }
  }

  private broadcastUltraFrame(chunk: WebCodecsEncodedAudioChunk): void {
    const size = chunk.byteLength
    if (size <= 0) return
    const buffer = new ArrayBuffer(ULTRA_DC_HEADER_BYTES + size)
    const header = new DataView(buffer)
    const rtpTimestamp = Math.round((chunk.timestamp / 1e6) * 48000) >>> 0
    header.setUint32(0, rtpTimestamp, true)
    header.setUint32(4, this.ultraSendSeq++ >>> 0, true)
    chunk.copyTo(new Uint8Array(buffer, ULTRA_DC_HEADER_BYTES))
    this.ultraSendFrameCount++
    if (this.ultraSendFrameCount === 1) { this.ultraSendStartFailures = 0; this.ultraSendLastError = '' }
    for (const [userId, channel] of this.ultraDataChannels) {
      if (!this.ultraSendTargets.has(userId)) continue
      if (channel.readyState !== 'open') continue
      if (channel.bufferedAmount > ULTRA_DC_MAX_BUFFERED_BYTES) continue
      try { channel.send(buffer); this.ultraSentOk++ } catch { }
    }
  }

  private stopUltraSend(): void {
    this.ultraSendGeneration++
    this.teardownUltraSendInternals()
  }

  private teardownUltraSendInternals(): void {
    const reader = this.ultraSendReader
    this.ultraSendReader = null
    if (reader) { try { void reader.cancel() } catch { } }
    const encoder = this.ultraSendEncoder
    this.ultraSendEncoder = null
    if (encoder) { try { if (encoder.state !== 'closed') encoder.close() } catch { } }
    const clone = this.ultraSendClonedTrack
    this.ultraSendClonedTrack = null
    if (clone) { try { clone.stop() } catch { } }
    this.ultraSendTrackId = null
    this.ultraSendStarting = false
  }

  private restartUltraSend(): void {
    this.stopUltraSend()
    this.maybeStartUltraSend()
  }

  private setupVoicePlayout(userId: string, stream: MediaStream, track: MediaStreamTrack, receiver?: RTCRtpReceiver) {
    let voicePull = this.audioElements.get(userId)
    if (!voicePull) {
      voicePull = new Audio()
      voicePull.autoplay = true
      this.audioElements.set(userId, voicePull)
    }
    if (voicePull.srcObject !== stream) voicePull.srcObject = stream

    this.teardownVoiceGraph(userId)

    if (this.ultraLowLatency) {
      const channel = this.ultraDataChannels.get(userId)
      if (channel && channel.readyState === 'open') this.ensureUltraCustomPlayout(userId)
    } else {
      this.teardownUltraCustomPlayout(userId)
    }

    if (!this.outputMixContext) {
      this.initOutputMixer()
    }
    if (!this.outputMixContext) return

    voicePull.muted = true
    void this.applyVoiceElementSink(voicePull)
    void voicePull.play().catch(() => { })

    const source = this.outputMixContext.createMediaStreamSource(new MediaStream([track]))
    const gain = this.outputMixContext.createGain()
    const store = useAppStore.getState()
    const vol = store.userVolumes[userId] ?? 100
    const targetGain = (this.ultraLowLatency && this.ultraCustomHandedOver.has(userId))
      ? 0
      : Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (vol / 100)))
    gain.gain.value = targetGain

    const panner = new StereoPannerNode(this.outputMixContext, { pan: 0 })
    const limiter = this.createPlaybackLimiter(PLAYBACK_VOICE_LIMIT_DB, 2, 20, 0.002, 0.060)
    source.connect(limiter)
    limiter.connect(gain)
    this.userLimiterNodes.set(userId, limiter)
    gain.connect(panner)
    panner.connect(this.outputBusGain!)

    this.userSourceNodes.set(userId, source)
    this.userGainNodes.set(userId, gain)
    this.userPannerNodes.set(userId, panner)
    if (!this.voiceSeatOrder.includes(userId)) this.voiceSeatOrder.push(userId)
    this.updateRemoteVolume(userId)
    this.applyVoiceSeats()

    if (this.ultraLowLatency && this.ultraCustomHandedOver.has(userId)) {
      const el = this.audioElements.get(userId)
      if (el) { try { el.muted = true; el.pause() } catch { } }
    }
  }

  public softRefreshRemoteAudio(userId: string) {
    if (!this.outputMixContext || this.outputMixContext.state === 'closed') return
    if (this.outputMixContext.state === 'suspended') {
      void this.outputMixContext.resume().catch(() => { })
    }

    const pc = this.peerConnections.get(userId)
    if (!pc || (pc.connectionState !== 'connected' && pc.iceConnectionState !== 'connected' && pc.iceConnectionState !== 'completed')) {
      return
    }

    const voiceTrackId = this.userVoiceTrackIds.get(userId)
    if (!voiceTrackId) return
    const receiver = pc.getReceivers().find(r => r.track && r.track.kind === 'audio' && r.track.id === voiceTrackId)
    const track = receiver?.track
    if (!track || track.readyState !== 'live') return

    const nowRefresh = performance.now()
    const lastRefreshAt = this.lastSoftRefreshAt.get(userId) ?? 0
    if (nowRefresh - lastRefreshAt < WebRTCManager.SOFT_REFRESH_COOLDOWN_MS) return
    this.lastSoftRefreshAt.set(userId, nowRefresh)

    if (this.ultraLowLatency && !this.userGainNodes.has(userId)) {
      const el = this.audioElements.get(userId)
      if (el) {
        el.muted = true
        try { el.srcObject = new MediaStream([track]) } catch { }
        void el.play().catch(() => { })
      }
      this.setupVoicePlayout(userId, new MediaStream([track]), track, receiver)
      return
    }

    const destination = this.userLimiterNodes.get(userId) ?? this.userGainNodes.get(userId)
    if (!destination) return

    const oldSource = this.userSourceNodes.get(userId)
    if (oldSource) {
      try { oldSource.disconnect() } catch { }
    }

    try {
      const newSource = this.outputMixContext.createMediaStreamSource(new MediaStream([track]))
      newSource.connect(destination)
      this.userSourceNodes.set(userId, newSource)
    } catch (e) {
      console.warn(`[WebRTC] Failed to soft-refresh remote audio for peer ${userId}`, e)
    }
  }

  private checkRenegotiationHealth(userId: string, pc: RTCPeerConnection) {
    if (pc.connectionState === 'closed' || pc.connectionState === 'failed') {
      this.renegotiationStuckSince.delete(userId)
      return
    }

    if (pc.signalingState === 'stable') {
      this.renegotiationStuckSince.delete(userId)
      if (this.pendingRenegotiation.has(userId) && !this.isMakingOffer.get(userId)) {
        this.flushPendingRenegotiation(userId)
      }
      return
    }

    const now = performance.now()
    const stuckSince = this.renegotiationStuckSince.get(userId)
    if (stuckSince === undefined) {
      this.renegotiationStuckSince.set(userId, now)
      return
    }

    if (now - stuckSince < WebRTCManager.RENEGOTIATION_STUCK_MS) return
    if (this.isMakingOffer.get(userId) || this.isSettingRemoteAnswerPending.get(userId)) return

    this.renegotiationStuckSince.delete(userId)
    void (async () => {
      try {
        if (pc.signalingState === 'have-local-offer') {
          await pc.setLocalDescription({ type: 'rollback' })
        }
      } catch { }
      const current = this.peerConnections.get(userId)
      if (current !== pc || pc.signalingState !== 'stable') return
      this.pendingRenegotiation.add(userId)
      this.flushPendingRenegotiation(userId)
    })()
  }

  private startAudioHealthMonitoring() {
    if (this.audioHealthInterval) return
    this.audioHealthInterval = setInterval(async () => {
      if (this.mediaHealthInFlight) return
      this.mediaHealthInFlight = true
      try {
      if (this.peerConnections.size === 0 && this.sfuSubConnections.size === 0) return
      if (this.outputMixContext?.state === 'suspended') {
        void this.outputMixContext.resume().catch(() => { })
      }
      if (this.ultraOutputContext?.state === 'suspended') {
        void this.ultraOutputContext.resume().catch(() => { })
      }

      if (this.ultraLowLatency) {
        const now = Date.now()
        for (const [uid, ch] of this.ultraDataChannels) {
          if (ch.readyState !== 'open') continue
          if (this.canUseUltraCustomPlayout() && !this.ultraCustomGotFrame.has(uid) && !this.ultraCustomFailed.has(uid)) {
            const sent = this.ultraHiResends.get(uid) ?? 0
            if (sent < ULTRA_HI_MAX_RESENDS) {
              try { ch.send('hi') } catch { }
              this.ultraHiResends.set(uid, sent + 1)
            }
          }
        }
        for (const uid of [...this.ultraCustomHandedOver]) {
          const last = this.ultraCustomLastAudioAt.get(uid) ?? 0
          if (now - last > ULTRA_CUSTOM_AUDIO_DROUGHT_MS) this.fallbackUltraCustomPlayout(uid)
        }
        if (this.ultraSendTargets.size > 0 && !this.ultraSendEncoder && !this.ultraSendStarting && this.canSendUltraFrames()) {
          this.maybeStartUltraSend()
        }
      }

      for (const [userId, pc] of this.peerConnections.entries()) {
        if (this.allowRemoteControl) {
          this.ensureRemoteControlChannel(pc, userId)
        }
        this.checkRenegotiationHealth(userId, pc)
        if (pc.connectionState !== 'connected') continue
        try {
          const stats = await pc.getStats()
          if (this.peerConnections.get(userId) !== pc) continue
          this.checkMediaHealth(userId, pc, 'p2p', stats)
          let rttMs = 0
          let networkRoute = 'unknown'
          let transport = 'unknown'
          stats.forEach(report => {
            if (report.type === 'candidate-pair' && (report.nominated || report.selected) && typeof report.currentRoundTripTime === 'number') {
              rttMs = report.currentRoundTripTime * 1000
              const local = stats.get(report.localCandidateId)
              const remote = stats.get(report.remoteCandidateId)
              networkRoute = local?.candidateType === 'relay' || remote?.candidateType === 'relay' ? 'turn' : 'p2p'
              transport = local?.protocol === 'udp' || local?.protocol === 'tcp' ? local.protocol : 'unknown'
            }
          })
          if (this.ultraLowLatency && rttMs > 0) this.ultraRttMs.set(userId, rttMs)
          let audioBytes = 0
          let audioPackets = 0
          let audioLost = 0
          let audioConcealed = 0
          stats.forEach(report => {
            if (report.type === 'inbound-rtp' && report.kind === 'audio') {
              if (report.trackIdentifier && this.userVoiceTrackIds.get(userId) && report.trackIdentifier !== this.userVoiceTrackIds.get(userId)) return
              const concealed = report.concealedSamples || 0
              audioBytes = report.bytesReceived ?? 0
              audioPackets = report.packetsReceived ?? 0
              audioLost = report.packetsLost ?? 0
              audioConcealed = concealed
              const prevConcealed = this.lastAudioConcealment.get(userId) ?? concealed
              this.lastAudioConcealment.set(userId, concealed)

              const lastPacketTime = report.lastPacketReceivedTimestamp || 0
              const prevPacketTime = this.lastAudioPacketTimes.get(userId) ?? lastPacketTime
              this.lastAudioPacketTimes.set(userId, lastPacketTime)

              if (this.ultraLowLatency) {
                const totalSamples = report.totalSamplesReceived || 0
                if (totalSamples > 0) this.ultraConcealRate.set(userId, Math.max(0, Math.min(1, concealed / totalSamples)))
                const concealBurst = concealed - prevConcealed > ULTRA_CONCEAL_BUMP_SAMPLES
                this.updateUltraJitterTarget(userId, report.jitter || 0, concealBurst)
                this.maybeAdaptUltraFrame(userId, pc, report.packetsLost || 0, report.packetsReceived || 0, rttMs)
              }

              if (!this.ultraCustomUsers.has(userId)) {
                if (lastPacketTime > 0 && prevPacketTime > 0 && (lastPacketTime - prevPacketTime > 3000)) {
                  this.softRefreshRemoteAudio(userId)
                } else if (concealed - prevConcealed > 4800) {
                  this.softRefreshRemoteAudio(userId)
                }
              }
            }
          })
          let connection = this.diagnosticConnections.get(pc)
          if (!connection) { connection = ++this.nextDiagnosticConnection; this.diagnosticConnections.set(pc, connection) }
          logDiagnostic({ event: 'media', mediaKind: 'audio', route: 'p2p', networkRoute, transport, connection, bytes: audioBytes, packets: audioPackets, lost: audioLost, concealed: audioConcealed, rttMs, ultra: this.ultraLowLatency, muted: Boolean(useAppStore.getState().currentUser?.isMuted), deafened: this.isDeafened })
        } catch { }
      }
      for (const [userId, pc] of this.sfuSubConnections) {
        if (pc.connectionState !== 'connected') continue
        try {
          const stats = await pc.getStats()
          if (this.sfuSubConnections.get(userId) === pc) this.checkMediaHealth(userId, pc, 'sfu', stats)
        } catch {}
      }
      } finally { this.mediaHealthInFlight = false }
    }, 2500)
  }

  private stopAudioHealthMonitoring() {
    this.mediaHealth.reset()
    this.keyframeRequestedAt.clear()
    if (this.audioHealthInterval) {
      clearInterval(this.audioHealthInterval)
      this.audioHealthInterval = null
    }
    this.lastAudioPacketTimes.clear()
    this.lastAudioConcealment.clear()
    this.ultraJitterTargetMs.clear()
    this.lastInboundLoss.clear()
    this.lastInboundReceived.clear()
    this.renegotiationStuckSince.clear()
    this.rollbackCount.clear()
    this.ultraRttMs.clear()
    this.ultraConcealRate.clear()
    this.ultraConcealBurstMs.clear()
    this.ultraFrameLossTicks.clear()
    this.peerLastSettledState.clear()
    this.lastSoftRefreshAt.clear()
  }

  public getUltraLatencyStats(): { rttMs: number; concealmentRate: number; jitterTargetMs: number; frameMs: number } | null {
    if (!this.ultraLowLatency || this.ultraRttMs.size === 0) return null
    let rttMs = 0
    for (const value of this.ultraRttMs.values()) rttMs = Math.max(rttMs, value)
    let concealmentRate = 0
    for (const value of this.ultraConcealRate.values()) concealmentRate = Math.max(concealmentRate, value)
    let jitterTargetMs = 0
    for (const value of this.ultraJitterTargetMs.values()) jitterTargetMs = Math.max(jitterTargetMs, value)
    let frameMs = ULTRA_FRAME_MS_SAFE
    for (const value of this.ultraFrameMs.values()) frameMs = Math.min(frameMs, value)
    return { rttMs, concealmentRate, jitterTargetMs, frameMs }
  }

  private checkMediaHealth(userId: string, pc: RTCPeerConnection, route: 'p2p' | 'sfu', stats: RTCStatsReport): void {
    const store = useAppStore.getState()
    if (store.activeStreamId !== userId) return
    const user = store.voiceUsers.find(user => user.id === userId) || (store.currentCallUser?.id === userId ? store.currentCallUser : null)
    if (!user?.isStreaming) return
    const currentPc = route === 'sfu' ? this.sfuSubConnections.get(userId) : this.peerConnections.get(userId)
    if (currentPc !== pc) return
    const displayedTrack = store.remoteVideoStreams[userId]?.getVideoTracks()[0]
    if (displayedTrack?.readyState === 'live' && !displayedTrack.enabled) return
    if (displayedTrack?.readyState === 'live' && !pc.getReceivers().some(receiver => receiver.track === displayedTrack)) return
    if (!displayedTrack && route === 'p2p' && this.sfuSubConnections.has(userId)) return
    const track = this.findRemoteVideoReceiver(pc, displayedTrack)?.track
    let frames = 0
    let bytes = 0
    let packets = 0
    let lost = 0
    stats.forEach(report => {
      if (report.type !== 'inbound-rtp' || report.kind !== 'video' || !track || report.trackIdentifier && report.trackIdentifier !== track.id) return
      if (typeof report.framesDecoded === 'number') frames = report.framesDecoded
      bytes = report.bytesReceived ?? 0
      packets = report.packetsReceived ?? 0
      lost = report.packetsLost ?? 0
    })
    let connection = this.diagnosticConnections.get(pc)
    if (!connection) { connection = ++this.nextDiagnosticConnection; this.diagnosticConnections.set(pc, connection) }
    logDiagnostic({ event: 'media', mediaKind: 'video', connection, route, frames, bytes, packets, lost, ultra: this.ultraLowLatency })
    const action = this.mediaHealth.observe(`${connection}:${track?.id ?? 'pending'}`, frames, performance.now())
    if (action === 'keyframe') {
      logDiagnostic({ event: 'recovery', connection, route, reason: 'keyframe' })
      if (route === 'sfu') void signalRService.sfuRequestKeyframe(userId)
      else this.sendViewerSignal(userId, RC_OP_KEYFRAME_REQUEST)
    } else if (action === 'recover') {
      logDiagnostic({ event: 'recovery', connection, route, reason: 'video-stall' })
      if (route === 'sfu') {
        const epoch = this.sfuSubEpochs.get(userId)
        if (epoch !== undefined) void signalRService.sfuReportFailure(userId, epoch)
        void this.switchViewerFromSfuToP2P(userId)
      } else void this.renegotiatePeer(pc, userId, true)
    }
  }

  private async refreshVideoSender(userId: string): Promise<void> {
    const now = performance.now()
    if (now - (this.keyframeRequestedAt.get(userId) ?? -5000) < 3000) return
    this.keyframeRequestedAt.set(userId, now)
    const pc = this.peerConnections.get(userId)
    const sender = pc?.getSenders().find(sender => sender.track?.kind === 'video')
    if (!sender) return
    const track = sender.track
    try {
      const params = sender.getParameters()
      if (!params.encodings?.length || params.encodings[0].active === false) return
      params.encodings[0].active = false
      await sender.setParameters(params)
    } catch {}
    finally {
      if (sender.track === track && track?.readyState === 'live' && (!this.sfuReadyPeers.has(userId) || this.activeRemoteViewerId === userId || this.sfuFallbackPeers.has(userId))) {
        try {
          const restored = sender.getParameters()
          if (restored.encodings?.length) {
            restored.encodings[0].active = true
            await sender.setParameters(restored)
          }
        } catch { void this.renegotiatePeer(pc!, userId) }
      }
    }
  }

  private attachRemoteVideo(userId: string, track: MediaStreamTrack, stream?: MediaStream, isSfu = false) {
    if (track.readyState === 'ended') return
    const videoStream = new MediaStream([track])
    const isControlling = useAppStore.getState().isRemoteControlling && this.controllingStreamerId === userId
    if (!isSfu) {
      if (stream) this.userScreenStreamIds.set(userId, stream.id)
      this.p2pStreamsBackup.set(userId, videoStream)
      if (!isControlling && this.sfuSubConnections.has(userId) && useAppStore.getState().remoteVideoStreams[userId]) {
        return
      }
    } else if (isControlling && this.p2pStreamsBackup.has(userId)) {
      // Keep direct ultra-low latency P2P video stream when actively controlling
      return
    }
    const currentStream = useAppStore.getState().remoteVideoStreams[userId]
    if (currentStream && currentStream.getVideoTracks().includes(track)) return

    useAppStore.getState().setRemoteVideoStream(userId, videoStream)
    track.onended = () => {
      const active = useAppStore.getState().remoteVideoStreams[userId]
      if (active && active.getVideoTracks().includes(track)) {
        this.cleanupRemoteStream(userId)
      }
    }
  }

  private attachRemoteStreamAudio(userId: string, track: MediaStreamTrack, receiver?: RTCRtpReceiver, stream?: MediaStream, isSfu = false) {
    if (track.readyState === 'ended') return
    const audioStream = (stream && stream.getAudioTracks().some(t => t === track || t.id === track.id))
      ? stream
      : new MediaStream([track])
    if (!isSfu) {
      this.p2pAudioBackup.set(userId, { track, receiver, stream: audioStream })
      if (this.sfuSubConnections.has(userId) && this.userStreamAudioTrackIds.has(userId)) {
        return
      }
    }
    if (this.userStreamAudioTrackIds.get(userId) === track.id && this.streamSourceNodes.has(userId)) return

    this.initOutputMixer()
    this.userStreamAudioTrackIds.set(userId, track.id)
    const streamId = stream?.id || (track as any).streamId
    if (streamId) this.userScreenStreamIds.set(userId, streamId)
    if (receiver) this.isolateReceiverLatency(receiver)
    track.onended = () => {
      if (this.userStreamAudioTrackIds.get(userId) === track.id) {
        this.cleanupRemoteStreamAudio(userId)
      }
    }
    track.contentHint = 'music'

    let streamPull = this.streamAudioElements.get(userId)
    if (!streamPull) {
      streamPull = new Audio()
      streamPull.autoplay = true
      streamPull.muted = true
      this.streamAudioElements.set(userId, streamPull)
    }
    streamPull.srcObject = audioStream
    void streamPull.play().catch(() => { })

    if (this.streamSourceNodes.has(userId)) {
      try { this.streamSourceNodes.get(userId)?.disconnect() } catch { }
      try { this.streamDelayNodes.get(userId)?.disconnect() } catch { }
      try { this.streamGainNodes.get(userId)?.disconnect() } catch { }
      try { this.streamLimiterNodes.get(userId)?.disconnect() } catch { }
    }

    let source: MediaStreamAudioSourceNode
    try {
      source = this.outputMixContext!.createMediaStreamSource(audioStream)
    } catch {
      const fallbackStream = new MediaStream([track])
      streamPull.srcObject = fallbackStream
      source = this.outputMixContext!.createMediaStreamSource(fallbackStream)
    }
    ;(source as any)._mediaStream = audioStream
    const delay = new DelayNode(this.outputMixContext!, { maxDelayTime: 1.0, delayTime: 0 })
    const gain = this.outputMixContext!.createGain()
    const limiter = this.createPlaybackLimiter(PLAYBACK_STREAM_LIMIT_DB, 2, 20, 0.002, 0.080)
    source.connect(delay)
    delay.connect(limiter)
    limiter.connect(gain)
    gain.connect(this.outputBusGain!)

    this.streamSourceNodes.set(userId, source)
    this.streamDelayNodes.set(userId, delay)
    this.streamGainNodes.set(userId, gain)
    this.streamLimiterNodes.set(userId, limiter)
    this.streamSyncOffsetEma.delete(userId)
    this.streamSyncSkew.delete(userId)
    this.updateRemoteStreamVolume(userId)
    this.startStreamSyncMonitoring()
  }

  private findRemoteVideoReceiver(pc: RTCPeerConnection, preferredTrack?: MediaStreamTrack): RTCRtpReceiver | undefined {
    let selected: RTCRtpReceiver | undefined
    let selectedScore = -1
    for (const transceiver of pc.getTransceivers()) {
      const track = transceiver.receiver.track
      if (transceiver.stopped || track.kind !== 'video' || track.readyState !== 'live') continue
      if (transceiver.currentDirection !== 'recvonly' && transceiver.currentDirection !== 'sendrecv') continue
      const score = (track.muted ? 0 : 2) + (track === preferredTrack ? 1 : 0)
      if (score > selectedScore) {
        selected = transceiver.receiver
        selectedScore = score
      }
    }
    return selected
  }

  public syncRemoteVideoStream(userId: string): void {
    const store = useAppStore.getState()
    const user = store.voiceUsers.find(u => u.id === userId) || (store.currentCallUser?.id === userId ? store.currentCallUser : null)
    const isUserStreaming = Boolean(user?.isStreaming)
    if (isUserStreaming) {
      this.reportedViewStates.delete(userId)
      this.scheduleStreamViewInterestReport(60)
    }

    const sfuPc = this.sfuSubConnections.get(userId)
    if (sfuPc && sfuPc.connectionState !== 'closed') {
      for (const receiver of sfuPc.getReceivers()) {
        if (receiver.track && receiver.track.kind === 'video' && receiver.track.readyState !== 'ended') {
          this.applyVideoZeroPlayoutDelay(receiver)
        }
      }
      const sfuAudioReceiver = sfuPc.getReceivers().find(r => r.track && r.track.kind === 'audio' && r.track.readyState !== 'ended')
      if (sfuAudioReceiver?.track) {
        if (!sfuAudioReceiver.track.onunmute) {
          sfuAudioReceiver.track.onunmute = () => {
            this.syncRemoteVideoStream(userId)
          }
        }
        const isActiveStream = store.activeStreamId === userId
        if (isUserStreaming || isActiveStream || !sfuAudioReceiver.track.muted) {
          if (this.userStreamAudioTrackIds.get(userId) !== sfuAudioReceiver.track.id || !this.streamSourceNodes.has(userId)) {
            this.attachRemoteStreamAudio(userId, sfuAudioReceiver.track, sfuAudioReceiver, undefined, true)
          }
        }
        if (isActiveStream) {
          if (this.outputMixContext?.state === 'suspended') {
            void this.outputMixContext.resume().catch(() => { })
          }
          const streamPull = this.streamAudioElements.get(userId)
          if (streamPull && streamPull.paused) {
            void streamPull.play().catch(() => { })
          }
        }
      }
    }

    const pc = this.peerConnections.get(userId)
    if (!pc || pc.connectionState === 'closed') return

    for (const receiver of pc.getReceivers()) {
      const track = receiver.track
      if (track && track.kind === 'video' && track.readyState !== 'ended') {
        this.applyVideoZeroPlayoutDelay(receiver)
        if (!track.onunmute) {
          track.onunmute = () => {
            if (this.peerConnections.get(userId) === pc) this.syncRemoteVideoStream(userId)
          }
        }
      }
    }

    const preferredTrack = store.remoteVideoStreams[userId]?.getVideoTracks()[0]
    const videoReceiver = this.findRemoteVideoReceiver(pc, preferredTrack)
    if (videoReceiver && (isUserStreaming || !videoReceiver.track.muted)) {
      this.attachRemoteVideo(userId, videoReceiver.track)
    }

    const audioReceivers = pc.getReceivers().filter(r => r.track && r.track.kind === 'audio')
    if (audioReceivers.length > 0 && !this.userVoiceTrackIds.has(userId) && audioReceivers[0].track) {
      this.userVoiceTrackIds.set(userId, audioReceivers[0].track.id)
    }

    if (audioReceivers.length >= 2) {
      const knownVoiceTrackId = this.userVoiceTrackIds.get(userId)
      const screenAudioReceiver = audioReceivers.find(r => r.track && r.track.id !== knownVoiceTrackId && r !== audioReceivers[0] && r.track.readyState !== 'ended') || (audioReceivers[1].track?.readyState !== 'ended' ? audioReceivers[1] : null)
      if (screenAudioReceiver?.track) {
        if (!screenAudioReceiver.track.onunmute) {
          screenAudioReceiver.track.onunmute = () => {
            this.syncRemoteVideoStream(userId)
          }
        }
        const isActiveStream = store.activeStreamId === userId
        if (isUserStreaming || isActiveStream || !screenAudioReceiver.track.muted) {
          if (this.userStreamAudioTrackIds.get(userId) !== screenAudioReceiver.track.id || !this.streamSourceNodes.has(userId)) {
            this.attachRemoteStreamAudio(userId, screenAudioReceiver.track, screenAudioReceiver)
          }
        }
        if (isActiveStream) {
          if (this.outputMixContext?.state === 'suspended') {
            void this.outputMixContext.resume().catch(() => { })
          }
          const streamPull = this.streamAudioElements.get(userId)
          if (streamPull && streamPull.paused) {
            void streamPull.play().catch(() => { })
          }
        }
      }
    } else if (audioReceivers.length === 1) {
      if (!this.sfuSubConnections.has(userId) && this.userStreamAudioTrackIds.get(userId) === audioReceivers[0].track?.id) {
        this.cleanupRemoteStreamAudio(userId)
      }
    }
  }

  private setupPeerHandlers(pc: RTCPeerConnection, userId: string) {
    try {
      pc.getTransceivers().forEach(transceiver => {
        const track = transceiver.receiver.track
        if (track && track.kind === 'video') {
          this.applyVideoZeroPlayoutDelay(transceiver.receiver)
          track.onunmute = () => {
            if (this.peerConnections.get(userId) === pc) this.syncRemoteVideoStream(userId)
          }
        }
      })
    } catch { }

    pc.ontrack = (event) => {
      if (this.peerConnections.get(userId) !== pc) return
      if (userId === useAppStore.getState().currentUser?.id) {
        event.track.stop()
        this.disconnectFromPeer(userId)
        return
      }
      const stream = event.streams[0] || new MediaStream([event.track])
      this.initOutputMixer()

      if (event.track.kind === 'video') {
        event.track.onunmute = () => {
          if (this.peerConnections.get(userId) === pc) this.syncRemoteVideoStream(userId)
        }
        if (event.receiver) {
          this.applyVideoZeroPlayoutDelay(event.receiver)
        }
        this.attachRemoteVideo(userId, event.track, stream)
        return
      }

      const knownVoiceTrackId = this.userVoiceTrackIds.get(userId)
      const knownStreamAudioTrackId = this.userStreamAudioTrackIds.get(userId)

      const streamId = event.streams[0]?.id
      const remoteVideoStream = useAppStore.getState().remoteVideoStreams[userId]
      const streamHasVideo = (event.streams[0]?.getVideoTracks().length ?? 0) > 0
      const matchesScreenStream = Boolean(
        streamId && (
          streamHasVideo ||
          (remoteVideoStream && streamId === remoteVideoStream.id) ||
          streamId === this.userScreenStreamIds.get(userId)
        )
      )

      const eventReceiver = event.receiver || pc.getReceivers().find(r => r.track === event.track)
      const audioReceivers = pc.getReceivers().filter(r => r.track && r.track.kind === 'audio')
      const isFirstAudioReceiver = Boolean(eventReceiver && audioReceivers.length > 0 && eventReceiver === audioReceivers[0])
      const isSecondAudioReceiver = Boolean(eventReceiver && audioReceivers.length > 1 && eventReceiver === audioReceivers[1])

      let isScreenShareAudio = false
      if (matchesScreenStream || isSecondAudioReceiver) {
        isScreenShareAudio = true
      } else if (isFirstAudioReceiver || (knownVoiceTrackId && event.track.id === knownVoiceTrackId)) {
        isScreenShareAudio = false
      } else if (knownStreamAudioTrackId && event.track.id === knownStreamAudioTrackId) {
        isScreenShareAudio = true
      } else {
        isScreenShareAudio = false
      }

      if (isScreenShareAudio) {
        this.attachRemoteStreamAudio(userId, event.track, event.receiver, stream)
      } else {
        this.userVoiceTrackIds.set(userId, event.track.id)
        if (streamId) this.userVoiceStreamIds.set(userId, streamId)
        event.track.onended = () => {
          if (this.userVoiceTrackIds.get(userId) === event.track.id) {
            this.userVoiceTrackIds.delete(userId)
            this.teardownVoiceGraph(userId)
          }
        }
        event.track.contentHint = 'speech'
        let voiceReceiver: RTCRtpReceiver | undefined
        try {
          voiceReceiver = pc.getReceivers().find(r => r.track && r.track.id === event.track.id)
          if (voiceReceiver) this.applyReceiverLatency(voiceReceiver)
        } catch { }
        this.setupVAD(stream, userId, false)
        this.setupVoicePlayout(userId, stream, event.track, voiceReceiver)
      }
    }

    pc.ondatachannel = (event) => {
      if (event.channel.label === RC_DC_LABEL || event.channel.id === RC_DC_ID) {
        this.attachRemoteControlChannel(userId, event.channel)
      }
    }
    this.ensureRemoteControlChannel(pc, userId)

    pc.onicecandidate = (e) => {
      if (!e.candidate) return
      if (this.relayOnlyIce) {
        const cand = e.candidate.candidate || ''
        if (!cand.includes('typ relay')) return
      }
      signalRService.sendIceCandidate(userId, JSON.stringify(e.candidate))
    }

    const checkState = () => {
      if (this.peerConnections.get(userId) !== pc) return
      const st = pc.connectionState
      const iceSt = pc.iceConnectionState
      logDiagnostic({ event: 'connection', state: st, route: 'p2p' })

      if (st === 'connected' || iceSt === 'connected' || iceSt === 'completed') {
        const startedAt = this.peerConnectStartedAt.get(userId)
        if (startedAt !== undefined) {
          this.peerConnectStartedAt.delete(userId)
          const elapsed = Math.round(performance.now() - startedAt)
          void pc.getStats().then(stats => {
            let pair = ''
            stats.forEach(report => {
              if (report.type !== 'candidate-pair' || !report.selected && report.state !== 'succeeded') return
              const local = stats.get(report.localCandidateId)
              const remote = stats.get(report.remoteCandidateId)
              if (local && remote) pair = `${local.candidateType}/${local.protocol} -> ${remote.candidateType}/${remote.protocol}`
            })
            console.log(`[WebRTC] peer ${userId} connected in ${elapsed}ms${pair ? ` via ${pair}` : ''}`)
          }).catch(() => console.log(`[WebRTC] peer ${userId} connected in ${elapsed}ms`))
        }
        useAppStore.getState().setWebRTCConnectionStatus(userId, true)
        this.syncRemoteVideoStream(userId)
        this.clearIceTimeout(userId)
        this.retryCount.delete(userId)
        const dcTimer = this.dcTimers.get(userId)
        if (dcTimer) {
          clearTimeout(dcTimer)
          this.dcTimers.delete(userId)
        }
        this.ultraCustomFailed.delete(userId)
        this.ultraCustomFailCount.delete(userId)
        const prevSettled = this.peerLastSettledState.get(userId)
        if (this.userSourceNodes.has(userId) && (prevSettled === 'disconnected' || prevSettled === 'failed')) {
          this.softRefreshRemoteAudio(userId)
        }
        this.peerLastSettledState.set(userId, 'connected')
        if (this.ultraLowLatency && this.canUseUltraCustomPlayout()) {
          const channel = this.ultraDataChannels.get(userId)
          if (channel && channel.readyState === 'open') {
            try { channel.send('hi'); this.ultraHiResends.set(userId, 1) } catch { }
            this.ensureUltraCustomPlayout(userId)
          }
        }
      } else if (st === 'failed' || iceSt === 'failed') {
        this.peerLastSettledState.set(userId, 'failed')
        useAppStore.getState().setWebRTCConnectionStatus(userId, false)
        void this.attemptRenegotiation(userId)
      } else if (st === 'disconnected' || iceSt === 'disconnected') {
        this.peerLastSettledState.set(userId, 'disconnected')
        useAppStore.getState().setWebRTCConnectionStatus(userId, false)
        const existingTimer = this.dcTimers.get(userId)
        if (!existingTimer) {
          const grace = this.ultraLowLatency ? 1500 : WebRTCManager.DISCONNECTED_GRACE_MS
          const t = setTimeout(() => {
            if (pc.connectionState === 'disconnected' || pc.iceConnectionState === 'disconnected') {
              void this.attemptRenegotiation(userId)
            }
            this.dcTimers.delete(userId)
          }, grace)
          this.dcTimers.set(userId, t)
        }
      } else {
        useAppStore.getState().setWebRTCConnectionStatus(userId, false)
      }
    }

    pc.onconnectionstatechange = checkState
    pc.oniceconnectionstatechange = checkState
  }

  private startIceTimeout(userId: string, timeoutMs = WebRTCManager.ICE_TIMEOUT_MS) {
    this.clearIceTimeout(userId)
    const timer = setTimeout(() => {
      this.iceTimeoutTimers.delete(userId)
      const pc = this.peerConnections.get(userId)
      if (pc && pc.connectionState !== 'connected') {
        void this.attemptRenegotiation(userId)
      }
    }, timeoutMs)
    this.iceTimeoutTimers.set(userId, timer)
  }

  private clearIceTimeout(userId: string) {
    const t = this.iceTimeoutTimers.get(userId)
    if (t) { clearTimeout(t); this.iceTimeoutTimers.delete(userId) }
  }

  private async attemptRenegotiation(userId: string) {
    if (this.iceRestartInFlight.has(userId)) return

    const pc = this.peerConnections.get(userId)
    if (!pc || pc.connectionState === 'closed') return

    const me = useAppStore.getState().currentUser?.id
    if (!me) return

    this.iceRestartInFlight.add(userId)
    try {
      const count = this.retryCount.get(userId) ?? 0

      if (me > userId && count === 0) {
        this.retryCount.set(userId, 1)
        this.startIceTimeout(userId, WebRTCManager.FAST_ICE_TIE_BREAK_MS)
        return
      }

      if (count < WebRTCManager.MAX_ICE_RETRIES) {
        this.retryCount.set(userId, count + 1)
        await this.renegotiatePeer(pc, userId, true)
        this.startIceTimeout(userId)
        return
      }

      this.disconnectFromPeer(userId, { preserveRemoteVideo: true, preserveRetryState: true })
      this.retryCount.set(userId, 0)
      await this.connectToPeer(userId, true)
    } finally {
      this.iceRestartInFlight.delete(userId)
    }
  }

  public updateRemoteStreamVolume(userId: string) {
    const store = useAppStore.getState()
    const isActive = store.activeStreamId === userId
    const vol = isActive ? (store.streamVolumes[userId] ?? 100) : 0

    if (isActive) {
      if (this.outputMixContext?.state === 'suspended') {
        void this.outputMixContext.resume().catch(() => { })
      }
      const streamPull = this.streamAudioElements.get(userId)
      if (streamPull && streamPull.paused) {
        void streamPull.play().catch(() => { })
      }
      if (!this.streamSourceNodes.has(userId) || !this.streamGainNodes.has(userId)) {
        this.syncRemoteVideoStream(userId)
      }
    }

    const gainNode = this.streamGainNodes.get(userId)
    if (gainNode) {
      const targetGain = Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (vol / 100)))
      if (this.outputMixContext && this.outputMixContext.state === 'running') {
        try {
          gainNode.gain.setTargetAtTime(targetGain, this.outputMixContext.currentTime, 0.015)
        } catch {
          gainNode.gain.value = targetGain
        }
      } else {
        gainNode.gain.value = targetGain
      }
    }
  }

  public setStreamVolumeRealtime(userId: string, volume: number) {
    const store = useAppStore.getState()
    const isActive = store.activeStreamId === userId
    const gainNode = this.streamGainNodes.get(userId)
    if (gainNode) {
      const vol = isActive ? volume : 0
      gainNode.gain.value = Math.max(0, Math.min(4.0, (this.outputVolume / 100) * (Math.max(0, Math.min(200, vol)) / 100)))
    }
  }

  private async startIsolatedStreamAudio(sourceId: string): Promise<MediaStreamTrack> {
    const generation = this.screenShareGeneration
    this.stopIsolatedStreamAudio()

    const context = new AudioContext({ sampleRate: 48000, latencyHint: 'interactive' })
    if (context.sampleRate !== 48000) {
      await context.close().catch(() => { })
      throw new Error(`Stream audio requires 48000Hz, got ${context.sampleRate}Hz`)
    }

    try {
      await context.audioWorklet.addModule(playbackBufferProcessorUrl)
      if (generation !== this.screenShareGeneration) throw new DOMException('Screen share cancelled', 'AbortError')
      const node = new AudioWorkletNode(context, 'playback-buffer-processor', {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [2]
      })
      const destination = context.createMediaStreamDestination()
      node.connect(destination)

      this.streamCaptureContext = context
      this.streamCaptureNode = node
      this.streamCaptureDestination = destination
      this.removeStreamAudioListener = window.windowControls.onStreamAudioData((data, metadata) => {
        if (metadata.sampleRate !== 48000 || metadata.bitsPerSample !== 32 || !metadata.isFloat) {
          console.warn('[WebRTC] Unsupported native stream audio format:', metadata)
          return
        }

        const copy = new Uint8Array(data.byteLength)
        copy.set(data)
        node.port.postMessage({
          type: 'audio',
          buffer: copy.buffer,
          channels: metadata.channels
        }, [copy.buffer])
      })

      await window.windowControls.startStreamAudioCapture(sourceId)
      if (generation !== this.screenShareGeneration) {
        await window.windowControls.stopStreamAudioCapture().catch(() => {})
        throw new DOMException('Screen share cancelled', 'AbortError')
      }
      if (context.state === 'suspended') await context.resume()

      const track = destination.stream.getAudioTracks()[0]
      if (!track) throw new Error('Native stream audio track was not created')
      track.contentHint = 'music'
      return track
    } catch (error) {
      this.stopIsolatedStreamAudio()
      if (context.state !== 'closed') await context.close().catch(() => {})
      throw error
    }
  }

  private stopIsolatedStreamAudio() {
    const wasCapturing = this.removeStreamAudioListener !== null
    if (this.removeStreamAudioListener) {
      try { this.removeStreamAudioListener() } catch { }
      this.removeStreamAudioListener = null
    }

    if (wasCapturing) {
      try { void window.windowControls.stopStreamAudioCapture().catch(() => { }) } catch { }
    }
    if (this.streamCaptureNode) {
      try { this.streamCaptureNode.disconnect() } catch { }
      this.streamCaptureNode = null
    }
    if (this.streamCaptureDestination) {
      try {
        this.streamCaptureDestination.stream.getTracks().forEach(track => {
          try {
            track.enabled = false
            track.stop()
          } catch { }
        })
      } catch { }
      this.streamCaptureDestination = null
    }
    if (this.streamCaptureContext && this.streamCaptureContext.state !== 'closed') {
      try { this.streamCaptureContext.close().catch(() => { }) } catch { }
    }
    this.streamCaptureContext = null
  }

  public async startScreenShare(
    sourceId: string,
    quality: 'high' | 'medium' | 'low' | 'camera',
    includeAudio: boolean,
    allowRemoteControl = false
  ) {
    allowRemoteControl = allowRemoteControl && !sourceId.startsWith('camera:') && quality !== 'camera'
    const previousStart = this.screenShareStartPromise
    if (this.localVideoStream || this.isStartingScreenShare || previousStart) this.stopScreenShare()
    else this.screenShareGeneration++
    const generation = this.screenShareGeneration
    const operation = this.startScreenShareOperation(sourceId, quality, includeAudio, allowRemoteControl, generation, previousStart)
    this.screenShareStartPromise = operation
    try {
      return await operation
    } finally {
      if (this.screenShareStartPromise === operation) this.screenShareStartPromise = null
    }
  }

  private async startScreenShareOperation(
    sourceId: string,
    quality: 'high' | 'medium' | 'low' | 'camera',
    includeAudio: boolean,
    allowRemoteControl: boolean,
    generation: number,
    previousStart: Promise<unknown> | null
  ) {
    if (previousStart) await previousStart.catch(() => {})
    const assertCurrent = () => {
      if (generation !== this.screenShareGeneration) throw new DOMException('Screen share cancelled', 'AbortError')
    }
    assertCurrent()
    if (this.localVideoStream) {
      throw new Error('Screen share is already active')
    }
    this.allowRemoteControl = allowRemoteControl
    this.hostControlRevoked = false
    useAppStore.getState().setRemoteControlState({ isRevoked: false })
    if (allowRemoteControl) {
      this.startHostRemoteControl()
    }
    this.currentStreamQuality = quality
    const savedViewerStates = new Map(this.viewerStates)
    const savedPendingSfu = this.pendingSfuPublish ?? (this.sfuPubEpoch > 0 ? { epoch: this.sfuPubEpoch, nodeId: '' } : null)
    const wasSfuActive = this.sfuPubActive
    this.isStartingScreenShare = true
    this.viewerStates = savedViewerStates
    if (!this.pendingSfuPublish && savedPendingSfu) {
      this.pendingSfuPublish = savedPendingSfu
    }
    if (wasSfuActive) {
      this.sfuPubActive = true
    }
    const width = quality === 'high' ? 1920 : 1280
    const height = quality === 'high' ? 1080 : 720
    const frameRate = (quality === 'high' || quality === 'medium') ? 60 : 30

    try {
      let constraints: MediaStreamConstraints
      const isCamera = sourceId.startsWith('camera:')

      if (isCamera) {
        const deviceId = sourceId.slice(7)
        constraints = {
          video: {
            deviceId: deviceId ? { exact: deviceId } : undefined
          },
          audio: false
        }
      } else {
        constraints = {
          video: {
            mandatory: {
              chromeMediaSource: 'desktop',
              chromeMediaSourceId: sourceId,
              maxWidth: width,
              maxHeight: height,
              maxFrameRate: frameRate,
              minFrameRate: frameRate
            }
          } as any
        }
      }

      let stream: MediaStream | null = null

      if (!isCamera && typeof navigator !== 'undefined' && navigator.mediaDevices?.getDisplayMedia) {
        try {
          await window.windowControls?.setDisplayMediaSource?.(sourceId)
          assertCurrent()
          stream = await navigator.mediaDevices.getDisplayMedia({
            video: {
              cursor: allowRemoteControl ? 'never' : 'always',
              width: { ideal: width, max: width },
              height: { ideal: height, max: height },
              frameRate: { ideal: frameRate, max: frameRate }
            } as any,
            audio: false
          })
        } catch (e) {
          assertCurrent()
          console.warn('[ScreenShare] getDisplayMedia with constraints failed, retrying simple getDisplayMedia:', e)
          try {
            await window.windowControls?.setDisplayMediaSource?.(sourceId)
            assertCurrent()
            stream = await navigator.mediaDevices.getDisplayMedia({
              video: true,
              audio: false
            })
          } catch (e2) {
            assertCurrent()
            console.warn('[ScreenShare] simple getDisplayMedia also failed:', e2)
          }
        }
      }

      if (!stream) {
        assertCurrent()
        try {
          stream = await navigator.mediaDevices.getUserMedia(constraints)
        } catch (err) {
          if (constraints.audio) {
            delete constraints.audio
            stream = await navigator.mediaDevices.getUserMedia(constraints)
          } else {
            throw err
          }
        }
      }

      if (!stream) {
        throw new Error('Failed to acquire stream')
      }
      if (generation !== this.screenShareGeneration) {
        stream.getTracks().forEach(track => track.stop())
        assertCurrent()
      }

      this.localVideoStream = stream
      const videoTrack = stream.getVideoTracks()[0]
      if (videoTrack) {
        const settings = videoTrack.getSettings()
        logDiagnostic({ event: 'capture', state: 'active', sourceKind: isCamera ? 'camera' : sourceId.startsWith('window:') ? 'window' : 'screen', width: settings.width ?? 0, height: settings.height ?? 0, generation })
      }
      let audioTrack: MediaStreamTrack | undefined
      if (includeAudio && !isCamera) {
        try {
          audioTrack = await this.startIsolatedStreamAudio(sourceId)
          assertCurrent()
          if (audioTrack) stream.addTrack(audioTrack)
        } catch (audioError) {
          assertCurrent()
          console.warn('[WebRTC] Stream audio capture failed, continuing without audio:', audioError)
        }
      }

      if (videoTrack) {
        videoTrack.contentHint = 'motion'
        videoTrack.onended = () => {
          if (this.localVideoStream === stream && !this.isStartingScreenShare) {
            const st = useAppStore.getState()
            const myId = st.currentUser?.id
            if (myId) {
              if (st.activeStreamId === myId) {
                st.setActiveStreamId(null)
                if (st.isStreamFullscreen) st.setStreamFullscreen(false)
              }
              st.updateUserStatus(myId, { isStreaming: false, streamQuality: undefined })
            }
            this.stopScreenShare()
            void signalRService.stopStream()
          }
        }
      }

      for (const [userId, pc] of this.peerConnections.entries()) {
        assertCurrent()
        if (pc.connectionState === 'closed') continue
        if (this.allowRemoteControl) {
          this.ensureRemoteControlChannel(pc, userId)
        }
        const isController = this.allowRemoteControl && this.activeRemoteViewerId === userId
        const keepP2PActive = !this.sfuReadyPeers.has(userId) || this.sfuFallbackPeers.has(userId) || isController
        if (videoTrack) {
          const videoTransceiver = pc.getTransceivers().find(t => t.receiver.track.kind === 'video' && !t.stopped)
          let sender: RTCRtpSender
          if (videoTransceiver) {
            videoTransceiver.direction = 'sendrecv'
            await videoTransceiver.sender.replaceTrack(videoTrack)
            try {
              (videoTransceiver.sender as any).setStreams(stream)
            } catch { }
            sender = videoTransceiver.sender
          } else {
            sender = pc.addTrack(videoTrack, stream)
          }
          try {
            const params = sender.getParameters()
            if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
            if (!isCamera) {
              params.degradationPreference = 'maintain-framerate'
              const isHigh = quality === 'high'
              const isMedium = quality === 'medium'
              params.encodings[0].maxBitrate = isHigh ? 6000000 : (isMedium ? 3500000 : 2500000)
              params.encodings[0].maxFramerate = (isHigh || isMedium) ? 60 : 30
              params.encodings[0].networkPriority = 'high'
            }
            params.encodings[0].active = keepP2PActive
            sender.setParameters(params).catch(() => { })
          } catch { }
        }
        if (audioTrack) {
          const audioTransceivers = pc.getTransceivers().filter(t => t.receiver.track.kind === 'audio' && !t.stopped)
          const screenAudioTransceiver = audioTransceivers.length > 1 ? audioTransceivers[1] : null
          let aSender: RTCRtpSender
          if (screenAudioTransceiver) {
            screenAudioTransceiver.direction = 'sendrecv'
            await screenAudioTransceiver.sender.replaceTrack(audioTrack)
            try {
              (screenAudioTransceiver.sender as any).setStreams(stream)
            } catch { }
            aSender = screenAudioTransceiver.sender
          } else {
            aSender = pc.addTrack(audioTrack, stream)
          }
          this.configureAudioSender(aSender)
          if (!keepP2PActive) {
            try {
              const params = aSender.getParameters()
              if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
              params.encodings[0].active = false
              aSender.setParameters(params).catch(() => { })
            } catch { }
          }
        }
        await this.renegotiatePeer(pc, userId)
      }

      this.isStartingScreenShare = false
      assertCurrent()
      if (this.pendingSfuPublish) {
        const pending = this.pendingSfuPublish
        void this.handleSfuPublishRequired(pending.epoch, pending.nodeId)
      }
      this.startStatsMonitoring()
      return true
    } catch (e) {
      if (generation === this.screenShareGeneration) {
        this.isStartingScreenShare = false
        this.stopScreenShare()
      }
      throw e
    }
  }

  public async restoreLocalVideoStream(streamQuality?: string): Promise<void> {
    const stream = this.localVideoStream
    if (!stream) return
    const isLive = stream.getTracks().some(t => t.readyState === 'live')
    if (!isLive) return

    const quality = (streamQuality ?? this.currentStreamQuality ?? 'medium') as any
    this.currentStreamQuality = quality
    const videoTrack = stream.getVideoTracks()[0]
    const micTrack = this.localStream?.getAudioTracks()[0]
    const audioTrack = stream.getAudioTracks().find(t => t !== micTrack)
    const isCamera = quality === 'camera'

    for (const [userId, pc] of this.peerConnections.entries()) {
      if (pc.connectionState === 'closed') continue
      if (this.allowRemoteControl) {
        this.ensureRemoteControlChannel(pc, userId)
      }
      const isController = this.allowRemoteControl && this.activeRemoteViewerId === userId
      const keepP2PActive = !this.sfuReadyPeers.has(userId) || this.sfuFallbackPeers.has(userId) || isController

      if (videoTrack) {
        const videoTransceiver = pc.getTransceivers().find(t => t.receiver.track.kind === 'video' && !t.stopped)
        let sender: RTCRtpSender
        if (videoTransceiver) {
          videoTransceiver.direction = 'sendrecv'
          await videoTransceiver.sender.replaceTrack(videoTrack).catch(() => { })
          try {
            (videoTransceiver.sender as any).setStreams(stream)
          } catch { }
          sender = videoTransceiver.sender
        } else {
          sender = pc.addTrack(videoTrack, stream)
        }
        try {
          const params = sender.getParameters()
          if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
          if (!isCamera) {
            params.degradationPreference = 'maintain-framerate'
            const isHigh = quality === 'high'
            const isMedium = quality === 'medium'
            params.encodings[0].maxBitrate = isHigh ? 6000000 : (isMedium ? 3500000 : 2500000)
            params.encodings[0].maxFramerate = (isHigh || isMedium) ? 60 : 30
            params.encodings[0].networkPriority = 'high'
          }
          params.encodings[0].active = keepP2PActive
          sender.setParameters(params).catch(() => { })
        } catch { }
      }

      if (audioTrack) {
        const audioTransceivers = pc.getTransceivers().filter(t => t.receiver.track.kind === 'audio' && !t.stopped)
        const screenAudioTransceiver = audioTransceivers.length > 1 ? audioTransceivers[1] : null
        let aSender: RTCRtpSender
        if (screenAudioTransceiver) {
          screenAudioTransceiver.direction = 'sendrecv'
          await screenAudioTransceiver.sender.replaceTrack(audioTrack).catch(() => { })
          try {
            (screenAudioTransceiver.sender as any).setStreams(stream)
          } catch { }
          aSender = screenAudioTransceiver.sender
        } else {
          aSender = pc.addTrack(audioTrack, stream)
        }
        this.configureAudioSender(aSender)
        if (!keepP2PActive) {
          try {
            const params = aSender.getParameters()
            if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
            params.encodings[0].active = false
            aSender.setParameters(params).catch(() => { })
          } catch { }
        }
      }

      await this.renegotiatePeer(pc, userId)
    }

    if (this.pendingSfuPublish) {
      const pending = this.pendingSfuPublish
      void this.handleSfuPublishRequired(pending.epoch, pending.nodeId)
    }
  }

  public async recoverMesh(peerIds: string[]): Promise<void> {
    const me = useAppStore.getState().currentUser?.id
    if (!me) return

    for (const peerId of peerIds) {
      if (peerId === me) continue
      const pc = this.peerConnections.get(peerId)
      if (
        !pc ||
        pc.connectionState === 'closed' ||
        pc.connectionState === 'failed' ||
        pc.connectionState === 'disconnected' ||
        pc.iceConnectionState === 'closed' ||
        pc.iceConnectionState === 'failed'
      ) {
        this.disconnectFromPeer(peerId, { preserveRemoteVideo: true, preserveRetryState: true })
        void this.connectToPeer(peerId, true)
      } else {
        if (pc.signalingState === 'have-local-offer') {
          try {
            await pc.setLocalDescription({ type: 'rollback' })
          } catch { }
        }
        void this.renegotiatePeer(pc, peerId, true)
      }
    }
  }

  public stopScreenShare() {
    this.screenShareGeneration++
    this.isStartingScreenShare = false
    if (this.statsInterval) {
      clearInterval(this.statsInterval)
      this.statsInterval = null
    }

    if (!this.isStartingScreenShare) {
      this.pendingSfuPublish = null
      this.sfuFallbackPeers.clear()
    }
    this.closeSfuPublisher()

    const localVideo = this.localVideoStream
    const videoTracks = localVideo ? localVideo.getVideoTracks() : []
    const screenAudioTracks = localVideo ? localVideo.getAudioTracks().filter(t => t !== this.localStream?.getAudioTracks()[0]) : []

    for (const [userId, pc] of this.peerConnections.entries()) {
      try {
        const transceivers = pc.getTransceivers()
        const audioTransceivers = transceivers.filter(t => t.receiver.track.kind === 'audio' && !t.stopped)
        for (const t of transceivers) {
          if (t.stopped) continue
          const track = t.sender.track
          const isScreenVideo = t.receiver.track.kind === 'video' || (track && track.kind === 'video') || (track && videoTracks.includes(track))
          const isScreenAudio = (audioTransceivers.length > 1 && audioTransceivers[1] === t) || (track && track.kind === 'audio' && track !== this.localStream?.getAudioTracks()[0]) || (track && screenAudioTracks.includes(track))
          if (isScreenVideo || isScreenAudio) {
            try { void t.sender.replaceTrack(null) } catch { }
            t.direction = 'recvonly'
          }
        }
        void this.renegotiatePeer(pc, userId)
      } catch { }
    }

    if (this.localVideoStream) {
      try {
        this.localVideoStream.getTracks().forEach(track => {
          try {
            track.onended = null
            track.enabled = false
            track.stop()
          } catch { }
        })
      } catch { }
      this.localVideoStream = null
    }

    this.stopIsolatedStreamAudio()

    this.lastPacketsLost.clear()
    this.lastPacketsSent.clear()
    this.lastFramesDropped.clear()
    this.lossLadderStep.clear()
    this.lossBreachCount.clear()
    this.lossCleanCount.clear()
    this.lossBaselineRtt.clear()
    this.appliedVideoProfiles.clear()
    this.viewerStates.clear()

    if (this.allowRemoteControl) {
      this.stopHostRemoteControl()
      this.allowRemoteControl = false
    }
    useAppStore.getState().setStreamRemoteControlAllowed(false)
  }

  private async renegotiatePeer(pc: RTCPeerConnection, userId: string, iceRestart = false): Promise<void> {
    return this.enqueueSignalingTask(userId, async () => {
      if (this.peerConnections.get(userId) !== pc || pc.signalingState === 'closed' || pc.connectionState === 'closed') {
        this.pendingRenegotiation.delete(userId)
        this.pendingIceRestart.delete(userId)
        return
      }
      if (pc.signalingState !== 'stable' || this.isMakingOffer.get(userId)) {
        this.pendingRenegotiation.add(userId)
        if (iceRestart) this.pendingIceRestart.add(userId)
        return
      }
      if (!signalRService.isConnected() || !signalRService.isSessionReady()) {
        this.pendingRenegotiation.add(userId)
        if (iceRestart) this.pendingIceRestart.add(userId)
        return
      }
      this.pendingRenegotiation.delete(userId)
      const needsIceRestart = iceRestart || this.pendingIceRestart.has(userId)
      this.isMakingOffer.set(userId, true)
      try {
        this.ensureUltraSendChannel(pc, userId)
        const offer = await pc.createOffer(
          needsIceRestart ? SILENCE_SUPPRESSION_OFF_WITH_ICE_RESTART : SILENCE_SUPPRESSION_OFF
        )
        if (this.peerConnections.get(userId) !== pc || (pc.signalingState as RTCSignalingState) === 'closed' || (pc.connectionState as RTCPeerConnectionState) === 'closed') {
          this.pendingRenegotiation.delete(userId)
          this.pendingIceRestart.delete(userId)
          return
        }
        if (pc.signalingState !== 'stable') {
          this.pendingRenegotiation.add(userId)
          if (needsIceRestart) this.pendingIceRestart.add(userId)
          return
        }
        const isRemoteControl = Boolean(
          this.allowRemoteControl ||
          this.rcDataChannels.has(userId) ||
          useAppStore.getState().isRemoteControlling ||
          this.activeRemoteViewerId === userId
        )
        const optimizedSDP = optimizeSDP(offer.sdp!, this.relayOnlyIce, this.ultraLowLatency, this.ultraPtimeFor(userId), isRemoteControl)
        if (!signalRService.isConnected() || !signalRService.isSessionReady()) {
          this.pendingRenegotiation.add(userId)
          if (needsIceRestart) this.pendingIceRestart.add(userId)
          return
        }
        await pc.setLocalDescription({ type: 'offer', sdp: optimizedSDP })
        const offerEpoch = (this.offerEpoch.get(userId) ?? 0) + 1
        this.offerEpoch.set(userId, offerEpoch)
        signalRService.sendWebRTCOffer(userId, JSON.stringify({ type: pc.localDescription!.type, sdp: pc.localDescription!.sdp, epoch: offerEpoch, allowRemoteControl: this.allowRemoteControl, remoteControlProtocol: 2 }))
        this.pendingIceRestart.delete(userId)
      } catch (e) {
        console.error('[WebRTC] renegotiation failed', e)
      } finally {
        this.isMakingOffer.set(userId, false)
      }
    })
  }

  private flushPendingRenegotiation(userId: string) {
    if (!this.pendingRenegotiation.has(userId)) return
    const pc = this.peerConnections.get(userId)
    if (!pc || pc.signalingState !== 'stable' || this.isMakingOffer.get(userId)) return
    this.pendingRenegotiation.delete(userId)
    void this.renegotiatePeer(pc, userId)
  }

  private async recoverRejectedAnswer(userId: string, pc: RTCPeerConnection): Promise<void> {
    if (this.peerConnections.get(userId) !== pc || pc.connectionState === 'closed') {
      void this.attemptRenegotiation(userId)
      return
    }
    if (pc.signalingState !== 'have-local-offer') return
    const attempts = (this.rollbackCount.get(userId) ?? 0) + 1
    this.rollbackCount.set(userId, attempts)
    if (attempts > WebRTCManager.MAX_ROLLBACKS) {
      this.rollbackCount.delete(userId)
      void this.attemptRenegotiation(userId)
      return
    }
    try {
      await pc.setLocalDescription({ type: 'rollback' })
    } catch {
      void this.attemptRenegotiation(userId)
      return
    }
    this.isMakingOffer.set(userId, false)
    this.renegotiationStuckSince.delete(userId)
    this.pendingRenegotiation.add(userId)
    void this.renegotiatePeer(pc, userId)
  }

  private static readonly SYNC_DEADBAND_S = 0.025
  private static readonly SYNC_MAX_AUDIO_DELAY_S = 0.5
  private static readonly SYNC_EMA_ALPHA = 0.15
  private static readonly SYNC_CORRECTION_GAIN = 0.5
  private static readonly SYNC_MAX_DELAY_STEP_S = 0.015
  private static readonly SYNC_DELAY_RAMP_S = 1.5

  private static readonly VIDEO_JITTER_MIN_MS = 60
  private static readonly VIDEO_JITTER_MAX_MS = 600
  private static readonly VIDEO_JITTER_HEADROOM_MS = 60
  private static readonly VIDEO_JITTER_FACTOR = 3
  private static readonly VIDEO_JITTER_LOSS_MS = 500
  private static readonly VIDEO_JITTER_FREEZE_MS = 300
  private static readonly VIDEO_JITTER_ATTACK = 0.7
  private static readonly VIDEO_JITTER_RELEASE = 0.04
  private static readonly VIDEO_JITTER_RC_MS = 25

  private startStreamSyncMonitoring() {
    if (this.streamSyncInterval) return
    this.streamSyncInterval = setInterval(() => {
      void this.runStreamSyncTick()
    }, 1000)
  }

  private stopStreamSyncMonitoring() {
    if (!this.streamSyncInterval) return
    clearInterval(this.streamSyncInterval)
    this.streamSyncInterval = null
    this.streamSyncOffsetEma.clear()
    this.streamSyncSkew.clear()
    this.videoJitterTargetMs.clear()
    this.lastVideoPacketsLost.clear()
    this.lastVideoPacketsReceived.clear()
    this.lastVideoFreezeCount.clear()
  }

  private measureAudioVideoOffset(stats: RTCStatsReport): number | null {
    let audioPlayout = Number.NaN
    let videoPlayout = Number.NaN
    let audioJitter = Number.NaN
    let videoJitter = Number.NaN

    stats.forEach(report => {
      if (report.type !== 'inbound-rtp') return
      const emitted = report.jitterBufferEmittedCount
      const jitterDelay = typeof report.jitterBufferDelay === 'number' && typeof emitted === 'number' && emitted > 0
        ? report.jitterBufferDelay / emitted
        : Number.NaN
      if (report.kind === 'audio') {
        if (typeof report.estimatedPlayoutTimestamp === 'number') audioPlayout = report.estimatedPlayoutTimestamp
        audioJitter = jitterDelay
      } else if (report.kind === 'video') {
        if (typeof report.estimatedPlayoutTimestamp === 'number') videoPlayout = report.estimatedPlayoutTimestamp
        videoJitter = jitterDelay
      }
    })

    if (Number.isFinite(audioPlayout) && Number.isFinite(videoPlayout)) {
      return (audioPlayout - videoPlayout) / 1000
    }
    if (Number.isFinite(audioJitter) && Number.isFinite(videoJitter)) {
      return videoJitter - audioJitter
    }
    return null
  }

  private async runStreamSyncTick() {
    if (this.streamGainNodes.size === 0) {
      this.stopStreamSyncMonitoring()
      return
    }

    const ctx = this.outputMixContext
    if (!ctx) return

    for (const userId of this.streamGainNodes.keys()) {
      const pc = this.sfuSubConnections.get(userId) ?? this.peerConnections.get(userId)
      const delayNode = this.streamDelayNodes.get(userId)
      if (!pc || !delayNode || pc.connectionState !== 'connected') continue

      try {
        const stats = await pc.getStats()
        if (!this.streamGainNodes.has(userId) || this.streamDelayNodes.get(userId) !== delayNode) continue
        const rawOffset = this.measureAudioVideoOffset(stats)
        if (rawOffset === null || !Number.isFinite(rawOffset)) continue

        const clampedOffset = Math.max(-0.5, Math.min(0.5, rawOffset))
        const previousEma = this.streamSyncOffsetEma.get(userId)
        const smoothed = previousEma === undefined
          ? clampedOffset
          : previousEma + WebRTCManager.SYNC_EMA_ALPHA * (clampedOffset - previousEma)
        this.streamSyncOffsetEma.set(userId, smoothed)

        let skew = this.streamSyncSkew.get(userId) ?? 0
        if (Math.abs(smoothed) > WebRTCManager.SYNC_DEADBAND_S) {
          skew = Math.max(
            0,
            Math.min(WebRTCManager.SYNC_MAX_AUDIO_DELAY_S, skew + WebRTCManager.SYNC_CORRECTION_GAIN * smoothed)
          )
          this.streamSyncSkew.set(userId, skew)
        }

        const wantedAudioDelay = Math.max(0, skew)
        const appliedAudioDelay = delayNode.delayTime.value
        const step = Math.max(
          -WebRTCManager.SYNC_MAX_DELAY_STEP_S,
          Math.min(WebRTCManager.SYNC_MAX_DELAY_STEP_S, wantedAudioDelay - appliedAudioDelay)
        )
        if (Math.abs(step) > 0.003) {
          const now = ctx.currentTime
          delayNode.delayTime.cancelScheduledValues(now)
          delayNode.delayTime.setValueAtTime(appliedAudioDelay, now)
          delayNode.delayTime.linearRampToValueAtTime(
            appliedAudioDelay + step,
            now + WebRTCManager.SYNC_DELAY_RAMP_S
          )
        }

        const videoReceiver = pc.getReceivers().find(r => r.track?.kind === 'video')
        if (videoReceiver) this.updateVideoJitterBuffer(userId, videoReceiver, stats)
      } catch { }
    }
  }

  private updateVideoJitterBuffer(userId: string, receiver: RTCRtpReceiver, stats: RTCStatsReport) {
    if (!('jitterBufferTarget' in receiver)) return

    if ((useAppStore.getState().isRemoteControlling && this.controllingStreamerId === userId) || this.activeRemoteViewerId === userId) {
      try {
        if ((receiver as any).jitterBufferTarget !== WebRTCManager.VIDEO_JITTER_RC_MS) {
          (receiver as any).jitterBufferTarget = WebRTCManager.VIDEO_JITTER_RC_MS
        }
        if ('playoutDelayHint' in receiver && (receiver as any).playoutDelayHint !== 0) {
          (receiver as any).playoutDelayHint = 0
        }
      } catch { }
      return
    }

    let jitterSeconds = 0
    let packetsLost = 0
    let packetsReceived = 0
    let freezeCount = 0
    let found = false

    stats.forEach(report => {
      if (report.type !== 'inbound-rtp' || report.kind !== 'video') return
      found = true
      if (typeof report.jitter === 'number') jitterSeconds = report.jitter
      if (typeof report.packetsLost === 'number') packetsLost = report.packetsLost
      if (typeof report.packetsReceived === 'number') packetsReceived = report.packetsReceived
      if (typeof report.freezeCount === 'number') freezeCount = report.freezeCount
    })

    if (!found) return

    const prevLost = this.lastVideoPacketsLost.get(userId) ?? packetsLost
    const prevReceived = this.lastVideoPacketsReceived.get(userId) ?? packetsReceived
    const prevFreeze = this.lastVideoFreezeCount.get(userId) ?? freezeCount
    this.lastVideoPacketsLost.set(userId, packetsLost)
    this.lastVideoPacketsReceived.set(userId, packetsReceived)
    this.lastVideoFreezeCount.set(userId, freezeCount)

    const lostDelta = Math.max(0, packetsLost - prevLost)
    const receivedDelta = Math.max(0, packetsReceived - prevReceived)
    const totalDelta = lostDelta + receivedDelta
    const lossRatio = totalDelta > 0 ? lostDelta / totalDelta : 0
    const freezeDelta = Math.max(0, freezeCount - prevFreeze)

    const jitterMs = Math.max(0, jitterSeconds * 1000)
    const wanted = Math.max(
      WebRTCManager.VIDEO_JITTER_MIN_MS,
      Math.min(
        WebRTCManager.VIDEO_JITTER_MAX_MS,
        WebRTCManager.VIDEO_JITTER_HEADROOM_MS
          + jitterMs * WebRTCManager.VIDEO_JITTER_FACTOR
          + lossRatio * WebRTCManager.VIDEO_JITTER_LOSS_MS
          + Math.min(freezeDelta, 3) * WebRTCManager.VIDEO_JITTER_FREEZE_MS
      )
    )

    const prevTarget = this.videoJitterTargetMs.get(userId) ?? WebRTCManager.VIDEO_JITTER_MIN_MS
    const alpha = wanted > prevTarget ? WebRTCManager.VIDEO_JITTER_ATTACK : WebRTCManager.VIDEO_JITTER_RELEASE
    const next = prevTarget + (wanted - prevTarget) * alpha
    this.videoJitterTargetMs.set(userId, next)

    try {
      (receiver as any).jitterBufferTarget = Math.round(next)
    } catch { }
  }

  public applyViewerState(viewerId: string, state: 'watching' | 'preview') {
    const normalized = state === 'preview' ? 'preview' : 'watching'
    if (this.viewerStates.get(viewerId) === normalized) return
    this.viewerStates.set(viewerId, normalized)
    if (this.localVideoStream && this.currentStreamQuality !== 'camera' && !this.sfuPubActive) {
      void this.applyVideoProfile(viewerId)
    }
  }

  public scheduleStreamViewInterestReport(delayMs = 80) {
    if (this.viewInterestTimer) clearTimeout(this.viewInterestTimer)
    this.viewInterestTimer = setTimeout(() => {
      this.viewInterestTimer = null
      this.reportStreamViewInterest()
    }, delayMs)
  }

  private reportStreamViewInterest() {
    const store = useAppStore.getState()
    const currentUserId = store.currentUser?.id
    const watchedId = store.activeStreamId
    const streamingSet = new Set<string>(Object.keys(store.remoteVideoStreams))
    for (const u of store.voiceUsers) {
      if (u.isStreaming && u.id !== currentUserId) streamingSet.add(u.id)
    }
    if (store.currentCallUser?.isStreaming && store.currentCallUser.id !== currentUserId) {
      streamingSet.add(store.currentCallUser.id)
    }
    const streamingPeers = [...streamingSet]

    for (const peerId of [...this.reportedViewStates.keys()]) {
      if (!streamingPeers.includes(peerId)) this.reportedViewStates.delete(peerId)
    }

    for (const peerId of streamingPeers) {
      if (peerId === currentUserId) continue
      const desired: 'watching' | 'preview' = peerId === watchedId ? 'watching' : 'preview'
      this.reconcileSfuSubscriptionForPeer(peerId, desired)
      if (this.reportedViewStates.get(peerId) === desired) continue
      this.reportedViewStates.set(peerId, desired)
      signalRService.sendStreamViewState(peerId, desired)
    }
  }

  private static readonly VIDEO_LADDER = [
    { scale: 1.0, bitrateHigh: 6000000, bitrateMedium: 3000000, bitrateLow: 2500000, fpsHigh: 60, fpsMedium: 60, fpsLow: 30 },
    { scale: 1.0, bitrateHigh: 3500000, bitrateMedium: 2200000, bitrateLow: 1500000, fpsHigh: 60, fpsMedium: 60, fpsLow: 30 },
    { scale: 1.5, bitrateHigh: 2000000, bitrateMedium: 1400000, bitrateLow: 1000000, fpsHigh: 60, fpsMedium: 60, fpsLow: 30 },
    { scale: 2.0, bitrateHigh: 1200000, bitrateMedium: 800000,  bitrateLow: 600000,  fpsHigh: 30, fpsMedium: 30, fpsLow: 24 }
  ]

  private static readonly PREVIEW_VIDEO_PROFILE = { scale: 4.0, bitrate: 150000, framerate: 2 }
  private static readonly LADDER_BREACHES_TO_DROP = 2
  private static readonly LADDER_CLEAN_TO_RECOVER = 3

  private videoProfileFor(userId: string) {
    if (userId !== '__sfu__' && this.viewerStates.get(userId) === 'preview') return WebRTCManager.PREVIEW_VIDEO_PROFILE
    const isHigh = this.currentStreamQuality === 'high'
    const isMedium = this.currentStreamQuality === 'medium'
    const maxStep = WebRTCManager.VIDEO_LADDER.length - 1
    const step = Math.max(0, Math.min(maxStep, this.lossLadderStep.get(userId) ?? 0))
    const rung = WebRTCManager.VIDEO_LADDER[step]
    return {
      scale: rung.scale,
      bitrate: isHigh ? rung.bitrateHigh : isMedium ? rung.bitrateMedium : rung.bitrateLow,
      framerate: isHigh ? rung.fpsHigh : isMedium ? rung.fpsMedium : rung.fpsLow
    }
  }

  private async applyVideoProfile(userId: string, pc?: RTCPeerConnection | null) {
    const connection = pc ?? (userId === '__sfu__' ? this.sfuPubConnection : this.peerConnections.get(userId))
    if (!connection) return
    const sender = connection.getSenders().find(s => s.track?.kind === 'video')
    if (!sender) return

    const profile = this.videoProfileFor(userId)
    const signature = `${profile.scale}|${profile.bitrate}|${profile.framerate}`
    if (this.appliedVideoProfiles.get(userId) === signature) return

    try {
      const params = sender.getParameters()
      if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
      params.degradationPreference = 'maintain-framerate'
      const isController = this.activeRemoteViewerId === userId
      params.encodings[0].networkPriority = 'high'
      params.encodings[0].scaleResolutionDownBy = isController ? 1.0 : profile.scale
      params.encodings[0].maxBitrate = profile.bitrate
      params.encodings[0].maxFramerate = isController ? 60 : profile.framerate
      await sender.setParameters(params)
      this.appliedVideoProfiles.set(userId, signature)
    } catch { }
  }

  private updateLossLadder(userId: string, fractionLost: number, rtt: number) {
    const previousBaseline = this.lossBaselineRtt.get(userId)
    const baseline = previousBaseline === undefined || (rtt > 0 && rtt < previousBaseline)
      ? rtt
      : previousBaseline * 0.98 + rtt * 0.02
    if (rtt > 0) this.lossBaselineRtt.set(userId, baseline)
    const rttExcess = rtt > 0 && baseline > 0 ? Math.max(0, rtt - baseline) : 0

    const desiredStep =
      fractionLost > 0.05 || rttExcess > 0.20 ? 3
        : fractionLost > 0.02 || rttExcess > 0.12 ? 2
          : fractionLost > 0.008 || rttExcess > 0.06 ? 1
            : 0
    const currentStep = this.lossLadderStep.get(userId) ?? 0

    if (desiredStep > currentStep) {
      const breaches = (this.lossBreachCount.get(userId) ?? 0) + 1
      this.lossCleanCount.set(userId, 0)
      if (breaches >= WebRTCManager.LADDER_BREACHES_TO_DROP) {
        this.lossLadderStep.set(userId, currentStep + 1)
        this.lossBreachCount.set(userId, 0)
      } else {
        this.lossBreachCount.set(userId, breaches)
      }
      return
    }

    this.lossBreachCount.set(userId, 0)

    if (desiredStep < currentStep) {
      const clean = (this.lossCleanCount.get(userId) ?? 0) + 1
      if (clean >= WebRTCManager.LADDER_CLEAN_TO_RECOVER) {
        this.lossLadderStep.set(userId, currentStep - 1)
        this.lossCleanCount.set(userId, 0)
      } else {
        this.lossCleanCount.set(userId, clean)
      }
      return
    }

    this.lossCleanCount.set(userId, 0)
  }

  private startStatsMonitoring() {
    if (this.statsInterval) clearInterval(this.statsInterval)
    this.statsInterval = setInterval(async () => {
      if (this.currentStreamQuality === 'camera') return
      const entries: Array<[string, RTCPeerConnection]> = [...this.peerConnections.entries()]
      if (this.sfuPubActive && this.sfuPubConnection) entries.push(['__sfu__', this.sfuPubConnection])

      for (const [userId, pc] of entries) {
        if (pc.connectionState !== 'connected') continue
        try {
          const stats = await pc.getStats()
          let reportedFractionLost = -1
          let rtt = 0
          let framesDropped = 0
          let rawPacketsLost = 0
          let rawPacketsSent = 0

          stats.forEach(report => {
            if (report.type === 'remote-inbound-rtp' && report.kind === 'video') {
              rtt = report.roundTripTime || 0
              rawPacketsLost = report.packetsLost || 0
              if (typeof report.fractionLost === 'number') reportedFractionLost = report.fractionLost
            }
            if (report.type === 'outbound-rtp' && report.kind === 'video') {
              framesDropped = report.framesDropped || 0
              rawPacketsSent = report.packetsSent || 0
            }
          })

          const previousLost = this.lastPacketsLost.get(userId) ?? rawPacketsLost
          const previousSent = this.lastPacketsSent.get(userId) ?? rawPacketsSent
          this.lastPacketsLost.set(userId, rawPacketsLost)
          this.lastPacketsSent.set(userId, rawPacketsSent)

          let fractionLost = reportedFractionLost
          if (fractionLost < 0) {
            const lostDelta = Math.max(0, rawPacketsLost - previousLost)
            const sentDelta = Math.max(0, rawPacketsSent - previousSent)
            fractionLost = sentDelta > 0 ? Math.min(1, lostDelta / (sentDelta + lostDelta)) : 0
          }

          this.updateLossLadder(userId, fractionLost, rtt)
          await this.applyVideoProfile(userId, pc)

          const previousDropped = this.lastFramesDropped.get(userId) ?? framesDropped
          this.lastFramesDropped.set(userId, framesDropped)
          const droppedDelta = Math.max(0, framesDropped - previousDropped)
          if (droppedDelta > 30) {
            const store = useAppStore.getState()
            const toastMsg = i18n.t('toasts.streamPerfIssue', 'проблемы с производительностью, рекомендуется снизить качество')
            store.setSystemToast(toastMsg)
            setTimeout(() => {
              if (store.systemToast === toastMsg) {
                store.setSystemToast(null)
              }
            }, 4000)
          }
        } catch (e) {
          console.warn(e)
        }
      }
    }, 2500)
  }

  private configureAudioSender(sender: RTCRtpSender) {
    try {
      const params = sender.getParameters()
      if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
      params.encodings[0].maxBitrate = OPUS_AUDIO_BITRATE
      params.encodings[0].networkPriority = 'high'
      sender.setParameters(params)
        .then(() => {
          console.info('[WebRTC] Audio sender configured', {
            codec: 'opus/48000 mono',
            maxBitrate: sender.getParameters().encodings?.[0]?.maxBitrate,
            contentHint: sender.track?.contentHint
          })
        })
        .catch(error => console.warn('[WebRTC] Failed to configure audio sender', error))
    } catch (error) {
      console.warn('[WebRTC] Failed to read audio sender parameters', error)
    }
  }

  private isPeerRelevant(userId: string): boolean {
    const store = useAppStore.getState()
    if (store.currentCallUser?.id === userId || store.incomingCall?.callerId === userId) return true
    return Boolean(store.currentChannelId && store.voiceUsers.some(user => user.id === userId))
  }

  private async awaitPeerRelevance(userId: string): Promise<boolean> {
    if (this.isPeerRelevant(userId)) return true
    const startedAt = performance.now()
    const deadline = startedAt + WebRTCManager.PEER_RELEVANCE_WAIT_MS
    while (performance.now() < deadline) {
      await new Promise(resolve => setTimeout(resolve, 50))
      if (!useAppStore.getState().currentUser) return false
      if (this.isPeerRelevant(userId)) {
        console.log(`[WebRTC] peer ${userId} became known after ${Math.round(performance.now() - startedAt)}ms`)
        return true
      }
    }
    console.warn(`[WebRTC] peer ${userId} never appeared in the channel roster, signalling dropped`)
    return false
  }

  public async connectToPeer(userId: string, preserveRemoteVideoOnFailure = false) {
    const generation = this.mediaSessionGeneration
    if (userId === useAppStore.getState().currentUser?.id) return
    if (!this.isPeerRelevant(userId)) return
    const existingPc = this.peerConnections.get(userId)
    if (existingPc) {
      const isDead =
        existingPc.connectionState === 'failed' ||
        existingPc.connectionState === 'closed' ||
        existingPc.connectionState === 'disconnected' ||
        existingPc.iceConnectionState === 'failed' ||
        existingPc.iceConnectionState === 'closed'
      if (isDead) {
        this.disconnectFromPeer(userId, { preserveRemoteVideo: preserveRemoteVideoOnFailure, preserveRetryState: true })
        this.peerConnections.delete(userId)
      } else {
        this.flushPendingRenegotiation(userId)
        return
      }
    }

    const startedAt = performance.now()
    this.peerConnectStartedAt.set(userId, startedAt)
    const localStreamPromise = this.localStream ? null : this.startLocalStream().catch(() => { })
    const iceStartedAt = performance.now()
    let iceMs = 0
    const iceServersPromise = this.ensureIceServers().then(() => {
      iceMs = Math.round(performance.now() - iceStartedAt)
    })
    await Promise.all([localStreamPromise, iceServersPromise])
    if (generation !== this.mediaSessionGeneration) return
    if (!this.isPeerRelevant(userId)) return

    return this.enqueueSignalingTask(userId, async () => {
      if (!this.isPeerRelevant(userId)) return
      const queuedExistingPc = this.peerConnections.get(userId)
      if (queuedExistingPc) {
        const isDead =
          queuedExistingPc.connectionState === 'failed' ||
          queuedExistingPc.connectionState === 'closed' ||
          queuedExistingPc.connectionState === 'disconnected' ||
          queuedExistingPc.iceConnectionState === 'failed' ||
          queuedExistingPc.iceConnectionState === 'closed'
        if (isDead) {
          this.disconnectFromPeer(userId, { preserveRemoteVideo: preserveRemoteVideoOnFailure, preserveRetryState: true })
          this.peerConnections.delete(userId)
        } else {
          this.flushPendingRenegotiation(userId)
          return
        }
      }

      const pc = new (RTCPeerConnection as any)(this.rtcConfig(), WebRTCManager.PC_CONSTRAINTS) as RTCPeerConnection
      this.peerConnections.set(userId, pc)

      if (this.localStream) {
        this.localStream.getTracks().forEach(track => {
          const sender = pc.addTrack(track, this.localStream!)
          if (track.kind === 'audio') {
            this.configureAudioSender(sender)
          }
        })
      }
      if (this.localVideoStream) {
        this.localVideoStream.getTracks().forEach(track => {
          const sender = pc.addTrack(track, this.localVideoStream!)
          if (track.kind === 'video') {
            try {
              const isCamera = this.currentStreamQuality === 'camera'
              const params = sender.getParameters()
              if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
              if (!isCamera) {
                params.degradationPreference = 'maintain-framerate'
                const isHigh = this.currentStreamQuality === 'high'
                const isMedium = this.currentStreamQuality === 'medium'
                params.encodings[0].maxBitrate = isHigh ? 6000000 : isMedium ? 3000000 : 2500000
                params.encodings[0].maxFramerate = (isHigh || isMedium) ? 60 : 30
                params.encodings[0].networkPriority = 'high'
              }
              const isController = this.allowRemoteControl && this.activeRemoteViewerId === userId
              if (this.sfuReadyPeers.has(userId) && !this.sfuFallbackPeers.has(userId) && !isController) {
                params.encodings[0].active = false
              }
              sender.setParameters(params).catch(() => { })
            } catch { }
          } else if (track.kind === 'audio') {
            this.configureAudioSender(sender)
            if (this.sfuReadyPeers.has(userId) && !this.sfuFallbackPeers.has(userId) && this.activeRemoteViewerId !== userId) {
              try {
                const params = sender.getParameters()
                if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
                params.encodings[0].active = false
                sender.setParameters(params).catch(() => { })
              } catch { }
            }
          }
        })
      } else {
        try {
          pc.addTransceiver('video', { direction: 'recvonly' })
          pc.addTransceiver('audio', { direction: 'recvonly' })
        } catch { }
      }

      this.setupPeerHandlers(pc, userId)
      this.startIceTimeout(userId)
      this.ensureUltraSendChannel(pc, userId)

      this.isMakingOffer.set(userId, true)
      try {
        const offer = await pc.createOffer(SILENCE_SUPPRESSION_OFF)
        const isRemoteControl = Boolean(
          this.allowRemoteControl ||
          this.rcDataChannels.has(userId) ||
          useAppStore.getState().isRemoteControlling ||
          this.activeRemoteViewerId === userId
        )
        const optimizedSDP = optimizeSDP(offer.sdp!, this.relayOnlyIce, this.ultraLowLatency, this.ultraPtimeFor(userId), isRemoteControl)
        if (!signalRService.isConnected() || !signalRService.isSessionReady()) {
          this.pendingRenegotiation.add(userId)
          return
        }
        await pc.setLocalDescription({ type: 'offer', sdp: optimizedSDP })
        if (this.peerConnections.get(userId) !== pc || !this.isPeerRelevant(userId)) {
          this.disconnectFromPeer(userId)
          return
        }
        const offerEpoch = (this.offerEpoch.get(userId) ?? 0) + 1
        this.offerEpoch.set(userId, offerEpoch)
        signalRService.sendWebRTCOffer(userId, JSON.stringify({ type: pc.localDescription!.type, sdp: pc.localDescription!.sdp, epoch: offerEpoch, allowRemoteControl: this.allowRemoteControl, remoteControlProtocol: 2 }))
        console.log(`[WebRTC] offer to ${userId} sent in ${Math.round(performance.now() - startedAt)}ms (ice servers ${iceMs}ms)`)
      } catch (e) {
        console.error('[WebRTC] connectToPeer failed', e)
        this.peerConnectStartedAt.delete(userId)
        if (preserveRemoteVideoOnFailure) {
          this.startIceTimeout(userId)
        } else {
          this.disconnectFromPeer(userId)
        }
      } finally {
        this.isMakingOffer.set(userId, false)
      }
    })
  }

  public getPeerConnection(userId: string): RTCPeerConnection | undefined {
    return this.peerConnections.get(userId)
  }

  public reconcilePeers(desiredIds: string[]): void {
    const desired = new Set(desiredIds)
    this.peerConnections.forEach((_, uid) => {
      if (!desired.has(uid)) this.disconnectFromPeer(uid)
    })
  }

  public async handleOffer(senderId: string, offerStr: string) {
    return this.enqueueSignalingTask(senderId, async () => {
      const store = useAppStore.getState()
      if (senderId === store.currentUser?.id) return
      if (!await this.awaitPeerRelevance(senderId)) return

      let pc = this.peerConnections.get(senderId)
      if (pc && (pc.connectionState === 'closed' || pc.connectionState === 'failed')) {
        this.disconnectFromPeer(senderId, { preserveRemoteVideo: true })
        pc = undefined
      }
      if (!pc) {
        if (!this.peerConnectStartedAt.has(senderId)) this.peerConnectStartedAt.set(senderId, performance.now())
        const localStreamPromise = this.localStream ? null : this.startLocalStream().catch(() => { })
        await Promise.all([localStreamPromise, this.ensureIceServers()])
        if (!this.isPeerRelevant(senderId)) return
        pc = new (RTCPeerConnection as any)(this.rtcConfig(), WebRTCManager.PC_CONSTRAINTS) as RTCPeerConnection
        this.peerConnections.set(senderId, pc)

        if (this.localStream) {
          this.localStream.getTracks().forEach(track => {
            const sender = pc!.addTrack(track, this.localStream!)
            if (track.kind === 'audio') {
              this.configureAudioSender(sender)
            }
          })
        }
        if (this.localVideoStream) {
          this.localVideoStream.getTracks().forEach(track => {
            const sender = pc!.addTrack(track, this.localVideoStream!)
            if (track.kind === 'video') {
              try {
                const isCamera = this.currentStreamQuality === 'camera'
                const params = sender.getParameters()
                if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
                if (!isCamera) {
                  params.degradationPreference = 'maintain-framerate'
                  const isHigh = this.currentStreamQuality === 'high'
                  const isMedium = this.currentStreamQuality === 'medium'
                  params.encodings[0].maxBitrate = isHigh ? 6000000 : isMedium ? 3000000 : 2500000
                  params.encodings[0].maxFramerate = (isHigh || isMedium) ? 60 : 30
                  params.encodings[0].networkPriority = 'high'
                }
                const isController = this.allowRemoteControl && this.activeRemoteViewerId === senderId
                if (this.sfuReadyPeers.has(senderId) && !this.sfuFallbackPeers.has(senderId) && !isController) {
                  params.encodings[0].active = false
                }
                sender.setParameters(params).catch(() => { })
              } catch { }
            } else if (track.kind === 'audio') {
              this.configureAudioSender(sender)
              if (this.sfuReadyPeers.has(senderId) && !this.sfuFallbackPeers.has(senderId) && this.activeRemoteViewerId !== senderId) {
                try {
                  const params = sender.getParameters()
                  if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
                  params.encodings[0].active = false
                  sender.setParameters(params).catch(() => { })
                } catch { }
              }
            }
          })
        }

        this.setupPeerHandlers(pc, senderId)
        this.startIceTimeout(senderId)
      }

      try {
        const offer = JSON.parse(offerStr)
        this.remoteControlVersions.set(senderId, Number(offer.remoteControlProtocol ?? 1))
        if (typeof (offer as { allowRemoteControl?: boolean }).allowRemoteControl === 'boolean') {
          const rcAllowed = Boolean((offer as { allowRemoteControl: boolean }).allowRemoteControl)
          store.setStreamRemoteControlAllowed(senderId, rcAllowed)
          store.updateUserStatus(senderId, { allowRemoteControl: rcAllowed })
        }

        const isMakingOffer = this.isMakingOffer.get(senderId) ?? false
        const readyForOffer = !isMakingOffer && (pc.signalingState === 'stable' || (this.isSettingRemoteAnswerPending.get(senderId) ?? false))
        const offerCollision = !readyForOffer

        const me = store.currentUser?.id ?? ''
        const isPolitePeer = me > senderId

        if (offerCollision) {
          if (!isPolitePeer) {
            console.log(`[WebRTC] Impolite peer ${me} ignoring colliding offer from ${senderId}`)
            return
          }
          if (pc.signalingState === 'have-local-offer') {
            await pc.setLocalDescription({ type: 'rollback' })
          }
          this.pendingRenegotiation.add(senderId)
        }

        await pc.setRemoteDescription(new RTCSessionDescription(offer))
        const offerSdp = typeof offer.sdp === 'string' ? offer.sdp : ''
        if (offerSdp.includes('m=application')) this.acceptUltraChannelFromOffer(pc, senderId)
        const answer = await pc.createAnswer(SILENCE_SUPPRESSION_OFF)
        const offeredMinPtime = offerSdp.match(/minptime=(\d+)/)
        const isOfferUltraLow = Boolean(offeredMinPtime && Number(offeredMinPtime[1]) <= 10)
        const effectiveUltraLow = this.ultraLowLatency || isOfferUltraLow
        const answerPtime = offeredMinPtime ? Math.max(ULTRA_FRAME_MS_FAST, Math.min(ULTRA_FRAME_MS_SAFE, Number(offeredMinPtime[1]))) : this.ultraPtimeFor(senderId)
        const isRemoteControl = Boolean(
          this.allowRemoteControl ||
          this.rcDataChannels.has(senderId) ||
          useAppStore.getState().isRemoteControlling ||
          this.activeRemoteViewerId === senderId
        )
        const optimizedAnswerSDP = optimizeSDP(answer.sdp!, this.relayOnlyIce, effectiveUltraLow, answerPtime, isRemoteControl)
        await pc.setLocalDescription({ type: 'answer', sdp: optimizedAnswerSDP })
        await this.drainPendingCandidates(senderId)
        if (this.peerConnections.get(senderId) !== pc || !this.isPeerRelevant(senderId)) {
          this.disconnectFromPeer(senderId)
          return
        }
        signalRService.sendWebRTCAnswer(senderId, JSON.stringify({ type: pc.localDescription!.type, sdp: pc.localDescription!.sdp, epoch: (offer as { epoch?: number }).epoch, allowRemoteControl: this.allowRemoteControl, remoteControlProtocol: 2 }))
        this.flushPendingRenegotiation(senderId)
        this.syncRemoteVideoStream(senderId)

        if (this.localVideoStream) {
          const transceivers = pc.getTransceivers()
          const tracks = this.localVideoStream.getTracks()
          const hasUnnegotiated = tracks.some(t => {
            if (t.readyState !== 'live') return false
            const transceiver = transceivers.find(transceiver => !transceiver.stopped && transceiver.sender.track === t)
            return !transceiver || (transceiver.currentDirection !== 'sendonly' && transceiver.currentDirection !== 'sendrecv')
          })
          if (hasUnnegotiated) {
            void this.renegotiatePeer(pc, senderId)
          }
        }
      } catch (e) {
        console.error('[WebRTC] handleOffer failed', e)
        if (!pc || pc.connectionState === 'closed' || pc.connectionState === 'failed') {
          this.disconnectFromPeer(senderId, { preserveRemoteVideo: true })
          void this.connectToPeer(senderId, true)
        } else {
          this.startIceTimeout(senderId)
        }
      }
    })
  }

  public async handleAnswer(senderId: string, answerStr: string) {
    return this.enqueueSignalingTask(senderId, async () => {
      if (senderId === useAppStore.getState().currentUser?.id) return
      if (!this.isPeerRelevant(senderId)) return
      const pc = this.peerConnections.get(senderId)
      if (pc) {
        this.isSettingRemoteAnswerPending.set(senderId, true)
        try {
          const answer = JSON.parse(answerStr)
          this.remoteControlVersions.set(senderId, Number(answer.remoteControlProtocol ?? 1))
          if (typeof (answer as { allowRemoteControl?: boolean }).allowRemoteControl === 'boolean') {
            const rcAllowed = Boolean((answer as { allowRemoteControl: boolean }).allowRemoteControl)
            const store = useAppStore.getState()
            store.setStreamRemoteControlAllowed(senderId, rcAllowed)
            store.updateUserStatus(senderId, { allowRemoteControl: rcAllowed })
          }
          const currentEpoch = this.offerEpoch.get(senderId)
          const answerEpoch = (answer as { epoch?: number }).epoch
          if (answerEpoch != null && currentEpoch != null && answerEpoch !== currentEpoch) return
          if (pc.signalingState === 'have-local-offer') {
            await pc.setRemoteDescription(new RTCSessionDescription(answer))
            this.rollbackCount.delete(senderId)
            await this.drainPendingCandidates(senderId)
            this.flushPendingRenegotiation(senderId)
            this.syncRemoteVideoStream(senderId)
          } else if (pc.signalingState !== 'stable') {
            this.startIceTimeout(senderId)
          }
        } catch (e) {
          console.error('[WebRTC] handleAnswer failed', e)
          await this.recoverRejectedAnswer(senderId, pc)
        } finally {
          this.isSettingRemoteAnswerPending.set(senderId, false)
        }
      }
    })
  }

  public async handleIceCandidate(senderId: string, candidateStr: string) {
    return this.enqueueSignalingTask(senderId, async () => {
      if (senderId === useAppStore.getState().currentUser?.id) return
      let candidate: RTCIceCandidateInit
      try { candidate = JSON.parse(candidateStr) } catch { return }

      if (!this.isPeerRelevant(senderId)) {
        const early = this.pendingCandidates.get(senderId) ?? []
        if (early.length < WebRTCManager.PENDING_CANDIDATES_PER_PEER) {
          early.push(candidate)
          this.pendingCandidates.set(senderId, early)
        }
        return
      }
      const pc = this.peerConnections.get(senderId)
      if (!pc || !pc.remoteDescription) {
        const buf = this.pendingCandidates.get(senderId) ?? []
        buf.push(candidate)
        this.pendingCandidates.set(senderId, buf)
        return
      }

      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate))
      } catch {
        const buf = this.pendingCandidates.get(senderId) ?? []
        buf.push(candidate)
        this.pendingCandidates.set(senderId, buf)
      }
    })
  }

  private async drainPendingCandidates(userId: string): Promise<void> {
    const pc = this.peerConnections.get(userId)
    const candidates = this.pendingCandidates.get(userId)
    if (!pc || !candidates || candidates.length === 0) return
    this.pendingCandidates.delete(userId)
    for (const c of candidates) {
      try { await pc.addIceCandidate(new RTCIceCandidate(c)) } catch { }
    }
  }

  public disconnectFromPeer(
    userId: string,
    options: { preserveRemoteVideo?: boolean; preserveRetryState?: boolean } = {}
  ) {
    useAppStore.getState().setWebRTCConnectionStatus(userId, false)

    this.clearIceTimeout(userId)
    this.iceRestartInFlight.delete(userId)
    if (!options.preserveRetryState) this.retryCount.delete(userId)
    const dcTimer = this.dcTimers.get(userId)
    if (dcTimer) { clearTimeout(dcTimer); this.dcTimers.delete(userId) }

    this.teardownUltraCustomPlayout(userId)
    const ultraChannel = this.ultraDataChannels.get(userId)
    if (ultraChannel) {
      try { ultraChannel.onopen = ultraChannel.onclose = ultraChannel.onerror = ultraChannel.onmessage = null; ultraChannel.close() } catch { }
      this.ultraDataChannels.delete(userId)
    }
    this.ultraCustomEngaging.delete(userId)
    this.ultraSendTargets.delete(userId)
    if (this.ultraSendTargets.size === 0) this.stopUltraSend()
    this.ultraCustomGotFrame.delete(userId)
    this.ultraCustomHandedOver.delete(userId)
    this.ultraCustomLastAudioAt.delete(userId)
    this.ultraRcvStats.delete(userId)
    this.ultraCustomFailCount.delete(userId)
    this.ultraCustomFailed.delete(userId)
    this.ultraHiResends.delete(userId)

    const rcChannel = this.rcDataChannels.get(userId)
    if (rcChannel) {
      try {
        rcChannel.onopen = rcChannel.onclose = rcChannel.onerror = rcChannel.onmessage = null
        rcChannel.close()
      } catch { }
      this.rcDataChannels.delete(userId)
    }
    this.handleRemoteControlDisconnect(userId)

    const pc = this.peerConnections.get(userId)
    if (pc) { pc.ontrack = null; pc.onicecandidate = null; pc.onconnectionstatechange = null; pc.oniceconnectionstatechange = null; pc.close(); this.peerConnections.delete(userId) }

    const source = this.userSourceNodes.get(userId)
    if (source) { try { source.disconnect() } catch { }; this.userSourceNodes.delete(userId) }

    const voicePull = this.audioElements.get(userId)
    if (voicePull) { try { voicePull.pause(); voicePull.srcObject = null } catch { }; this.audioElements.delete(userId) }

    const gain = this.userGainNodes.get(userId)
    if (gain) { try { gain.disconnect() } catch { }; this.userGainNodes.delete(userId) }

    const limiter = this.userLimiterNodes.get(userId)
    if (limiter) { try { limiter.disconnect() } catch { }; this.userLimiterNodes.delete(userId) }

    const panner = this.userPannerNodes.get(userId)
    if (panner) { try { panner.disconnect() } catch { }; this.userPannerNodes.delete(userId) }
    this.applyVoiceSeats()

    if (!options.preserveRemoteVideo) {
      this.closeSfuSubscriber(userId, false)
      this.streamDeliveryModes.delete(userId)
      this.p2pStreamsBackup.delete(userId)
      this.p2pAudioBackup.delete(userId)
      this.cleanupRemoteStreamAudio(userId)
      useAppStore.getState().setRemoteVideoStream(userId, null)
    } else if (!this.sfuSubConnections.has(userId)) {
      this.cleanupRemoteStreamAudio(userId)
    }

    const voiceTrackId = this.userVoiceTrackIds.get(userId)
    if (voiceTrackId) {
      this.ultraJitterTargetMs.delete(voiceTrackId)
      this.ultraConcealBurstMs.delete(voiceTrackId)
    }
    this.userVoiceTrackIds.delete(userId)
    this.userVoiceStreamIds.delete(userId)

    this.pendingCandidates.delete(userId)
    this.pendingRenegotiation.delete(userId)
    this.pendingIceRestart.delete(userId)
    this.isMakingOffer.delete(userId)
    this.isSettingRemoteAnswerPending.delete(userId)
    this.offerEpoch.delete(userId)
    this.clearVAD(userId)
    this.lastPacketsLost.delete(userId)
    this.lastPacketsSent.delete(userId)
    this.lastFramesDropped.delete(userId)
    this.lossLadderStep.delete(userId)
    this.lossBreachCount.delete(userId)
    this.lossCleanCount.delete(userId)
    this.lossBaselineRtt.delete(userId)
    this.lastAudioPacketTimes.delete(userId)
    this.lastAudioConcealment.delete(userId)
    this.ultraFrameMs.delete(userId)
    this.ultraFrameCleanTicks.delete(userId)
    this.ultraFrameLastSwitchAt.delete(userId)
    this.ultraFrameLossTicks.delete(userId)
    this.lastInboundLoss.delete(userId)
    this.lastInboundReceived.delete(userId)
    this.renegotiationStuckSince.delete(userId)
    this.rollbackCount.delete(userId)
    this.ultraRttMs.delete(userId)
    this.ultraConcealRate.delete(userId)
    this.peerLastSettledState.delete(userId)
    this.lastSoftRefreshAt.delete(userId)
    this.appliedVideoProfiles.delete(userId)
    this.viewerStates.delete(userId)
    this.reportedViewStates.delete(userId)
    this.remoteControlVersions.delete(userId)
  }

  public cleanupRemoteStreamAudio(userId: string) {
    this.userStreamAudioTrackIds.delete(userId)
    this.userScreenStreamIds.delete(userId)

    const streamPull = this.streamAudioElements.get(userId)
    if (streamPull) { try { streamPull.pause(); streamPull.srcObject = null } catch { }; this.streamAudioElements.delete(userId) }

    const streamSource = this.streamSourceNodes.get(userId)
    if (streamSource) { try { streamSource.disconnect() } catch { }; this.streamSourceNodes.delete(userId) }

    const streamGain = this.streamGainNodes.get(userId)
    if (streamGain) { try { streamGain.disconnect() } catch { }; this.streamGainNodes.delete(userId) }

    const streamLimiter = this.streamLimiterNodes.get(userId)
    if (streamLimiter) { try { streamLimiter.disconnect() } catch { }; this.streamLimiterNodes.delete(userId) }

    const streamDelay = this.streamDelayNodes.get(userId)
    if (streamDelay) { try { streamDelay.disconnect() } catch { }; this.streamDelayNodes.delete(userId) }
    this.streamSyncOffsetEma.delete(userId)
    this.streamSyncSkew.delete(userId)
    this.videoJitterTargetMs.delete(userId)
    this.lastVideoPacketsLost.delete(userId)
    this.lastVideoPacketsReceived.delete(userId)
    this.lastVideoFreezeCount.delete(userId)
    if (this.streamGainNodes.size === 0) this.stopStreamSyncMonitoring()
  }

  public cleanupRemoteStream(userId: string) {
    this.closeSfuSubscriber(userId, false)
    this.streamDeliveryModes.delete(userId)
    this.p2pStreamsBackup.delete(userId)
    this.p2pAudioBackup.delete(userId)
    this.cleanupRemoteStreamAudio(userId)
    const st = useAppStore.getState()
    if (this.controllingStreamerId === userId) {
      this.controllingStreamerId = null
      st.setRemoteControlState({ isControlling: false, isHostActive: false, isRevoked: false })
    }
    st.setRemoteVideoStream(userId, null)
    if (st.activeStreamId === userId) {
      st.setRemoteControlState({ isControlling: false, isRevoked: false })
    }
  }

  private waitForIceGatheringComplete(pc: RTCPeerConnection, timeoutMs = 1200): Promise<void> {
    if (pc.iceGatheringState === 'complete') return Promise.resolve()
    return new Promise<void>(resolve => {
      let settled = false
      const done = () => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        pc.removeEventListener('icegatheringstatechange', onState)
        resolve()
      }
      const onState = () => {
        if (pc.iceGatheringState === 'complete') done()
      }
      const timer = setTimeout(done, timeoutMs)
      pc.addEventListener('icegatheringstatechange', onState)
    })
  }

  private waitForFirstVideoFrame(stream: MediaStream, timeoutMs = 6500): Promise<boolean> {
    const track = stream.getVideoTracks()[0]
    if (!track || track.readyState === 'ended') return Promise.resolve(false)
    track.enabled = true
    return new Promise<boolean>(resolve => {
      let settled = false
      const video = document.createElement('video')
      video.muted = true
      video.playsInline = true
      video.autoplay = true
      video.srcObject = new MediaStream([track])
      const anyVideo = video as HTMLVideoElement & {
        requestVideoFrameCallback?: (cb: () => void) => number
        cancelVideoFrameCallback?: (h: number) => void
      }
      let frameHandle = 0
      const onFrame = () => {
        if (!track.muted && video.videoWidth > 0 && video.readyState >= 2) done(true)
        else if (typeof anyVideo.requestVideoFrameCallback === 'function') frameHandle = anyVideo.requestVideoFrameCallback(onFrame)
      }
      const onPlaying = () => { if (video.readyState >= 2 && video.videoWidth > 0 && !track.muted) done(true) }
      const done = (ready = false) => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        if (frameHandle && typeof anyVideo.cancelVideoFrameCallback === 'function') {
          try { anyVideo.cancelVideoFrameCallback(frameHandle) } catch { }
        }
        video.removeEventListener('loadeddata', onPlaying)
        video.removeEventListener('playing', onPlaying)
        try {
          video.pause()
          video.srcObject = null
        } catch { }
        resolve(ready)
      }
      const timer = setTimeout(() => done(false), timeoutMs)
      video.addEventListener('loadeddata', onPlaying)
      video.addEventListener('playing', onPlaying)
      if (typeof anyVideo.requestVideoFrameCallback === 'function') {
        frameHandle = anyVideo.requestVideoFrameCallback(onFrame)
      } else {
        video.addEventListener('loadeddata', onPlaying, { once: true })
        video.addEventListener('playing', onPlaying, { once: true })
      }
      void video.play().catch(() => { })
    })
  }

  private closeSfuPublisher() {
    this.sfuReadyPeers.clear()
    if (this.sfuPubPauseTimer) {
      clearTimeout(this.sfuPubPauseTimer)
      this.sfuPubPauseTimer = null
    }
    if (this.sfuPubCloseTimer) {
      clearTimeout(this.sfuPubCloseTimer)
      this.sfuPubCloseTimer = null
    }
    if (this.sfuPubWatchdogTimer) {
      clearTimeout(this.sfuPubWatchdogTimer)
      this.sfuPubWatchdogTimer = null
    }
    this.sfuPubActive = false
    this.sfuPubEpoch = 0
    if (this.sfuPubConnection) {
      const pc = this.sfuPubConnection
      this.sfuPubConnection = null
      try {
        pc.onconnectionstatechange = null
        pc.oniceconnectionstatechange = null
        pc.close()
      } catch { }
    }
    this.lastPacketsLost.delete('__sfu__')
    this.lastPacketsSent.delete('__sfu__')
    this.lastFramesDropped.delete('__sfu__')
    this.lossLadderStep.delete('__sfu__')
    this.lossBreachCount.delete('__sfu__')
    this.lossCleanCount.delete('__sfu__')
    this.lossBaselineRtt.delete('__sfu__')
    this.appliedVideoProfiles.delete('__sfu__')
  }

  private async setP2PScreenSendersActive(active: boolean) {
    const localVideo = this.localVideoStream
    if (!localVideo) return
    const videoTrack = localVideo.getVideoTracks()[0] ?? null
    const micTrack = this.localStream?.getAudioTracks()[0] ?? null
    const screenAudioTrack = localVideo.getAudioTracks().find(t => t !== micTrack) ?? null

    for (const [peerId, pc] of this.peerConnections.entries()) {
      if (pc.connectionState === 'closed') continue
      const isController = this.allowRemoteControl && this.activeRemoteViewerId === peerId
      const targetActive = active || this.sfuFallbackPeers.has(peerId) || isController
      try {
        const transceivers = pc.getTransceivers()
        const videoTransceiver = transceivers.find(t => t.receiver.track.kind === 'video' && !t.stopped)
        if (videoTransceiver) {
          const sender = videoTransceiver.sender
          if (targetActive && videoTrack) {
            if (sender.track !== videoTrack) {
              await sender.replaceTrack(videoTrack).catch(() => { })
            }
          }
          const params = sender.getParameters()
          if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
          params.encodings[0].active = targetActive
          await sender.setParameters(params).catch(() => { })
          if (targetActive && this.currentStreamQuality !== 'camera') {
            this.appliedVideoProfiles.delete(peerId)
            await this.applyVideoProfile(peerId, pc)
          }
        }

        const audioTransceivers = transceivers.filter(t => t.receiver.track.kind === 'audio' && !t.stopped)
        const screenAudioTransceiver = audioTransceivers.length > 1 ? audioTransceivers[1] : null
        if (screenAudioTransceiver) {
          const sender = screenAudioTransceiver.sender
          if (targetActive && screenAudioTrack && sender.track !== screenAudioTrack) {
            await sender.replaceTrack(screenAudioTrack).catch(() => { })
          }
          const params = sender.getParameters()
          if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
          params.encodings[0].active = targetActive
          await sender.setParameters(params).catch(() => { })
        }
      } catch { }
    }
  }

  public async setP2PScreenSenderActiveForPeer(peerId: string, active: boolean) {
    const pc = this.peerConnections.get(peerId)
    if (!pc || pc.connectionState === 'closed') return
    const localVideo = this.localVideoStream
    if (!localVideo) return
    const videoTrack = localVideo.getVideoTracks()[0] ?? null
    try {
      const transceivers = pc.getTransceivers()
      const videoTransceiver = transceivers.find(t =>
        !t.stopped && (
          t.sender.track === videoTrack ||
          t.sender.track?.kind === 'video' ||
          t.receiver.track.kind === 'video'
        )
      ) ?? transceivers.find(t => t.receiver.track.kind === 'video' && !t.stopped)
      if (videoTransceiver) {
        const sender = videoTransceiver.sender
        if (active && videoTrack && sender.track !== videoTrack) {
          await sender.replaceTrack(videoTrack).catch(() => { })
        }
        const params = sender.getParameters()
        if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
        params.encodings[0].active = active
        if (active) {
          params.encodings[0].networkPriority = 'high'
          params.encodings[0].maxFramerate = 60
          params.encodings[0].scaleResolutionDownBy = 1.0
          params.degradationPreference = 'maintain-framerate'
        }
        await sender.setParameters(params).catch(() => { })
        if (active && this.currentStreamQuality !== 'camera') {
          this.appliedVideoProfiles.delete(peerId)
          await this.applyVideoProfile(peerId, pc)
        }
      }
      const screenAudioTrack = localVideo.getAudioTracks()[0]
      const audioTransceiver = transceivers.find(t => !t.stopped && t.sender.track === screenAudioTrack && screenAudioTrack)
        ?? transceivers.filter(t => !t.stopped && t.receiver.track.kind === 'audio')[1]
      if (audioTransceiver && screenAudioTrack) {
        const sender = audioTransceiver.sender
        if (active && sender.track !== screenAudioTrack) await sender.replaceTrack(screenAudioTrack)
        const params = sender.getParameters()
        if (params.encodings?.length) {
          params.encodings[0].active = active
          await sender.setParameters(params)
        }
      }
    } catch { }
  }

  public getP2PVideoStream(userId: string): MediaStream | null {
    return this.p2pStreamsBackup.get(userId) || null
  }

  public async handleViewerSfuFallback(viewerId: string, epoch: number) {
    if (!viewerId || !this.localVideoStream || this.sfuPubEpoch !== epoch) return
    this.sfuReadyPeers.delete(viewerId)
    this.sfuFallbackPeers.add(viewerId)
    const pc = this.peerConnections.get(viewerId)
    if (!pc || pc.connectionState === 'closed') return
    const videoTrack = this.localVideoStream.getVideoTracks()[0] ?? null
    const micTrack = this.localStream?.getAudioTracks()[0] ?? null
    const screenAudioTrack = this.localVideoStream.getAudioTracks().find(t => t !== micTrack) ?? null
    try {
      const transceivers = pc.getTransceivers()
      const videoTransceiver = transceivers.find(t => t.receiver.track.kind === 'video' && !t.stopped)
      if (videoTransceiver) {
        const sender = videoTransceiver.sender
        if (videoTrack && sender.track !== videoTrack) {
          await sender.replaceTrack(videoTrack).catch(() => { })
        }
        const params = sender.getParameters()
        if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
        params.encodings[0].active = true
        await sender.setParameters(params).catch(() => { })
        if (this.currentStreamQuality !== 'camera') {
          this.appliedVideoProfiles.delete(viewerId)
          await this.applyVideoProfile(viewerId, pc)
        }
      }
      const audioTransceivers = transceivers.filter(t => t.receiver.track.kind === 'audio' && !t.stopped)
      const screenAudioTransceiver = audioTransceivers.length > 1 ? audioTransceivers[1] : null
      if (screenAudioTransceiver) {
        const sender = screenAudioTransceiver.sender
        if (screenAudioTrack && sender.track !== screenAudioTrack) {
          await sender.replaceTrack(screenAudioTrack).catch(() => { })
        }
        const params = sender.getParameters()
        if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
        params.encodings[0].active = true
        await sender.setParameters(params).catch(() => { })
      }
    } catch { }
  }

  public async handleSfuPublishRequired(epoch: number, _nodeId: string) {
    const previous = this.sfuPublishTask ?? Promise.resolve()
    const generation = this.screenShareGeneration
    const task = previous.catch(() => {}).then(async () => {
      if (this.screenShareGeneration !== generation || epoch < this.sfuPubEpoch) return
      await this.handleSfuPublishRequiredOperation(epoch, _nodeId)
    })
    this.sfuPublishTask = task
    try { await task }
    finally { if (this.sfuPublishTask === task) this.sfuPublishTask = null }
  }

  private async handleSfuPublishRequiredOperation(epoch: number, _nodeId: string) {
    this.pendingSfuPublish = { epoch, nodeId: _nodeId }
    if (!this.localVideoStream || this.isStartingScreenShare) return
    this.pendingSfuPublish = null
    this.sfuFallbackPeers.clear()
    this.sfuReadyPeers.clear()
    if (this.sfuPubCloseTimer) {
      clearTimeout(this.sfuPubCloseTimer)
      this.sfuPubCloseTimer = null
    }
    if (this.sfuPubWatchdogTimer) {
      clearTimeout(this.sfuPubWatchdogTimer)
      this.sfuPubWatchdogTimer = null
    }
    if (this.sfuPubConnection && this.sfuPubEpoch === epoch && this.sfuPubConnection.connectionState !== 'failed' && this.sfuPubConnection.connectionState !== 'closed') {
      return
    }
    if (this.sfuPubConnection) {
      try {
        this.sfuPubConnection.onconnectionstatechange = null
        this.sfuPubConnection.oniceconnectionstatechange = null
        this.sfuPubConnection.close()
      } catch { }
      this.sfuPubConnection = null
    }

    this.sfuPubEpoch = epoch
    await this.ensureIceServers()
    if (!this.localVideoStream || this.sfuPubEpoch !== epoch || this.isStartingScreenShare) return

    const pc = new (RTCPeerConnection as any)(this.rtcConfig(), WebRTCManager.PC_CONSTRAINTS) as RTCPeerConnection
    this.sfuPubConnection = pc

    const videoTrack = this.localVideoStream.getVideoTracks()[0]
    const micTrack = this.localStream?.getAudioTracks()[0]
    const screenAudioTrack = this.localVideoStream.getAudioTracks().find(t => t !== micTrack)

    if (videoTrack) {
      const vSender = pc.addTrack(videoTrack, this.localVideoStream)
      try {
        if (this.currentStreamQuality !== 'camera') {
          const params = vSender.getParameters()
          if (!params.encodings || params.encodings.length === 0) params.encodings = [{}]
          params.degradationPreference = 'maintain-framerate'
          const isHigh = this.currentStreamQuality === 'high'
          const isMedium = this.currentStreamQuality === 'medium'
          params.encodings[0].maxBitrate = isHigh ? 6000000 : isMedium ? 3000000 : 2500000
          params.encodings[0].maxFramerate = (isHigh || isMedium) ? 60 : 30
          params.encodings[0].networkPriority = 'high'
          params.encodings[0].active = true
          vSender.setParameters(params).catch(() => { })
        }
      } catch { }
    }

    if (screenAudioTrack) {
      const aSender = pc.addTrack(screenAudioTrack, this.localVideoStream)
      this.configureAudioSender(aSender)
    }

    let notifiedReady = false
    const onStateChange = () => {
      if (this.sfuPubConnection !== pc || this.sfuPubEpoch !== epoch) return
      const st = pc.connectionState
      const iceSt = pc.iceConnectionState
      if (st === 'connected' || iceSt === 'connected' || iceSt === 'completed') {
        if (this.sfuPubWatchdogTimer) {
          clearTimeout(this.sfuPubWatchdogTimer)
          this.sfuPubWatchdogTimer = null
        }
        if (!notifiedReady) {
          notifiedReady = true
          void signalRService.sfuPublishReady(epoch)
        }
      } else if (st === 'failed' || iceSt === 'failed') {
        if (this.sfuPubWatchdogTimer) {
          clearTimeout(this.sfuPubWatchdogTimer)
          this.sfuPubWatchdogTimer = null
        }
        const me = useAppStore.getState().currentUser?.id
        if (me) void signalRService.sfuReportFailure(me, epoch)
      }
    }
    pc.onconnectionstatechange = onStateChange
    pc.oniceconnectionstatechange = onStateChange

    this.sfuPubWatchdogTimer = setTimeout(() => {
      this.sfuPubWatchdogTimer = null
      if (this.sfuPubConnection === pc && this.sfuPubEpoch === epoch && !notifiedReady) {
        const me = useAppStore.getState().currentUser?.id
        if (me) void signalRService.sfuReportFailure(me, epoch)
      }
    }, 6500)

    try {
      const offer = await pc.createOffer(SILENCE_SUPPRESSION_OFF)
      const optimizedSDP = optimizeSDP(offer.sdp!, this.relayOnlyIce, false, 20)
      await pc.setLocalDescription({ type: 'offer', sdp: optimizedSDP })
      await this.waitForIceGatheringComplete(pc, 1200)
      if (this.sfuPubConnection !== pc || this.sfuPubEpoch !== epoch) return

      const res = await signalRService.sfuPublish(epoch, pc.localDescription!.sdp, Boolean(screenAudioTrack))
      if (this.sfuPubConnection !== pc || this.sfuPubEpoch !== epoch) return
      if (!res || !res.ok || !res.answerSdp) {
        const me = useAppStore.getState().currentUser?.id
        if (me) void signalRService.sfuReportFailure(me, epoch)
        return
      }

      await pc.setRemoteDescription({ type: 'answer', sdp: res.answerSdp })
      onStateChange()
    } catch {
      const me = useAppStore.getState().currentUser?.id
      if (me && this.sfuPubEpoch === epoch) {
        void signalRService.sfuReportFailure(me, epoch)
      }
    }
  }

  public async handleStreamDeliveryModeChanged(dto: any) {
    const streamerId: string = dto?.streamerId ?? dto?.StreamerId ?? ''
    const mode: 'p2p' | 'sfu' = (dto?.mode ?? dto?.Mode) === 'sfu' ? 'sfu' : 'p2p'
    const epoch = Number(dto?.epoch ?? dto?.Epoch ?? 0)
    const nodeId: string | undefined = dto?.nodeId ?? dto?.NodeId
    if (!streamerId) return
    logDiagnostic({ event: 'sfu', route: mode, epoch })

    const prev = this.streamDeliveryModes.get(streamerId)
    if (prev && prev.epoch > epoch) return
    this.streamDeliveryModes.set(streamerId, { mode, epoch, nodeId })

    const store = useAppStore.getState()
    const currentUserId = store.currentUser?.id

    if (streamerId === currentUserId) {
      if (mode === 'sfu') {
        if (this.sfuPubCloseTimer) {
          clearTimeout(this.sfuPubCloseTimer)
          this.sfuPubCloseTimer = null
        }
        this.sfuPubActive = true
      } else {
        if (this.sfuPubPauseTimer) {
          clearTimeout(this.sfuPubPauseTimer)
          this.sfuPubPauseTimer = null
        }
        this.sfuPubActive = false
        this.sfuReadyPeers.clear()
        this.sfuFallbackPeers.clear()
        await this.setP2PScreenSendersActive(true)
        if (this.sfuPubCloseTimer) clearTimeout(this.sfuPubCloseTimer)
        this.sfuPubCloseTimer = setTimeout(() => {
          this.sfuPubCloseTimer = null
          if (!this.sfuPubActive) {
            this.closeSfuPublisher()
          }
        }, 650)
      }
      return
    }

    const isWatching = store.activeStreamId === streamerId
    const hasStream = Boolean(store.remoteVideoStreams[streamerId])

    if (mode === 'sfu') {
      if (isWatching) {
        await this.subscribeToSfuStream(streamerId, epoch, false)
      } else if (!hasStream) {
        await this.subscribeToSfuStream(streamerId, epoch, true)
      }
    } else {
      await this.switchViewerFromSfuToP2P(streamerId)
    }
  }

  private reconcileSfuSubscriptionForPeer(streamerId: string, desired: 'watching' | 'preview') {
    const delivery = this.streamDeliveryModes.get(streamerId)
    if (!delivery || delivery.mode !== 'sfu') return

    const previewTimer = this.sfuPreviewTearDownTimers.get(streamerId)
    if (previewTimer) {
      clearTimeout(previewTimer)
      this.sfuPreviewTearDownTimers.delete(streamerId)
    }

    if (desired === 'watching') {
      const existingPc = this.sfuSubConnections.get(streamerId)
      const existingEpoch = this.sfuSubEpochs.get(streamerId)
      if (!existingPc || existingEpoch !== delivery.epoch || existingPc.connectionState === 'failed' || existingPc.connectionState === 'closed') {
        void this.subscribeToSfuStream(streamerId, delivery.epoch, false)
      } else {
        void signalRService.sfuRequestKeyframe(streamerId)
      }
    } else {
      if (this.sfuSubConnections.has(streamerId)) {
        const t = setTimeout(() => {
          this.sfuPreviewTearDownTimers.delete(streamerId)
          if (useAppStore.getState().activeStreamId !== streamerId) {
            this.closeSfuSubscriber(streamerId, true)
          }
        }, 2600)
        this.sfuPreviewTearDownTimers.set(streamerId, t)
      }
    }
  }

  public async handleViewerSfuReady(viewerId: string, epoch: number): Promise<void> {
    if (!this.sfuPubActive || this.sfuPubEpoch !== epoch || !this.localVideoStream) return
    if (this.activeRemoteViewerId === viewerId) return
    this.sfuReadyPeers.add(viewerId)
    if (!this.sfuFallbackPeers.has(viewerId) && this.activeRemoteViewerId !== viewerId) {
      await this.setP2PScreenSenderActiveForPeer(viewerId, false)
    }
  }

  private async subscribeToSfuStream(streamerId: string, epoch: number, forPreviewSnapshot = false): Promise<void> {
    const previous = this.sfuSubscriptionTasks.get(streamerId) ?? Promise.resolve()
    const task = previous.catch(() => {}).then(() => this.subscribeToSfuStreamOperation(streamerId, epoch, forPreviewSnapshot))
    this.sfuSubscriptionTasks.set(streamerId, task)
    try {
      await task
    } finally {
      if (this.sfuSubscriptionTasks.get(streamerId) === task) this.sfuSubscriptionTasks.delete(streamerId)
    }
  }

  private async subscribeToSfuStreamOperation(streamerId: string, epoch: number, forPreviewSnapshot = false) {
    const existingPc = this.sfuSubConnections.get(streamerId)
    const existingEpoch = this.sfuSubEpochs.get(streamerId)
    if (existingPc && existingEpoch === epoch && existingPc.connectionState !== 'failed' && existingPc.connectionState !== 'closed') {
      return
    }
    this.closeSfuSubscriber(streamerId, false)

    await this.ensureIceServers()
    const currentDelivery = this.streamDeliveryModes.get(streamerId)
    if (!currentDelivery || currentDelivery.mode !== 'sfu' || currentDelivery.epoch !== epoch) return

    const pc = new (RTCPeerConnection as any)(this.rtcConfig(), WebRTCManager.PC_CONSTRAINTS) as RTCPeerConnection
    this.sfuSubConnections.set(streamerId, pc)
    this.sfuSubEpochs.set(streamerId, epoch)

    pc.addTransceiver('video', { direction: 'recvonly' })
    pc.addTransceiver('audio', { direction: 'recvonly' })

    const sfuCombinedStream = new MediaStream()
    let videoAttached = false
    let subConnected = false

    pc.ontrack = (event) => {
      if (this.sfuSubConnections.get(streamerId) !== pc) return
      sfuCombinedStream.addTrack(event.track)

      if (event.track.kind === 'video') {
        if (event.receiver) {
          this.applyVideoZeroPlayoutDelay(event.receiver)
        }
        void (async () => {
          const ready = await this.waitForFirstVideoFrame(sfuCombinedStream)
          if (this.sfuSubConnections.get(streamerId) !== pc) return
          if (!ready) {
            void signalRService.sfuReportFailure(streamerId, epoch)
            await this.switchViewerFromSfuToP2P(streamerId)
            return
          }
          videoAttached = true
          const watchdog = this.sfuSubWatchdogTimers.get(streamerId)
          if (watchdog) clearTimeout(watchdog)
          this.sfuSubWatchdogTimers.delete(streamerId)
          this.attachRemoteVideo(streamerId, event.track, sfuCombinedStream, true)
          if (!forPreviewSnapshot || useAppStore.getState().activeStreamId === streamerId) {
            void signalRService.sfuViewerReady(streamerId, epoch)
          }
          if (forPreviewSnapshot && useAppStore.getState().activeStreamId !== streamerId) {
            const t = setTimeout(() => {
              this.sfuPreviewTearDownTimers.delete(streamerId)
              if (useAppStore.getState().activeStreamId !== streamerId) {
                this.closeSfuSubscriber(streamerId, true)
              }
            }, 2600)
            this.sfuPreviewTearDownTimers.set(streamerId, t)
          }
        })()
      } else if (event.track.kind === 'audio') {
        this.attachRemoteStreamAudio(streamerId, event.track, event.receiver, sfuCombinedStream, true)
      }
    }

    const onStateChange = () => {
      if (this.sfuSubConnections.get(streamerId) !== pc) return
      const st = pc.connectionState
      const iceSt = pc.iceConnectionState
      if (st === 'connected' || iceSt === 'connected' || iceSt === 'completed') {
        subConnected = true
        void signalRService.sfuRequestKeyframe(streamerId)
      } else if (st === 'failed' || iceSt === 'failed') {
        const wd = this.sfuSubWatchdogTimers.get(streamerId)
        if (wd) {
          clearTimeout(wd)
          this.sfuSubWatchdogTimers.delete(streamerId)
        }
        void this.switchViewerFromSfuToP2P(streamerId)
        void signalRService.sfuReportFailure(streamerId, epoch)
      }
    }
    pc.onconnectionstatechange = onStateChange
    pc.oniceconnectionstatechange = onStateChange

    const watchdog = setTimeout(() => {
      this.sfuSubWatchdogTimers.delete(streamerId)
      if (this.sfuSubConnections.get(streamerId) === pc && (!subConnected || !videoAttached)) {
        void this.switchViewerFromSfuToP2P(streamerId)
        void signalRService.sfuReportFailure(streamerId, epoch)
      }
    }, 10000)
    this.sfuSubWatchdogTimers.set(streamerId, watchdog)

    try {
      const offer = await pc.createOffer(SILENCE_SUPPRESSION_OFF)
      const optimizedSDP = optimizeSDP(offer.sdp!, this.relayOnlyIce, false, 20)
      await pc.setLocalDescription({ type: 'offer', sdp: optimizedSDP })
      await this.waitForIceGatheringComplete(pc, 1200)
      if (this.sfuSubConnections.get(streamerId) !== pc) return

      const res = await signalRService.sfuSubscribe(streamerId, epoch, pc.localDescription!.sdp)
      if (this.sfuSubConnections.get(streamerId) !== pc) return
      if (!res || !res.ok || !res.answerSdp) {
        void this.switchViewerFromSfuToP2P(streamerId)
        void signalRService.sfuReportFailure(streamerId, epoch)
        return
      }

      await pc.setRemoteDescription({ type: 'answer', sdp: res.answerSdp })
      setTimeout(() => {
        if (this.sfuSubConnections.get(streamerId) === pc && !videoAttached) {
          void signalRService.sfuRequestKeyframe(streamerId)
        }
      }, 300)
    } catch {
      if (this.sfuSubConnections.get(streamerId) === pc) {
        void this.switchViewerFromSfuToP2P(streamerId)
        void signalRService.sfuReportFailure(streamerId, epoch)
      }
    }
  }

  public async switchViewerFromSfuToP2P(streamerId: string, immediate = false) {
    const pending = this.p2pSwitchTasks.get(streamerId)
    if (pending) return pending
    const task = this.switchViewerFromSfuToP2POperation(streamerId, immediate)
    this.p2pSwitchTasks.set(streamerId, task)
    try { await task }
    finally { if (this.p2pSwitchTasks.get(streamerId) === task) this.p2pSwitchTasks.delete(streamerId) }
  }

  private async waitForVideoProgress(pc: RTCPeerConnection, timeoutMs = 6500): Promise<boolean> {
    const deadline = performance.now() + timeoutMs
    let firstFrames: number | undefined
    while (performance.now() < deadline && pc.connectionState !== 'closed') {
      const stats = await pc.getStats().catch(() => null)
      let frames = 0
      stats?.forEach(report => { if (report.type === 'inbound-rtp' && report.kind === 'video') frames += report.framesDecoded ?? 0 })
      if (firstFrames !== undefined && frames > firstFrames) return true
      firstFrames ??= frames
      await new Promise(resolve => setTimeout(resolve, 250))
    }
    return false
  }

  private async switchViewerFromSfuToP2POperation(streamerId: string, immediate = false) {
    const generation = this.mediaSessionGeneration
    const sfuPc = this.sfuSubConnections.get(streamerId)
    const isControlling = immediate || useAppStore.getState().isRemoteControlling
    const p2pPc = this.peerConnections.get(streamerId)
    let p2pVideoStream = this.p2pStreamsBackup.get(streamerId)
    if ((!p2pVideoStream || p2pVideoStream.getVideoTracks().every(t => t.readyState === 'ended')) && p2pPc && p2pPc.connectionState !== 'closed') {
      const vRec = p2pPc.getReceivers().find(r => r.track && r.track.kind === 'video' && r.track.readyState !== 'ended')
      if (vRec?.track) {
        p2pVideoStream = new MediaStream([vRec.track])
        this.p2pStreamsBackup.set(streamerId, p2pVideoStream)
        this.applyVideoZeroPlayoutDelay(vRec)
      }
    }

    const fresh = !sfuPc || !p2pPc || await this.waitForVideoProgress(p2pPc)
    if (generation !== this.mediaSessionGeneration || this.sfuSubConnections.get(streamerId) !== sfuPc || this.peerConnections.get(streamerId) !== p2pPc) return
    const hasP2PVideo = Boolean(fresh && p2pVideoStream && await this.waitForFirstVideoFrame(p2pVideoStream))
    if (hasP2PVideo && p2pVideoStream) {
      this.closeSfuSubscriber(streamerId, false)
      this.attachRemoteVideo(streamerId, p2pVideoStream.getVideoTracks()[0], p2pVideoStream, false)
    }
    const audioBackup = this.p2pAudioBackup.get(streamerId)
    if (audioBackup && audioBackup.track.readyState !== 'ended') {
      this.attachRemoteStreamAudio(streamerId, audioBackup.track, audioBackup.receiver, audioBackup.stream, false)
    } else {
      this.syncRemoteVideoStream(streamerId)
    }
    if (isControlling) {
      this.enforceVideoZeroPlayoutDelay(streamerId)
    }
  }

  public async switchViewerToP2PForRemoteControl(streamerId: string): Promise<void> {
    await this.switchViewerFromSfuToP2P(streamerId, true)
  }

  private closeSfuSubscriber(streamerId: string, notifyServer = false) {
    const previewTimer = this.sfuPreviewTearDownTimers.get(streamerId)
    if (previewTimer) {
      clearTimeout(previewTimer)
      this.sfuPreviewTearDownTimers.delete(streamerId)
    }
    const wdTimer = this.sfuSubWatchdogTimers.get(streamerId)
    if (wdTimer) {
      clearTimeout(wdTimer)
      this.sfuSubWatchdogTimers.delete(streamerId)
    }
    this.sfuSubEpochs.delete(streamerId)
    const pc = this.sfuSubConnections.get(streamerId)
    if (pc) {
      this.sfuSubConnections.delete(streamerId)
      try {
        pc.ontrack = null
        pc.onconnectionstatechange = null
        pc.oniceconnectionstatechange = null
        pc.close()
      } catch { }
      if (notifyServer) {
        void signalRService.sfuUnsubscribe(streamerId)
      }
    }
  }

  public leaveAll() {
    this.mediaSessionGeneration++
    this.p2pSwitchTasks.clear()
    this.stopAudioHealthMonitoring()
    this.stopStreamSyncMonitoring()
    this.pendingSfuPublish = null
    this.sfuFallbackPeers.clear()
    this.closeSfuPublisher()
    for (const streamerId of [...this.sfuSubConnections.keys()]) {
      this.closeSfuSubscriber(streamerId, false)
    }
    this.sfuSubWatchdogTimers.forEach(t => clearTimeout(t))
    this.sfuSubWatchdogTimers.clear()
    this.sfuPreviewTearDownTimers.forEach(t => clearTimeout(t))
    this.sfuPreviewTearDownTimers.clear()
    this.streamDeliveryModes.clear()
    this.p2pStreamsBackup.clear()
    this.p2pAudioBackup.clear()
    if (this.viewInterestTimer) {
      clearTimeout(this.viewInterestTimer)
      this.viewInterestTimer = null
    }
    if (this.settingsUpdateTimer) {
      clearTimeout(this.settingsUpdateTimer)
      this.settingsUpdateTimer = null
    }
    this.pendingSettingsUpdate = null
    this.settingsWaiters.forEach(w => w.resolve())
    this.settingsWaiters = []

    this.dcTimers.forEach(t => clearTimeout(t))
    this.dcTimers.clear()
    this.iceTimeoutTimers.forEach(t => clearTimeout(t))
    this.iceTimeoutTimers.clear()

    this.peerConnections.forEach((_, uid) => this.disconnectFromPeer(uid))
    this.iceRestartInFlight.clear()

    this.stopUltraSend()
    this.ultraSendTargets.clear()
    this.ultraSendUnsupported = false
    this.ultraSendStartFailures = 0
    this.ultraSendLastError = ''
    this.ultraRcvStats.clear()
    this.ultraDataChannels.forEach(ch => { try { ch.onopen = ch.onclose = ch.onerror = ch.onmessage = null; ch.close() } catch { } })
    this.ultraDataChannels.clear()

    this.ultraDecoders.forEach(dec => { try { if (dec.state !== 'closed') dec.close() } catch { } })
    this.ultraDecoders.clear()
    this.ultraJitterNodes.forEach(node => { try { node.port.onmessage = null; node.disconnect() } catch { } })
    this.ultraJitterNodes.clear()
    this.ultraJitterGains.forEach(gain => { try { gain.disconnect() } catch { } })
    this.ultraJitterGains.clear()
    this.ultraReorderBuffers.clear()
    this.ultraLastDecodedTs.clear()
    this.ultraCustomUsers.clear()
    this.ultraCustomUnderruns.clear()
    this.ultraCustomBufferMs.clear()
    this.ultraCustomTargetMs.clear()
    this.ultraCustomSpeaking.clear()
    this.ultraCustomGotFrame.clear()
    this.ultraCustomHandedOver.clear()

    if (this.ultraOutputContext && this.ultraOutputContext.state !== 'closed') {
      void this.ultraOutputContext.close().catch(() => {})
      this.ultraOutputContext = null
    }
    this.ultraJitterModuleContext = null
    this.ultraJitterLoadingContext = null
    this.ultraJitterModulePromise = null

    this.ultraCustomEngaging.clear()
    this.ultraCustomFailed.clear()
    this.ultraCustomFailCount.clear()
    this.ultraCustomLastAudioAt.clear()
    this.ultraHiResends.clear()
    this.pendingCandidates.clear()
    this.pendingRenegotiation.clear()
    this.pendingIceRestart.clear()
    this.peerSignalingQueues.clear()
    this.isMakingOffer.clear()
    this.isSettingRemoteAnswerPending.clear()
    this.offerEpoch.clear()
    this.userVoiceTrackIds.clear()
    this.userStreamAudioTrackIds.clear()
    this.userVoiceStreamIds.clear()
    this.userScreenStreamIds.clear()

    this.userSourceNodes.forEach(s => { try { s.disconnect() } catch { } })
    this.userSourceNodes.clear()
    this.userGainNodes.forEach(g => { try { g.disconnect() } catch { } })
    this.userGainNodes.clear()
    this.userLimiterNodes.forEach(l => { try { l.disconnect() } catch { } })
    this.userLimiterNodes.clear()
    this.userPannerNodes.forEach(p => { try { p.disconnect() } catch { } })
    this.userPannerNodes.clear()
    this.voiceSeatOrder = []

    this.streamGainNodes.forEach(g => { try { g.disconnect() } catch { } })
    this.streamGainNodes.clear()
    this.streamSourceNodes.forEach(s => { try { s.disconnect() } catch { } })
    this.streamSourceNodes.clear()
    this.streamLimiterNodes.forEach(l => { try { l.disconnect() } catch { } })
    this.streamLimiterNodes.clear()
    this.streamDelayNodes.forEach(d => { try { d.disconnect() } catch { } })
    this.streamDelayNodes.clear()

    this.audioElements.forEach(el => { try { el.pause(); el.srcObject = null } catch { } })
    this.audioElements.clear()
    this.streamAudioElements.forEach(el => { try { el.pause(); el.srcObject = null } catch { } })
    this.streamAudioElements.clear()
  }
}

export const webrtc = new WebRTCManager()
export const webrtcService = webrtc
