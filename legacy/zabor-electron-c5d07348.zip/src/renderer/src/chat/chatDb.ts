import type { ChatMessage } from './types';

const DB_NAME = 'zabor-chat-v1';
const DB_VERSION = 1;
const STORE_NAME = 'messages';
const RETENTION_MS = 14 * 24 * 60 * 60 * 1000;

let openPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (openPromise) return openPromise;
  openPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      const store = db.createObjectStore(STORE_NAME, { keyPath: ['ownerId', 'id'] });
      store.createIndex('ownerConversation', ['ownerId', 'conversationId', 'createdAt']);
      store.createIndex('ownerCreatedAt', ['ownerId', 'createdAt']);
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => { db.close(); openPromise = null; };
      resolve(db);
    };
    request.onerror = () => reject(request.error);
  });
  void openPromise.catch(() => { openPromise = null; });
  return openPromise;
}

function requestValue<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function transactionComplete(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new Error('chat-transaction-aborted'));
    transaction.onerror = () => reject(transaction.error ?? new Error('chat-transaction-failed'));
  });
}

export async function loadConversation(ownerId: string, conversationId: string): Promise<ChatMessage[]> {
  const db = await openDb();
  const tx = db.transaction(STORE_NAME, 'readonly');
  const index = tx.objectStore(STORE_NAME).index('ownerConversation');
  const range = IDBKeyRange.bound([ownerId, conversationId, 0], [ownerId, conversationId, Number.MAX_SAFE_INTEGER]);
  return requestValue(index.getAll(range));
}

export async function saveMessage(message: ChatMessage): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(STORE_NAME, 'readwrite');
  const completion = transactionComplete(tx);
  tx.objectStore(STORE_NAME).put(message);
  await completion;
}

export async function deleteMessage(ownerId: string, id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(STORE_NAME, 'readwrite');
  const completion = transactionComplete(tx);
  tx.objectStore(STORE_NAME).delete([ownerId, id]);
  await completion;
}

export async function loadPending(ownerId: string): Promise<ChatMessage[]> {
  const db = await openDb();
  const tx = db.transaction(STORE_NAME, 'readonly');
  const index = tx.objectStore(STORE_NAME).index('ownerCreatedAt');
  const range = IDBKeyRange.bound([ownerId, 0], [ownerId, Number.MAX_SAFE_INTEGER]);
  const messages = await requestValue(index.getAll(range));
  return messages.filter(message => message.senderId === ownerId && (message.delivery === 'pending' || message.delivery === 'sent'));
}

export async function pruneExpired(ownerId: string): Promise<void> {
  const db = await openDb();
  const readTx = db.transaction(STORE_NAME, 'readonly');
  const index = readTx.objectStore(STORE_NAME).index('ownerCreatedAt');
  const range = IDBKeyRange.bound([ownerId, 0], [ownerId, Date.now() - RETENTION_MS]);
  const expired = await requestValue(index.getAll(range));
  if (expired.length === 0) return;
  const storedNames = expired.flatMap(message => message.file?.storedName ? [message.file.storedName] : []);
  const uniqueStoredNames = [...new Set(storedNames)];
  if (uniqueStoredNames.length) {
    const removed = await window.windowControls.chatFileDeleteMany(uniqueStoredNames);
    if (removed !== uniqueStoredNames.length) throw new Error('chat-file-cleanup-failed');
  }
  const deleteTx = db.transaction(STORE_NAME, 'readwrite');
  const completion = transactionComplete(deleteTx);
  const deleteStore = deleteTx.objectStore(STORE_NAME);
  for (const message of expired) deleteStore.delete([ownerId, message.id]);
  await completion;
}
