import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { DownloadSimple, ArrowSquareOut, File, Paperclip, PaperPlaneRight, Trash, Copy, Broom, PhoneCall, X, Info } from '@phosphor-icons/react';
import { useTranslation } from 'react-i18next';
import { useAppStore, type User } from '../../store/useAppStore';
import { useChatStore } from '../../store/useChatStore';
import type { ChatMessage } from '../../chat/types';
import { chatPeer } from '../../services/chatPeer';
import { animate, play, utils, springs, stagger, EASE_OUT, EASE_IN, DUR, prefersReducedMotion } from '../../lib/anime';

interface ChatPanelProps {
  currentUser: User;
  friend: User;
  onCall: () => void;
  onOpenProfile?: () => void;
}

const EMPTY_MESSAGES: ChatMessage[] = [];
const BASE_INPUT_HEIGHT = 44;
const MAX_INPUT_HEIGHT = 132;

function computeChatInputHeight(scrollHeight: number): number {
  const lines = Math.max(1, Math.round((scrollHeight - 24) / 20));
  if (lines < 3) return BASE_INPUT_HEIGHT;
  const step = Math.min(3, Math.floor(lines / 3));
  if (step === 1) return 74;
  if (step === 2) return 104;
  return MAX_INPUT_HEIGHT;
}

function formatSize(bytes: number, unit: (key: string) => string): string {
  if (bytes < 1024) return `${bytes} ${unit('chat.units.b')}`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} ${unit('chat.units.kb')}`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} ${unit('chat.units.mb')}`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} ${unit('chat.units.gb')}`;
}

function renderMessageContent(text: string) {
  if (!text) return null;
  const regex = /(https?:\/\/[^\s<]+|www\.[^\s<]+)/gi;
  const parts: Array<{ type: 'text' | 'link'; content: string; url?: string }> = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const matchStart = match.index;
    if (matchStart > lastIndex) {
      parts.push({ type: 'text', content: text.slice(lastIndex, matchStart) });
    }

    let rawUrl = match[0];
    let trailingPunctuation = '';

    while (rawUrl.length > 0) {
      const lastChar = rawUrl[rawUrl.length - 1];
      if (['.', ',', ';', ':', '!', '?'].includes(lastChar)) {
        trailingPunctuation = lastChar + trailingPunctuation;
        rawUrl = rawUrl.slice(0, -1);
      } else if (lastChar === ')') {
        const openCount = (rawUrl.match(/\(/g) || []).length;
        const closeCount = (rawUrl.match(/\)/g) || []).length;
        if (closeCount > openCount) {
          trailingPunctuation = lastChar + trailingPunctuation;
          rawUrl = rawUrl.slice(0, -1);
        } else {
          break;
        }
      } else {
        break;
      }
    }

    if (rawUrl.length > 0) {
      const href = /^https?:\/\//i.test(rawUrl) ? rawUrl : `https://${rawUrl}`;
      parts.push({ type: 'link', content: rawUrl, url: href });
    }

    if (trailingPunctuation) {
      parts.push({ type: 'text', content: trailingPunctuation });
    }

    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < text.length) {
    parts.push({ type: 'text', content: text.slice(lastIndex) });
  }

  return parts.map((part, index) => {
    if (part.type === 'link' && part.url) {
      return (
        <a
          key={index}
          href={part.url}
          onClick={event => {
            event.preventDefault();
            event.stopPropagation();
            if (part.url) {
              if (window.windowControls?.openExternalUrl) {
                void window.windowControls.openExternalUrl(part.url);
              } else {
                window.open(part.url, '_blank', 'noopener,noreferrer');
              }
            }
          }}
          draggable={false}
          className="text-blue-400 hover:text-blue-300 underline underline-offset-2 break-all cursor-pointer transition-colors select-text"
          title={part.url}
          target="_blank"
          rel="noopener noreferrer"
        >
          {part.content}
        </a>
      );
    }
    return <span key={index} className="select-text cursor-default">{part.content}</span>;
  });
}

export function ChatPanel({ currentUser, friend, onCall, onOpenProfile }: ChatPanelProps) {
  const { t } = useTranslation();
  const handleOpenProfile = () => {
    if (onOpenProfile) {
      onOpenProfile();
    } else {
      useAppStore.getState().setSelectedProfileUser(friend, 'friends');
      useAppStore.getState().setModal('profile', true);
    }
  };
  const storedMessages = useChatStore(state => state.messages[friend.id]);
  const messages = storedMessages ?? EMPTY_MESSAGES;
  const connected = useChatStore(state => state.connections[friend.id] ?? false);
  const route = useChatStore(state => state.routes[friend.id] ?? 'unknown');
  const [value, setValue] = useState('');
  const [inputHeight, setInputHeight] = useState(BASE_INPUT_HEIGHT);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const mirrorRef = useRef<HTMLTextAreaElement>(null);
  const valueRef = useRef(value);
  valueRef.current = value;

  const updateInputHeight = useCallback(() => {
    const textarea = textareaRef.current;
    const mirror = mirrorRef.current;
    if (!textarea || !mirror) return;

    const text = valueRef.current;
    if (!text) {
      setInputHeight(BASE_INPUT_HEIGHT);
      return;
    }

    const clientWidth = textarea.clientWidth;
    if (clientWidth > 0) {
      mirror.style.width = `${clientWidth}px`;
    }
    mirror.value = text;
    const targetHeight = computeChatInputHeight(mirror.scrollHeight);
    setInputHeight(prev => (prev !== targetHeight ? targetHeight : prev));
  }, []);

  useLayoutEffect(() => {
    updateInputHeight();
  }, [value, updateInputHeight]);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const handleResize = () => {
      updateInputHeight();
    };

    window.addEventListener('resize', handleResize);
    const resizeObserver = typeof ResizeObserver !== 'undefined'
      ? new ResizeObserver(handleResize)
      : null;
    resizeObserver?.observe(textarea);

    return () => {
      window.removeEventListener('resize', handleResize);
      resizeObserver?.disconnect();
    };
  }, [updateInputHeight]);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const isAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight <= 100;
    if (isAtBottom) {
      bottomRef.current?.scrollIntoView({ block: 'end' });
    }
  }, [inputHeight]);
  const [dragging, setDragging] = useState(false);
  const [droppedFiles, setDroppedFiles] = useState<File[]>([]);
  const dragDepth = useRef(0);
  const [menu, setMenu] = useState<{ x: number; y: number; message: ChatMessage; selectedText?: string } | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const sendRef = useRef<HTMLButtonElement>(null);
  const staggerFriendRef = useRef<string | null>(null);
  const prevLenRef = useRef(0);

  useEffect(() => { void chatPeer.open(friend.id); }, [friend.id]);
  useEffect(() => () => chatPeer.keepWarm(friend.id), [friend.id]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ block: 'end' }); }, [messages.length]);
  useLayoutEffect(() => {
    const el = rootRef.current;
    if (!el) return;
    if (prefersReducedMotion()) { utils.set(el, { opacity: 1, scale: 1, translateY: 0 }); return; }
    utils.set(el, { opacity: 0, scale: 0.985, translateY: 8 });
    void play(el, { opacity: [0, 1], scale: [0.985, 1], translateY: [8, 0], duration: DUR.base, ease: EASE_OUT });
  }, []);
  useLayoutEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const total = messages.length;
    if (staggerFriendRef.current !== friend.id) {
      staggerFriendRef.current = friend.id;
      prevLenRef.current = total;
      if (prefersReducedMotion()) return;
      const bubbles = Array.from(container.querySelectorAll<HTMLElement>('[data-bubble]'));
      const incoming = bubbles.filter(node => node.getAttribute('data-dir') === 'in');
      const outgoing = bubbles.filter(node => node.getAttribute('data-dir') === 'out');
      if (incoming.length) {
        utils.set(incoming, { opacity: 0, translateX: -16 });
        animate(incoming, { opacity: [0, 1], translateX: [-16, 0], duration: DUR.base, ease: EASE_OUT, delay: stagger(30) });
      }
      if (outgoing.length) {
        utils.set(outgoing, { opacity: 0, translateX: 16 });
        animate(outgoing, { opacity: [0, 1], translateX: [16, 0], duration: DUR.base, ease: EASE_OUT, delay: stagger(30) });
      }
      return;
    }
    if (total <= prevLenRef.current) { prevLenRef.current = total; return; }
    const added = total - prevLenRef.current;
    prevLenRef.current = total;
    if (prefersReducedMotion()) return;
    const all = Array.from(container.querySelectorAll<HTMLElement>('[data-bubble]'));
    all.slice(-added).forEach(node => {
      const fromX = node.getAttribute('data-dir') === 'out' ? 16 : -16;
      utils.set(node, { opacity: 0, translateX: fromX });
      animate(node, { opacity: [0, 1], translateX: [fromX, 0], duration: DUR.base, ease: EASE_OUT });
    });
  }, [friend.id, messages.length]);
  useEffect(() => {
    const markRead = () => { if (document.visibilityState === 'visible') void chatPeer.markVisibleAsRead(friend.id); };
    markRead();
    document.addEventListener('visibilitychange', markRead);
    window.addEventListener('focus', markRead);
    return () => {
      document.removeEventListener('visibilitychange', markRead);
      window.removeEventListener('focus', markRead);
    };
  }, [friend.id, storedMessages]);
  useEffect(() => {
    if (!menu) return;
    const safeMargin = 32;
    const handleMouseMove = (event: MouseEvent) => {
      const element = menuRef.current;
      if (!element) return;
      const rect = element.getBoundingClientRect();
      const isNear = event.clientX >= rect.left - safeMargin
        && event.clientX <= rect.right + safeMargin
        && event.clientY >= rect.top - safeMargin
        && event.clientY <= rect.bottom + safeMargin;
      if (!isNear) setMenu(null);
    };
    const handlePointerDown = (event: PointerEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) setMenu(null);
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('pointerdown', handlePointerDown);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('pointerdown', handlePointerDown);
    };
  }, [menu]);

  const canSend = value.trim().length > 0 && value.trim().length <= 4000;
  const status = useMemo(() => connected ? t('chat.connected') : friend.isOnline ? t('chat.connecting') : t('chat.offline'), [connected, friend.isOnline, t]);

  const send = async () => {
    if (!canSend) return;
    const text = value;
    setValue('');
    setInputHeight(BASE_INPUT_HEIGHT);
    void play(sendRef.current, { scale: [0.9, 1], ease: springs.press });
    await chatPeer.sendText(friend.id, text);
  };

  const download = async (message: ChatMessage) => {
    const file = message.file;
    if (!file) return;
    const own = message.senderId === currentUser.id;
    if (file.savedPath) {
      if (await window.windowControls.chatFileRevealPath(file.savedPath)) return;
      await useChatStore.getState().upsert({ ...message, file: { ...file, savedPath: null } });
    }
    if (file.storedName) {
      const dest = await window.windowControls.chatFilePickSavePath(file.name);
      if (!dest) return;
      if (await window.windowControls.chatFileSaveTo(file.storedName, dest)) {
        await useChatStore.getState().upsert({ ...message, file: { ...file, savedPath: dest } });
        return;
      }
      if (own) return;
      const cleared: ChatMessage = { ...message, file: { ...file, storedName: null, savedPath: null, transferState: 'missing', progress: 0 } };
      await useChatStore.getState().upsert(cleared);
      await chatPeer.requestFile(cleared, dest);
      return;
    }
    if (own) return;
    const dest = await window.windowControls.chatFilePickSavePath(file.name);
    if (!dest) return;
    await chatPeer.requestFile(message, dest);
  };

  const handleDragEnter = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragDepth.current += 1;
    if (event.dataTransfer.types.includes('Files')) setDragging(true);
  };

  const handleDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragDepth.current -= 1;
    if (dragDepth.current <= 0) {
      dragDepth.current = 0;
      setDragging(false);
    }
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragDepth.current = 0;
    setDragging(false);
    const files = Array.from(event.dataTransfer.files);
    if (files.length > 0) setDroppedFiles(files);
  };

  const confirmDroppedFiles = async () => {
    const paths = droppedFiles.map(file => window.windowControls.getPathForFile(file)).filter((path): path is string => Boolean(path));
    setDroppedFiles([]);
    await chatPeer.sendDroppedFiles(friend.id, paths);
  };

  return (
    <div ref={rootRef} className="absolute inset-3 z-[80] bg-panelBg border border-white/[0.07] border-t-white/[0.14] rounded-panel flex flex-col overflow-hidden" onDragEnter={handleDragEnter} onDragOver={event => event.preventDefault()} onDragLeave={handleDragLeave} onDrop={handleDrop}>
      <div className="h-16 px-4 grid grid-cols-[40px_minmax(0,1fr)_40px] items-center gap-3 border-b border-white/[0.07] shrink-0">
        <div className="group relative flex items-center justify-center" aria-label={t('chat.information')}>
          <Info weight="bold" size={18} className="text-white/30 transition-colors group-hover:text-white/70" />
          <div role="tooltip" className="pointer-events-none absolute left-0 top-[calc(100%+12px)] z-[100] w-64 rounded-[14px] border border-white/[0.07] border-t-white/[0.14] bg-panelBg/95 p-3 text-left opacity-0 backdrop-blur-xl transition-opacity group-hover:opacity-100">
            <div className="text-sm font-medium text-white">{t('chat.retentionHint')}</div>
            <div className="mt-2 text-xs text-textMuted">{t('chat.encryptionHint')}</div>
            {connected && route !== 'unknown' && (
              <div className="mt-2 pt-2 border-t border-white/[0.06] text-xs text-primaryText/90 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block"></span>
                <span>{route === 'p2p' ? t('chat.routeP2p') : route === 'turn' ? t('chat.routeTurn') : t('chat.routeRelay')}</span>
              </div>
            )}
          </div>
        </div>
        <div className="min-w-0 flex flex-col items-center justify-center">
          <button
            type="button"
            onClick={handleOpenProfile}
            className="group max-w-full inline-flex items-center justify-center px-2.5 py-0.5 -my-0.5 rounded-lg hover:bg-white/[0.08] active:bg-white/[0.12] active:scale-[0.98] transition-all cursor-pointer select-none"
            title={t('contextMenu.profile', 'профиль')}
          >
            <span className="font-bold text-white group-hover:text-primaryText transition-colors truncate">
              {friend.displayName}
            </span>
          </button>
          <div className="text-xs text-textMuted truncate max-w-full">{status}</div>
        </div>
        <button onClick={onCall} disabled={!friend.isOnline} className="w-10 h-10 rounded-full bg-surface/70 hover:bg-surfaceHover/80 disabled:opacity-40 text-success flex items-center justify-center transition-transform active:scale-95" title={t('chat.call')}>
          <PhoneCall weight="bold" size={19} />
        </button>
      </div>

      <div ref={scrollRef} className="chat-scroll flex-1 min-h-0 overflow-y-auto p-4">
        {messages.length === 0 ? (
          <div className="h-full flex items-center justify-center text-textMuted font-medium">{t('chat.empty')}</div>
        ) : (
          <div className="flex flex-col gap-2">
            {messages.map(message => {
              const own = message.senderId === currentUser.id;
              return (
                <div key={message.id} className={`flex ${own ? 'justify-end' : 'justify-start'}`}>
                  <div
                    data-bubble
                    data-dir={own ? 'out' : 'in'}
                    onContextMenu={event => {
                      event.preventDefault();
                      event.stopPropagation();
                      const selection = window.getSelection();
                      const rawSelected = selection ? selection.toString() : '';
                      const isInside = Boolean(
                        rawSelected &&
                        selection &&
                        selection.rangeCount > 0 &&
                        event.currentTarget.contains(selection.getRangeAt(0).commonAncestorContainer)
                      );
                      setMenu({
                        x: Math.min(event.clientX, window.innerWidth - 208),
                        y: Math.min(event.clientY, window.innerHeight - 180),
                        message,
                        selectedText: isInside ? rawSelected : undefined
                      });
                    }}
                    className={`max-w-[72%] rounded-[14px] px-4 py-3 border ${own ? 'bg-primary/20 border-primary/30' : 'bg-surface/70 border-white/[0.07]'}`}
                  >
                    {message.kind === 'text' ? (
                      <p className="text-white text-sm whitespace-pre-wrap break-words select-text cursor-default">{renderMessageContent(message.text)}</p>
                    ) : message.file && (
                      <div className="flex items-center gap-3 min-w-[240px] select-none">
                        <div className="w-10 h-10 rounded-xl bg-white/[0.06] flex items-center justify-center shrink-0"><File weight="bold" size={20} /></div>
                        <div className="min-w-0 flex-1">
                          <div className="text-white text-sm font-semibold truncate">{message.file.name}</div>
                          <div className="text-textMuted text-xs">{formatSize(message.file.size, t)}</div>
                          {message.file.transferState === 'transferring' && <div className="h-1 bg-black/30 rounded-full overflow-hidden mt-2"><div className="h-full bg-primary origin-left" style={{ transform: `scaleX(${message.file.progress})` }} /></div>}
                          {message.file.transferState === 'deleted' && <div className="text-danger text-xs mt-1">{own ? t('chat.file.deletedByYou') : t('chat.file.deletedBySender')}</div>}
                          {message.file.transferState === 'failed' && <div className="text-warning text-xs mt-1">{t('chat.file.failed')}</div>}
                        </div>
                        {message.file.transferState === 'transferring' ? (
                          <button onClick={() => void chatPeer.cancelDownload(message)} className="w-9 h-9 rounded-xl bg-surface/70 hover:bg-surfaceHover/80 flex items-center justify-center active:scale-95" title={t('chat.cancel')}>
                            <X weight="bold" size={17} />
                          </button>
                        ) : (message.file.savedPath || message.file.transferState !== 'deleted') && (
                          <button onClick={() => void download(message)} className="w-9 h-9 rounded-xl bg-surface/70 hover:bg-surfaceHover/80 flex items-center justify-center active:scale-95" title={message.file.savedPath ? t('chat.openFile') : t('chat.download')}>
                            {message.file.savedPath ? <ArrowSquareOut weight="bold" size={17} /> : <DownloadSimple weight="bold" size={17} />}
                          </button>
                        )}
                      </div>
                    )}
                    <div className="mt-1.5 text-[10px] text-white/35 text-right select-none">
                      {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}{own ? ` · ${t(`chat.delivery.${message.delivery}`)}` : ''}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      <div className="p-4 border-t border-white/[0.07] flex items-end gap-2 shrink-0">
        <button onClick={() => void chatPeer.sendFiles(friend.id)} className="w-11 h-11 rounded-[14px] bg-surface/70 hover:bg-surfaceHover/80 text-white flex items-center justify-center transition-transform active:scale-95" title={t('chat.attach')}>
          <Paperclip weight="bold" size={20} />
        </button>
        <textarea
          ref={textareaRef}
          value={value}
          onChange={event => setValue(event.target.value.slice(0, 4000))}
          onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); void send(); } }}
          rows={1}
          placeholder={t('chat.placeholder')}
          style={{ height: `${inputHeight}px` }}
          className="glass-field flex-1 resize-none min-h-11 max-h-[132px] px-4 py-3 text-sm leading-5 rounded-[14px] break-words overflow-x-hidden overflow-y-auto transition-[height] duration-200 ease-[cubic-bezier(0.16,1,0.3,1)]"
        />
        <textarea
          ref={mirrorRef}
          tabIndex={-1}
          aria-hidden="true"
          readOnly
          rows={1}
          className="glass-field px-4 py-3 text-sm leading-5 resize-none break-words pointer-events-none fixed -top-[9999px] -left-[9999px] opacity-0 invisible -z-50 select-none overflow-hidden"
          style={{
            height: 'auto',
            minHeight: `${BASE_INPUT_HEIGHT}px`,
            boxSizing: 'border-box'
          }}
        />
        <button ref={sendRef} onClick={() => void send()} disabled={!canSend} className="w-11 h-11 rounded-[14px] bg-primary/90 hover:opacity-90 disabled:opacity-40 text-white flex items-center justify-center transition-transform active:scale-95">
          <PaperPlaneRight weight="bold" size={20} />
        </button>
      </div>

      {menu && createPortal(
        <div ref={menuRef} className="fixed z-[999999] glass-sheet py-2 w-48 rounded-[14px] select-none" style={{ left: menu.x, top: menu.y }} onClick={event => event.stopPropagation()} onContextMenu={event => { event.preventDefault(); event.stopPropagation(); }}>
          {menu.message.kind === 'text' && (
            <>
              {menu.selectedText ? (
                <>
                  <button onClick={() => { void navigator.clipboard.writeText(menu.selectedText!); setMenu(null); }} className="w-full text-left px-4 py-2 flex items-center gap-3 text-white hover:bg-surfaceHover/80 select-none"><Copy weight="bold" size={16} />{t('chat.copySelected')}</button>
                  <button onClick={() => { void navigator.clipboard.writeText(menu.message.text); setMenu(null); }} className="w-full text-left px-4 py-2 flex items-center gap-3 text-white hover:bg-surfaceHover/80 select-none"><Copy weight="bold" size={16} />{t('chat.copy')}</button>
                </>
              ) : (
                <button onClick={() => { void navigator.clipboard.writeText(menu.message.text); setMenu(null); }} className="w-full text-left px-4 py-2 flex items-center gap-3 text-white hover:bg-surfaceHover/80 select-none"><Copy weight="bold" size={16} />{t('chat.copy')}</button>
              )}
            </>
          )}
          {menu.message.file?.storedName && <button onClick={() => { void chatPeer.clearFile(menu.message); setMenu(null); }} className="w-full text-left px-4 py-2 flex items-center gap-3 text-white hover:bg-surfaceHover/80"><Broom weight="bold" size={16} />{t('chat.clearFile')}</button>}
          <button onClick={() => { void chatPeer.deleteLocal(menu.message); setMenu(null); }} className="w-full text-left px-4 py-2 flex items-center gap-3 text-danger hover:bg-surfaceHover/80"><Trash weight="bold" size={16} />{t('chat.deleteMessage')}</button>
        </div>,
        document.body
      )}
      {dragging && (
        <div className="absolute inset-0 z-[99999] bg-black/70 backdrop-blur-md flex items-center justify-center pointer-events-none">
          <div className="glass-modal w-[400px] p-8 text-center">
            <PaperPlaneRight weight="bold" size={40} className="mx-auto mb-4 text-primaryText" />
            <div className="text-xl font-bold text-white">{t('chat.dropToSend')}</div>
          </div>
        </div>
      )}
      {droppedFiles.length > 0 && createPortal(
        <div className="fixed inset-0 z-[100000] bg-black/70 backdrop-blur-md flex items-center justify-center p-3 pt-[3.75rem]">
          <div className="glass-modal w-[400px] p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">{t('chat.sendFileConfirm')}</h2>
              <button onClick={() => setDroppedFiles([])} className="p-1.5 rounded-lg text-textMuted hover:text-white hover:bg-surface/70 transition-colors"><X weight="bold" size={24} /></button>
            </div>
            <div className="max-h-48 overflow-y-auto space-y-2 mb-6">
              {droppedFiles.map((file, index) => <div key={`${file.name}-${index}`} className="glass-field rounded-xl p-3 text-sm text-white truncate">{file.name}</div>)}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setDroppedFiles([])} className="py-3 rounded-xl font-bold bg-surface/70 text-white hover:bg-surfaceHover/80 active:scale-[0.98] transition-all">{t('common.cancel')}</button>
              <button onClick={() => void confirmDroppedFiles()} className="py-3 rounded-xl font-bold bg-primary/90 text-white hover:opacity-90 active:scale-[0.98] transition-all">{t('chat.sendFile')}</button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
