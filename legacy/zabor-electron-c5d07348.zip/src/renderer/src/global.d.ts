/// <reference types="vite/client" />

export {};

interface StreamAudioMetadata {
  sampleRate: number;
  channels: number;
  bitsPerSample: number;
  isFloat: boolean;
}

export interface UpdateInfo {
  version: string;
  currentVersion: string;
  releaseName: string;
  releaseNotes: string;
  publishedAt: string;
  downloadUrl: string;
  releaseUrl: string;
  fileSize: number;
  sha256?: string;
}

export interface UpdateProgress {
  percent: number;
  transferred: number;
  total: number;
}

export interface UpdateCheckResult {
  updateAvailable: boolean;
  currentVersion: string;
  updateInfo?: UpdateInfo;
  error?: string;
}

export type UpdateStatus = 'idle' | 'available' | 'downloading' | 'downloaded' | 'installing' | 'error';

export interface UpdateSnapshot {
  status: UpdateStatus;
  updateInfo: UpdateInfo | null;
  progress: UpdateProgress | null;
  error: string | null;
}

declare global {
  interface Window {
    electron: {
      process: {
        versions: Record<string, string>;
      };
    };
    windowControls: {
      writeDiagnostic?: (record: unknown) => void;
      diagnosticsDirectory: () => Promise<string>;
      minimize: () => void;
      maximize: () => void;
      close: () => void;
      quit: () => void;
      wipeAppData: (options?: { preserveChat?: boolean }) => Promise<boolean>;
      getUserDataPath: () => Promise<string>;
      loadSileroModel: () => Promise<Uint8Array>;
      getClientRuntime: () => Promise<{ rustVoicing: boolean; channel: 'stable' | 'beta'; version: string }>;
      loadRustVoicing: () => Promise<Uint8Array | null>;
      loadDeepFilterAsset: (assetPath: string) => Promise<Uint8Array | null>;
      getAutoLaunch: () => Promise<boolean>;
      setAutoLaunch: (enabled: boolean) => Promise<boolean>;
      getMinimizeToTray: () => Promise<boolean>;
      setMinimizeToTray: (enabled: boolean) => Promise<boolean>;
      getWebrtcRelayOnly: () => Promise<boolean>;
      setWebrtcRelayOnly: (enabled: boolean) => Promise<boolean>;
      saveSession: (data: string) => Promise<boolean>;
      loadSession: () => Promise<string | null>;
      clearSession: () => Promise<boolean>;
      loadChatIdentity: () => Promise<string | null>;
      saveChatIdentity: (data: string) => Promise<boolean>;
      getPathForFile: (file: File) => string;
      chatFilePick: () => Promise<Array<{ storedName: string; name: string; size: number; sha256: string }>>;
      chatFileImport: (filePaths: string[]) => Promise<Array<{ storedName: string; name: string; size: number; sha256: string }>>;
      chatFileBegin: (transferId: string, fileName: string, size: number) => Promise<{ ok: true; storedName: string } | { ok: false; error: string }>;
      chatFileChunk: (transferId: string, chunk: Uint8Array) => Promise<{ ok: true; written: number } | { ok: false; error: string }>;
      chatFileCommit: (transferId: string) => Promise<{ ok: true; storedName: string; size: number; sha256: string } | { ok: false; error: string }>;
      chatFileAbort: (transferId: string) => Promise<boolean>;
      chatFileDelete: (storedName: string) => Promise<boolean>;
      chatFileDeleteMany: (storedNames: string[]) => Promise<number>;
      chatFileStat: (storedName: string) => Promise<{ size: number } | null>;
      chatFileHash: (storedName: string) => Promise<string | null>;
      chatFileReadOpen: (storedName: string) => Promise<string | null>;
      chatFileReadBlock: (readId: string, offset: number, length: number) => Promise<Uint8Array | null>;
      chatFileReadClose: (readId: string) => Promise<boolean>;
      chatFileSaveAs: (storedName: string, suggestedName: string) => Promise<boolean>;
      chatFileReveal: (storedName: string) => Promise<boolean>;
      chatFilePickSavePath: (suggestedName: string) => Promise<string | null>;
      chatFileSaveTo: (storedName: string, destPath: string) => Promise<boolean>;
      chatFileRevealPath: (absPath: string) => Promise<boolean>;
      chatFilesPrune: (keepNames: string[]) => Promise<number>;
      chatFilesWipe: () => Promise<boolean>;
      getClientAttestation: () => Promise<string | null>;
      onMaximizeChange: (callback: (isMaximized: boolean) => void) => () => void;
      onBeforeQuit: (callback: () => void) => () => void;
      getDesktopSources: (options?: any) => Promise<any[]>;
      startStreamAudioCapture: (sourceId: string) => Promise<boolean>;
      stopStreamAudioCapture: () => Promise<boolean>;
      onStreamAudioData: (
        callback: (data: Uint8Array, metadata: StreamAudioMetadata) => void
      ) => () => void;
      getAppVersion: () => Promise<string>;
      checkForUpdates: () => Promise<UpdateCheckResult>;
      getUpdateStatus: () => Promise<UpdateSnapshot>;
      openUpdaterWindow?: () => Promise<boolean>;
      startUpdateDownload: (
        downloadUrl: string,
        version: string
      ) => Promise<{ success: boolean; filePath?: string; error?: string }>;
      cancelUpdateDownload: () => Promise<boolean>;
      installUpdate: () => Promise<{ success: boolean; message?: string; error?: string }>;
      openExternalUrl: (url: string) => Promise<boolean>;
      onUpdateAvailable: (callback: (info: UpdateInfo) => void) => () => void;
      onUpdateDownloadProgress: (callback: (progress: UpdateProgress) => void) => () => void;
      onUpdateProgress?: (callback: (progress: UpdateProgress) => void) => () => void;
      onUpdateDownloaded: (callback: (data: { filePath: string }) => void) => () => void;
      onUpdateError: (callback: (error: string) => void) => () => void;
      onUpdateInstalling: (callback: () => void) => () => void;
      setDisplayMediaSource?: (sourceId: string | null) => Promise<boolean>;
      remoteControlStart: () => Promise<boolean>;
      remoteControlStop: () => Promise<boolean>;
      remoteControlReset: () => Promise<boolean>;
      remoteControlGetScreen: () => Promise<{ width: number; height: number; x: number; y: number }>;
      remoteControlClipCursor: (rect: { left: number; top: number; right: number; bottom: number }) => Promise<boolean>;
      remoteControlUnclipCursor: () => Promise<boolean>;
      remoteControlHideHostCursor?: () => Promise<boolean>;
      remoteControlShowHostCursor?: () => Promise<boolean>;
      remoteControlMove: (absX: number, absY: number) => void;
      remoteControlMoveNormalized: (xNorm: number, yNorm: number) => void;
      remoteControlMouseButton: (button: number, down: boolean) => void;
      remoteControlMouseWheel: (delta: number, horizontal?: number) => void;
      remoteControlKey: (vk: number, down: boolean) => void;
      remoteControlShowPill?: (data: { controllerName: string; isControlling: boolean }) => void;
      remoteControlHidePill?: () => void;
      onRemoteControlHostActivity: (callback: (data: { type: 'move' | 'click'; dist?: number }) => void) => () => void;
      onRemoteControlPanicRevoke: (callback: () => void) => () => void;
    };
  }
}

declare module '*.mp3' {
  const src: string;
  export default src;
}

declare module '@echogarden/fvad-wasm' {
  export interface FvadModule {
    _fvad_new(): number;
    _fvad_free(inst: number): void;
    _fvad_reset(inst: number): void;
    _fvad_set_mode(inst: number, mode: number): number;
    _fvad_set_sample_rate(inst: number, sampleRate: number): number;
    _fvad_process(inst: number, framePtr: number, length: number): number;
    _malloc(size: number): number;
    _free(ptr: number): void;
    HEAP16: Int16Array;
    HEAPU8: Uint8Array;
  }
  export default function fvad(options?: Record<string, unknown>): Promise<FvadModule>;
}

