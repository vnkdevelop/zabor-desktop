import { app, BrowserWindow, shell, ipcMain } from 'electron';
import { join } from 'path';
import { createWriteStream, mkdirSync, existsSync, rmSync, createReadStream, writeFileSync, copyFileSync } from 'fs';
import { spawn, execFile } from 'child_process';
import { createHash } from 'crypto';
import { once } from 'node:events';
import { BETA_MANIFEST_NAME, compareVersions, distributionChannel, distributionProfile, isReleaseDownloadUrl, parseVersion, validateBetaManifest, validateReleaseManifest } from './updatePolicy';

declare const __ZABOR_DISTRIBUTION_CHANNEL__: string;

function getDistributionChannel() {
  return typeof __ZABOR_DISTRIBUTION_CHANNEL__ === 'string' && __ZABOR_DISTRIBUTION_CHANNEL__ === 'beta'
    ? 'beta' as const
    : distributionChannel(app.getVersion());
}

function getProfile() {
  return distributionProfile(getDistributionChannel());
}

declare const __ZABOR_UPDATE_SIGNER__: string;
const UPDATE_SIGNER = typeof __ZABOR_UPDATE_SIGNER__ === 'string' ? __ZABOR_UPDATE_SIGNER__ : '';

export interface UpdateInfo {
  version: string;
  currentVersion: string;
  releaseName: string;
  releaseNotes: string;
  publishedAt: string;
  downloadUrl: string;
  releaseUrl: string;
  fileSize: number;
  sha256: string;
}

export interface UpdateProgress {
  percent: number;
  transferred: number;
  total: number;
}

export interface UpdateCheckResult {
  updateAvailable: boolean;
  currentVersion: string;
  updateInfo?: UpdateInfo;
  error?: string;
}

export type UpdateStatus = 'idle' | 'available' | 'downloading' | 'downloaded' | 'installing' | 'error';

export interface UpdateSnapshot {
  status: UpdateStatus;
  updateInfo: UpdateInfo | null;
  progress: UpdateProgress | null;
  error: string | null;
}

const GITHUB_REPO = 'vnkdevelop/zabor-desktop';
const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_REPO}/releases/latest`;

function getUpdateTempDir(): string {
  return join(app.getPath('temp'), getProfile().updateDirectory);
}

export function cleanUpdateDirectory(): void {
  if (updateState.status === 'downloading' || updateState.status === 'downloaded' || updateState.status === 'installing') return;
  try {
    const tempDir = getUpdateTempDir();
    if (existsSync(tempDir)) {
      rmSync(tempDir, { recursive: true, force: true });
    }
    const tempSplash = join(app.getPath('temp'), getProfile().splashFile);
    if (existsSync(tempSplash)) {
      rmSync(tempSplash, { force: true });
    }
    const tempExe = join(app.getPath('temp'), `${getProfile().updater}.exe`);
    if (existsSync(tempExe)) {
      rmSync(tempExe, { force: true });
    }
  } catch {}
}

export function scheduleCleanUpdateDirectory(delayMs: number = 3000, retries: number = 5): void {
  const attempt = (remaining: number) => {
    cleanUpdateDirectory();
    try {
      const tempDir = getUpdateTempDir();
      if (existsSync(tempDir) && remaining > 0) {
        const retryTimer = setTimeout(() => attempt(remaining - 1), 2000);
        if (typeof retryTimer.unref === 'function') retryTimer.unref();
      }
    } catch {}
  };
  const initTimer = setTimeout(() => attempt(retries), delayMs);
  if (typeof initTimer.unref === 'function') initTimer.unref();
}

export function isNewerVersion(remote: string, current: string): boolean {
  return (compareVersions(remote, current || '0.0.0') ?? 0) > 0;
}

let downloadAbortController: AbortController | null = null;
let downloadInFlight = false;
let installInFlight = false;

const updateState: {
  status: UpdateStatus;
  updateInfo: UpdateInfo | null;
  progress: UpdateProgress | null;
  error: string | null;
  installerPath: string | null;
  expectedSha256: string;
} = {
  status: 'idle',
  updateInfo: null,
  progress: null,
  error: null,
  installerPath: null,
  expectedSha256: ''
};

function getSnapshot(): UpdateSnapshot {
  return {
    status: updateState.status,
    updateInfo: updateState.updateInfo,
    progress: updateState.progress,
    error: updateState.error
  };
}

async function fetchBetaRelease(currentVersion: string): Promise<UpdateInfo | undefined> {
  const releases: any[] = [];
  let pageUrl: string | null = `https://api.github.com/repos/${GITHUB_REPO}/releases?per_page=100`;
  let pages = 0;
  while (pageUrl && pages < 20) {
    const response = await fetch(pageUrl, {
      headers: { 'User-Agent': 'zabor-desktop', 'Accept': 'application/vnd.github.v3+json' },
      signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) throw new Error(`GitHub API error: ${response.status} ${response.statusText}`);
    const data: unknown = await response.json();
    if (!Array.isArray(data)) throw new Error('Invalid GitHub releases list');
    releases.push(...data.filter(release => release && release.prerelease === true && release.draft !== true &&
      distributionChannel(release.tag_name) === 'beta' && isNewerVersion(release.tag_name, currentVersion)));
    const next = /<([^>]+)>;\s*rel="next"/.exec(response.headers.get('link') ?? '')?.[1];
    if (next && !next.startsWith(`https://api.github.com/repos/${GITHUB_REPO}/releases?`)) throw new Error('Invalid GitHub pagination link');
    pageUrl = next ?? null;
    pages++;
  }
  if (pageUrl) throw new Error('GitHub release pagination limit reached');
  releases.sort((a, b) => -(compareVersions(a.tag_name, b.tag_name) ?? 0));
  for (const release of releases) {
    const version = parseVersion(release.tag_name)?.normalized;
    if (!version || !Array.isArray(release.assets)) continue;
    const asset = release.assets.find((item: any) => item?.name === BETA_MANIFEST_NAME);
    if (!asset || !isReleaseDownloadUrl(asset.browser_download_url) || asset.size > 65536) continue;
    const response = await fetch(asset.browser_download_url, { signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error(`Beta manifest error: ${response.status}`);
    const text = await response.text();
    if (text.length > 65536) throw new Error('Beta manifest too large');
    let manifest: unknown;
    try { manifest = JSON.parse(text); } catch { continue; }
    if (!validateBetaManifest(manifest, version, process.arch)) continue;
    const installer = release.assets.find((item: any) => item?.name === manifest.artifact.name && item.size === manifest.artifact.size);
    if (!installer || !isReleaseDownloadUrl(installer.browser_download_url)) continue;
    if (typeof installer.digest === 'string' && installer.digest && installer.digest.toLowerCase() !== `sha256:${manifest.artifact.sha256}`) continue;
    return {
      version, currentVersion, releaseName: release.name || `zabor ${version}`,
      releaseNotes: release.body || '', publishedAt: release.published_at || '',
      downloadUrl: installer.browser_download_url, releaseUrl: release.html_url || `https://github.com/${GITHUB_REPO}/releases`,
      fileSize: manifest.artifact.size, sha256: manifest.artifact.sha256
    };
  }
  return undefined;
}

export async function checkGitHubRelease(): Promise<UpdateCheckResult> {
  const currentVersion = app.getVersion();
  try {
    if (getDistributionChannel() === 'beta') {
      const updateInfo = await fetchBetaRelease(currentVersion);
      return { updateAvailable: !!updateInfo, currentVersion, ...(updateInfo ? { updateInfo } : {}) };
    }
    const response = await fetch(GITHUB_API_URL, {
      headers: {
        'User-Agent': 'zabor-desktop',
        'Accept': 'application/vnd.github.v3+json'
      }
    });

    if (!response.ok) {
      return {
        updateAvailable: false,
        currentVersion,
        error: `GitHub API error: ${response.status} ${response.statusText}`
      };
    }

    const data = await response.json() as any;
    const tagName = (data.tag_name || '').toString();
    const isNewer = data.prerelease !== true && data.draft !== true && !parseVersion(tagName)?.prerelease.length && isNewerVersion(tagName, currentVersion);

    if (!isNewer) {
      if (updateState.status !== 'downloading' && updateState.status !== 'downloaded' && updateState.status !== 'installing') {
        updateState.status = 'idle';
        updateState.updateInfo = null;
        updateState.progress = null;
        updateState.error = null;
        updateState.installerPath = null;
      }
      return {
        updateAvailable: false,
        currentVersion
      };
    }

    const assets = Array.isArray(data.assets) ? data.assets : [];
    let setupAsset = assets.find((a: any) => typeof a.name === 'string' && a.name.toLowerCase().endsWith('.exe'));
    let manifestSha256 = '';
    const stableManifestAsset = assets.find((asset: any) => asset?.name === 'zabor-stable-manifest.json');
    if (stableManifestAsset) {
      if (!isReleaseDownloadUrl(stableManifestAsset.browser_download_url) || stableManifestAsset.size > 65536) throw new Error('stable-release-manifest-invalid');
      const response = await fetch(stableManifestAsset.browser_download_url, { signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new Error('stable-release-manifest-unavailable');
      const text = await response.text();
      if (text.length > 65536) throw new Error('stable-release-manifest-invalid');
      const manifest: unknown = JSON.parse(text);
      const version = parseVersion(tagName)?.normalized ?? '';
      if (!validateReleaseManifest(manifest, 'stable', version, process.arch)) throw new Error('stable-release-manifest-invalid');
      setupAsset = assets.find((asset: any) => asset?.name === manifest.artifact.name && asset.size === manifest.artifact.size);
      if (!setupAsset || !isReleaseDownloadUrl(setupAsset.browser_download_url) || setupAsset.digest && setupAsset.digest.toLowerCase() !== `sha256:${manifest.artifact.sha256}`) throw new Error('stable-release-artifact-invalid');
      manifestSha256 = manifest.artifact.sha256;
    }

    const downloadUrl = setupAsset ? setupAsset.browser_download_url : data.html_url;
    const fileSize = setupAsset ? setupAsset.size : 0;
    const digest = setupAsset && typeof setupAsset.digest === 'string' ? setupAsset.digest : '';
    const sha256 = manifestSha256 || (digest.toLowerCase().startsWith('sha256:') ? digest.slice(7).toLowerCase() : '');

    const updateInfo: UpdateInfo = {
      version: tagName.replace(/^v/i, ''),
      currentVersion,
      releaseName: data.name || `zabor ${tagName}`,
      releaseNotes: data.body || '',
      publishedAt: data.published_at || '',
      downloadUrl,
      releaseUrl: data.html_url || `https://github.com/${GITHUB_REPO}/releases`,
      fileSize,
      sha256
    };

    return {
      updateAvailable: true,
      currentVersion,
      updateInfo
    };
  } catch (err: any) {
    return {
      updateAvailable: false,
      currentVersion,
      error: err?.message || 'Failed to fetch release'
    };
  }
}

function installerNeedsElevation(): boolean {
  if (process.platform !== 'win32') return false;
  return true;
}

function hashFile(filePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256');
    const stream = createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex').toLowerCase()));
  });
}

function verifyAuthenticode(filePath: string): Promise<{ valid: boolean; subject: string; status: string }> {
  return new Promise(resolve => {
    if (process.platform !== 'win32') {
      resolve({ valid: false, subject: '', status: 'not-windows' });
      return;
    }
    const psScript =
      `$ErrorActionPreference='Stop';` +
      `$s=Get-AuthenticodeSignature -LiteralPath $args[0];` +
      `$o=[ordered]@{status=$s.Status.ToString();subject=''};` +
      `if($s.SignerCertificate){$o.subject=$s.SignerCertificate.Subject};` +
      `ConvertTo-Json -Compress -InputObject $o`;
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', psScript, filePath],
      { timeout: 30000, windowsHide: true },
      (err, stdout) => {
        if (err) {
          resolve({ valid: false, subject: '', status: 'verify-failed' });
          return;
        }
        try {
          const parsed = JSON.parse(String(stdout).trim());
          const status = String(parsed.status || '');
          const subject = String(parsed.subject || '');
          resolve({ valid: status === 'Valid', subject, status });
        } catch {
          resolve({ valid: false, subject: '', status: 'parse-failed' });
        }
      }
    );
  });
}

async function verifyInstaller(filePath: string, expectedSha256: string): Promise<{ ok: boolean; reason: string }> {
  if (getDistributionChannel() === 'beta' && !/^[0-9a-f]{64}$/.test(expectedSha256)) {
    return { ok: false, reason: 'expected-sha256-missing' };
  }
  if (expectedSha256) {
    let actual: string;
    try {
      actual = await hashFile(filePath);
    } catch {
      return { ok: false, reason: 'hash-error' };
    }
    if (actual !== expectedSha256) {
      return { ok: false, reason: 'sha256-mismatch' };
    }
  }

  if (process.platform === 'win32' && UPDATE_SIGNER) {
    const sig = await verifyAuthenticode(filePath);
    if (!sig.valid) return { ok: false, reason: `signature-${sig.status}` };
    const subjectMatch = sig.subject.toLowerCase().includes(UPDATE_SIGNER.toLowerCase());
    if (!subjectMatch) return { ok: false, reason: 'signer-mismatch' };
  }

  return { ok: true, reason: expectedSha256 ? 'sha256+signature' : 'signature-only' };
}

const INSTALL_SPLASH_SCRIPT = `
[CmdletBinding()]
param(
    [int]$ParentPid = 0
)

Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="ZaborUpdater"
        WindowStyle="None"
        AllowsTransparency="True"
        Background="Transparent"
        ShowInTaskbar="False"
        Topmost="True"
        WindowStartupLocation="CenterScreen"
        Width="380" Height="140">
    <Grid VerticalAlignment="Center" HorizontalAlignment="Center">
        <Border Width="240" Height="110" CornerRadius="16"
                Background="#D90A0A0E" BorderBrush="#24FFFFFF" BorderThickness="1">
            <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center">
                <TextBlock Text="zabor" FontSize="26" FontWeight="Black" Foreground="#FFFFFF" HorizontalAlignment="Center" Margin="0,0,0,12"/>
                <Grid Height="4" Width="160" HorizontalAlignment="Center">
                    <Border CornerRadius="2" Background="#2BFFFFFF"/>
                    <Canvas ClipToBounds="True">
                        <Border Name="Indicator" CornerRadius="2" Height="4" Width="50" Background="#FFFFFF">
                            <Border.Triggers>
                                <EventTrigger RoutedEvent="Loaded">
                                    <BeginStoryboard>
                                        <Storyboard RepeatBehavior="Forever">
                                            <DoubleAnimation Storyboard.TargetProperty="(Canvas.Left)"
                                                             From="-50" To="160"
                                                             Duration="0:0:1.1"/>
                                        </Storyboard>
                                    </BeginStoryboard>
                                </EventTrigger>
                            </Border.Triggers>
                        </Border>
                    </Canvas>
                </Grid>
            </StackPanel>
        </Border>
    </Grid>
</Window>
'@

try {
    $reader = [System.Xml.XmlNodeReader]::new([xml]$xaml)
    $window = [System.Windows.Markup.XamlReader]::Load($reader)

    $window.Add_MouseLeftButtonDown({ $window.DragMove() })
    $window.Add_KeyDown({ if ($_.Key -eq [System.Windows.Input.Key]::Escape) { $window.Close() } })

    $timer = New-Object System.Windows.Threading.DispatcherTimer
    $timer.Interval = [TimeSpan]::FromMilliseconds(500)
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    $timer.Add_Tick({
        if ($stopwatch.Elapsed.TotalSeconds -gt 600) {
            $window.Close()
            return
        }

        if ($stopwatch.Elapsed.TotalSeconds -gt 6) {
            try {
                $setupProcs = Get-Process -Name "ZABOR-Setup*" -ErrorAction SilentlyContinue
                if ($setupProcs) {
                    return
                }

                if ($stopwatch.Elapsed.TotalSeconds -gt 10) {
                    $procs = Get-Process -Name "ZABOR" -ErrorAction SilentlyContinue
                    if ($procs) {
                        $newProc = if ($ParentPid -gt 0) {
                            $procs | Where-Object { $_.Id -ne $ParentPid }
                        } else {
                            $procs
                        }
                        if ($newProc) {
                            $window.Close()
                            return
                        }
                    }

                    if ($stopwatch.Elapsed.TotalSeconds -gt 15) {
                        $window.Close()
                        return
                    }
                }
            } catch {}
        }
    })

    $timer.Start()
    [void]$window.ShowDialog()
} catch {
}
`;

export function launchInstallSplash(): void {
  if (process.platform !== 'win32') return;

  try {
    const profile = getProfile();
    const splashArgs = [String(process.pid), ...(getDistributionChannel() === 'beta' ? ['beta'] : [])];
    const devPath = join(app.getAppPath(), 'build', 'ZaborUpdater.exe');
    const prodPath = typeof process.resourcesPath === 'string' ? join(process.resourcesPath, `${profile.updater}.exe`) : '';
    const updaterExe = (prodPath && existsSync(prodPath)) ? prodPath : existsSync(devPath) ? devPath : null;

    if (updaterExe) {
      try {
        const tempExe = join(app.getPath('temp'), `${profile.updater}.exe`);
        copyFileSync(updaterExe, tempExe);
        const child = spawn(tempExe, splashArgs, {
          detached: true,
          stdio: 'ignore'
        });
        child.on('error', (err) => {
          console.warn('[installSplash] Failed to spawn ZaborUpdater from temp:', err);
        });
        child.unref();
        return;
      } catch {
        const child = spawn(updaterExe, splashArgs, {
          detached: true,
          stdio: 'ignore'
        });
        child.on('error', (err) => {
          console.warn('[installSplash] Failed to spawn ZaborUpdater window:', err);
        });
        child.unref();
        return;
      }
    }

    const scriptPath = join(app.getPath('temp'), profile.splashFile);
    const splashScript = getDistributionChannel() === 'beta'
      ? INSTALL_SPLASH_SCRIPT.replace(/ZaborUpdater/g, profile.updater).replace(/ZABOR-Setup/g, 'ZABOR-Beta-Setup').replace(/"ZABOR"/g, `"${profile.executable}"`)
      : INSTALL_SPLASH_SCRIPT;
    writeFileSync(scriptPath, splashScript.trim(), 'utf-8');

    const currentPid = process.pid;
    const child = spawn(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-WindowStyle',
        'Hidden',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        scriptPath,
        '-ParentPid',
        String(currentPid)
      ],
      {
        detached: true,
        stdio: 'ignore',
        windowsHide: true
      }
    );

    child.on('error', (err) => {
      console.warn('[installSplash] Failed to spawn splash window:', err);
    });

    child.unref();
  } catch (err) {
    console.warn('[installSplash] Error launching splash window:', err);
  }
}

export function setupUpdater(
  getMainWindow: () => BrowserWindow | null,
  openUpdaterWindow?: () => BrowserWindow | null
): void {
  cleanUpdateDirectory();
  scheduleCleanUpdateDirectory(3000, 5);

  const sendToWindow = (channel: string, payload?: unknown): void => {
    const windows = BrowserWindow.getAllWindows();
    for (const win of windows) {
      if (!win.isDestroyed()) {
        try {
          win.webContents.send(channel, payload);
        } catch {}
      }
    }
  };

  ipcMain.handle('check-for-updates', async () => {
    const result = await checkGitHubRelease();
    if (
      result.updateAvailable &&
      result.updateInfo &&
      (updateState.status === 'idle' || updateState.status === 'available' || updateState.status === 'error')
    ) {
      updateState.status = 'available';
      updateState.updateInfo = result.updateInfo;
      updateState.progress = null;
      updateState.error = null;
    } else if (!result.updateAvailable) {
      if (updateState.status !== 'downloading' && updateState.status !== 'downloaded' && updateState.status !== 'installing') {
        updateState.status = 'idle';
        updateState.updateInfo = null;
        updateState.progress = null;
        updateState.error = null;
        updateState.installerPath = null;
      }
    }
    return result;
  });

  ipcMain.handle('get-update-status', (): UpdateSnapshot => {
    return getSnapshot();
  });

  ipcMain.handle('get-app-version', () => {
    return app.getVersion();
  });

  ipcMain.handle('open-external-url', async (_event, url: string) => {
    if (typeof url === 'string') {
      try {
        const parsed = new URL(url);
        if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
          await shell.openExternal(url);
          return true;
        }
      } catch {}
    }
    return false;
  });

  ipcMain.handle('start-update-download', async (_event, downloadUrl: string, version: string) => {
    if (downloadInFlight || installInFlight || updateState.status === 'downloading') return { success: false, message: 'Already downloading' };
    const allowedPrefix = `https://github.com/${GITHUB_REPO}/releases/download/`;
    if (!downloadUrl || typeof downloadUrl !== 'string' || !downloadUrl.startsWith(allowedPrefix)) {
      return { success: false, message: 'Invalid download url' };
    }

    if (getDistributionChannel() === 'beta' && (!isReleaseDownloadUrl(downloadUrl) ||
      updateState.updateInfo?.downloadUrl !== downloadUrl || updateState.updateInfo.version !== version ||
      !/^[0-9a-f]{64}$/.test(updateState.updateInfo.sha256))) {
      return { success: false, message: 'Unverified beta update' };
    }

    cleanUpdateDirectory();

    const tempDir = getUpdateTempDir();
    try {
      if (!existsSync(tempDir)) {
        mkdirSync(tempDir, { recursive: true });
      }
    } catch {}

    const safeVersion = getDistributionChannel() === 'beta'
      ? parseVersion(version)?.normalized ?? ''
      : version ? String(version).replace(/[^a-zA-Z0-9.-]/g, '') : '';
    if (!safeVersion) {
      return { success: false, message: 'Invalid version identifier' };
    }

    const fileName = getDistributionChannel() === 'beta'
      ? `ZABOR-Beta-Setup-${safeVersion}-${process.arch}.exe`
      : `ZABOR-Setup-${safeVersion}.exe`;
    const targetPath = join(tempDir, fileName);

    updateState.status = 'downloading';
    updateState.progress = { percent: 0, transferred: 0, total: 0 };
    updateState.error = null;
    updateState.installerPath = null;
    updateState.expectedSha256 =
      updateState.updateInfo && updateState.updateInfo.version === safeVersion.replace(/^v/i, '')
        ? updateState.updateInfo.sha256
        : '';
    const controller = new AbortController();
    downloadAbortController = controller;
    downloadInFlight = true;
    let fileStream: ReturnType<typeof createWriteStream> | null = null;
    let streamClosed: Promise<void> | null = null;

    try {
      const response = await fetch(downloadUrl, {
        headers: { 'User-Agent': 'zabor-desktop' },
        signal: controller.signal
      });
      if (controller.signal.aborted) throw new DOMException('update-cancelled', 'AbortError');

      if (!response.ok || !response.body) {
        throw new Error(`Download response not ok: ${response.status} ${response.statusText}`);
      }

      const total = Number(response.headers.get('content-length')) || 0;
      let transferred = 0;

      const reader = response.body.getReader();
      fileStream = createWriteStream(targetPath);
      streamClosed = new Promise(resolve => fileStream!.once('close', resolve));
      fileStream.on('error', () => {});

      while (true) {
        const { done, value } = await reader.read();
        if (controller.signal.aborted) throw new DOMException('update-cancelled', 'AbortError');
        if (done) break;

        transferred += value.length;
        if (!fileStream.write(Buffer.from(value))) await once(fileStream, 'drain', { signal: controller.signal });

        const percent = total > 0 ? Math.round((transferred / total) * 100) : 0;
        const progress: UpdateProgress = { percent, transferred, total };
        updateState.progress = progress;
        sendToWindow('update-download-progress', progress);
      }

      await new Promise<void>((resolve, reject) => {
        if (!fileStream) return resolve();
        fileStream.on('error', reject);
        fileStream.end(() => resolve());
      });
      if (controller.signal.aborted) throw new DOMException('update-cancelled', 'AbortError');

      updateState.status = 'downloaded';
      updateState.installerPath = targetPath;
      downloadAbortController = null;

      sendToWindow('update-downloaded', { filePath: targetPath });

      return { success: true, filePath: targetPath };
    } catch (err: any) {
      downloadAbortController = null;
      updateState.installerPath = null;
      if (fileStream) {
        try {
          fileStream.destroy();
        } catch {}
        fileStream = null;
      }
      if (updateState.status === 'downloading') {
        updateState.status = 'error';
        updateState.error = err?.message || 'Download error';
        updateState.progress = null;
        cleanUpdateDirectory();
        sendToWindow('update-error', err?.message || 'Download error');
        return { success: false, error: err?.message };
      }
      cleanUpdateDirectory();
      return { success: false };
    } finally {
      if (streamClosed) await streamClosed;
      downloadInFlight = false;
      const settledStatus = updateState.status as UpdateStatus;
      if (settledStatus !== 'downloaded' && settledStatus !== 'installing') cleanUpdateDirectory();
    }
  });

  ipcMain.handle('cancel-update-download', () => {
    if (downloadAbortController) {
      downloadAbortController.abort();
      downloadAbortController = null;
      updateState.installerPath = null;
      updateState.progress = null;
      updateState.error = null;
      updateState.status = updateState.updateInfo ? 'available' : 'idle';
      cleanUpdateDirectory();
      return true;
    }
    return false;
  });

  ipcMain.handle('install-update', async () => {
    if (installInFlight || downloadInFlight || updateState.status === 'installing') return { success: false, message: 'Already downloading' };
    if (!updateState.installerPath || !existsSync(updateState.installerPath)) {
      return { success: false, message: 'Installer not found' };
    }

    const installerPath = updateState.installerPath;
    installInFlight = true;
    try {
    const verification = await verifyInstaller(installerPath, updateState.expectedSha256);
    if (!verification.ok) {
      updateState.status = 'error';
      updateState.error = `installer-verification-failed:${verification.reason}`;
      updateState.installerPath = null;
      cleanUpdateDirectory();
      sendToWindow('update-error', `installer-verification-failed:${verification.reason}`);
      return { success: false, message: `Installer verification failed: ${verification.reason}` };
    }

    launchInstallSplash();

    const installerArgs = ['/S', '--updated', '--keep-app-data', '--force-run'];

    try {
      updateState.status = 'installing';
      sendToWindow('update-installing');

      try {
        if (typeof app.releaseSingleInstanceLock === 'function') {
          app.releaseSingleInstanceLock();
        }
      } catch {}

      const windows = BrowserWindow.getAllWindows();
      for (const win of windows) {
        if (!win.isDestroyed()) {
          try {
            win.destroy();
          } catch {}
        }
      }

      if (process.platform === 'win32') {
        if (installerNeedsElevation()) {
          const prodElevate = typeof process.resourcesPath === 'string' ? join(process.resourcesPath, 'elevate.exe') : '';
          const devElevate = join(app.getAppPath(), 'release', 'win-unpacked', 'resources', 'elevate.exe');
          const elevatePath = (prodElevate && existsSync(prodElevate)) ? prodElevate : existsSync(devElevate) ? devElevate : null;

          if (elevatePath) {
            const child = spawn(elevatePath, [installerPath, ...installerArgs], {
              detached: true,
              stdio: 'ignore',
              windowsHide: true
            });
            child.on('error', () => {});
            child.unref();
          } else {
            const psScript = `Start-Process -FilePath "${installerPath.replace(/"/g, '`"')}" -ArgumentList '/S','--updated','--keep-app-data','--force-run' -Verb RunAs`;
            const child = spawn('powershell.exe', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', psScript], {
              detached: true,
              stdio: 'ignore',
              windowsHide: true
            });
            child.on('error', () => {});
            child.unref();
          }
        } else {
          const child = spawn(installerPath, installerArgs, {
            detached: true,
            stdio: 'ignore',
            windowsHide: true
          });
          child.on('error', () => {});
          child.unref();
        }
      } else {
        await shell.openPath(installerPath);
      }

      setTimeout(() => {
        app.exit(0);
      }, 150);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
    } finally {
      installInFlight = false;
    }
  });

  setTimeout(async () => {
    cleanUpdateDirectory();
    const window = getMainWindow();
    if (!window || window.isDestroyed()) return;

    const result = await checkGitHubRelease();
    if (result.updateAvailable && result.updateInfo) {
      if (updateState.status === 'idle' || updateState.status === 'available' || updateState.status === 'error') {
        updateState.status = 'available';
        updateState.updateInfo = result.updateInfo;
        updateState.progress = null;
        updateState.error = null;
      }
      sendToWindow('update-available', result.updateInfo);
    } else if (!result.updateAvailable) {
      if (updateState.status !== 'downloading' && updateState.status !== 'downloaded' && updateState.status !== 'installing') {
        updateState.status = 'idle';
        updateState.updateInfo = null;
        updateState.progress = null;
        updateState.error = null;
        updateState.installerPath = null;
      }
    }
  }, 4000);
}
