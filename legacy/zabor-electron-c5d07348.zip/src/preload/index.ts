import { contextBridge, ipcRenderer, webUtils } from 'electron'

interface StreamAudioMetadata {
  sampleRate: number
  channels: number
  bitsPerSample: number
  isFloat: boolean
}

const windowControls = {
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  close: () => ipcRenderer.send('window-close'),
  quit: () => ipcRenderer.send('app-quit'),
  wipeAppData: (options?: { preserveChat?: boolean }) => ipcRenderer.invoke('wipe-app-data', options),
  getUserDataPath: () => ipcRenderer.invoke('get-userdata-path'),
  loadSileroModel: (): Promise<Uint8Array> => ipcRenderer.invoke('load-silero-model'),
  getClientRuntime: (): Promise<{ rustVoicing: boolean; channel: 'stable' | 'beta'; version: string }> => ipcRenderer.invoke('get-client-runtime'),
  loadRustVoicing: (): Promise<Uint8Array | null> => ipcRenderer.invoke('load-rust-voicing'),
  loadDeepFilterAsset: (assetPath: string): Promise<Uint8Array | null> =>
    ipcRenderer.invoke('load-deepfilter-asset', assetPath),
  getAutoLaunch: (): Promise<boolean> => ipcRenderer.invoke('get-auto-launch'),
  setAutoLaunch: (enabled: boolean): Promise<boolean> => ipcRenderer.invoke('set-auto-launch', enabled),
  getMinimizeToTray: (): Promise<boolean> => ipcRenderer.invoke('get-minimize-to-tray'),
  setMinimizeToTray: (enabled: boolean): Promise<boolean> => ipcRenderer.invoke('set-minimize-to-tray', enabled),
  getWebrtcRelayOnly: (): Promise<boolean> => ipcRenderer.invoke('get-webrtc-relay-only'),
  setWebrtcRelayOnly: (enabled: boolean): Promise<boolean> => ipcRenderer.invoke('set-webrtc-relay-only', enabled),
  saveSession: (data: string): Promise<boolean> => ipcRenderer.invoke('save-session', data),
  loadSession: (): Promise<string | null> => ipcRenderer.invoke('load-session'),
  clearSession: (): Promise<boolean> => ipcRenderer.invoke('clear-session'),
  loadChatIdentity: (): Promise<string | null> => ipcRenderer.invoke('chat-identity-load'),
  saveChatIdentity: (data: string): Promise<boolean> => ipcRenderer.invoke('chat-identity-save', data),
  getPathForFile: (file: File): string => webUtils.getPathForFile(file),
  chatFilePick: () => ipcRenderer.invoke('chat-file-pick'),
  chatFileImport: (filePaths: string[]) => ipcRenderer.invoke('chat-file-import', filePaths),
  chatFileBegin: (transferId: string, fileName: string, size: number) => ipcRenderer.invoke('chat-file-begin', transferId, fileName, size),
  chatFileChunk: (transferId: string, chunk: Uint8Array) => ipcRenderer.invoke('chat-file-chunk', transferId, chunk),
  chatFileCommit: (transferId: string) => ipcRenderer.invoke('chat-file-commit', transferId),
  chatFileAbort: (transferId: string): Promise<boolean> => ipcRenderer.invoke('chat-file-abort', transferId),
  chatFileDelete: (storedName: string): Promise<boolean> => ipcRenderer.invoke('chat-file-delete', storedName),
  chatFileDeleteMany: (storedNames: string[]): Promise<number> => ipcRenderer.invoke('chat-file-delete-many', storedNames),
  chatFileStat: (storedName: string) => ipcRenderer.invoke('chat-file-stat', storedName),
  chatFileHash: (storedName: string): Promise<string | null> => ipcRenderer.invoke('chat-file-hash', storedName),
  chatFileReadOpen: (storedName: string): Promise<string | null> => ipcRenderer.invoke('chat-file-read-open', storedName),
  chatFileReadBlock: (readId: string, offset: number, length: number): Promise<Uint8Array | null> => ipcRenderer.invoke('chat-file-read-block', readId, offset, length),
  chatFileReadClose: (readId: string): Promise<boolean> => ipcRenderer.invoke('chat-file-read-close', readId),
  chatFileSaveAs: (storedName: string, suggestedName: string): Promise<boolean> => ipcRenderer.invoke('chat-file-save-as', storedName, suggestedName),
  chatFileReveal: (storedName: string): Promise<boolean> => ipcRenderer.invoke('chat-file-reveal', storedName),
  chatFilePickSavePath: (suggestedName: string): Promise<string | null> => ipcRenderer.invoke('chat-file-pick-save-path', suggestedName),
  chatFileSaveTo: (storedName: string, destPath: string): Promise<boolean> => ipcRenderer.invoke('chat-file-save-to', storedName, destPath),
  chatFileRevealPath: (absPath: string): Promise<boolean> => ipcRenderer.invoke('chat-file-reveal-path', absPath),
  chatFilesPrune: (keepNames: string[]): Promise<number> => ipcRenderer.invoke('chat-files-prune', keepNames),
  chatFilesWipe: (): Promise<boolean> => ipcRenderer.invoke('chat-files-wipe'),
  getClientAttestation: (): Promise<string | null> => ipcRenderer.invoke('get-client-attestation'),
  onBeforeQuit: (callback: () => void) => {
    ipcRenderer.on('before-quit', callback)
    return () => { ipcRenderer.removeAllListeners('before-quit') }
  },
  onMaximizeChange: (callback: (isMaximized: boolean) => void) => {
    ipcRenderer.on('window-maximized', () => callback(true))
    ipcRenderer.on('window-unmaximized', () => callback(false))
    return () => {
      ipcRenderer.removeAllListeners('window-maximized')
      ipcRenderer.removeAllListeners('window-unmaximized')
    }
  },
  getDesktopSources: (options?: any) => ipcRenderer.invoke('get-desktop-sources', options),
  startStreamAudioCapture: (sourceId: string): Promise<boolean> =>
    ipcRenderer.invoke('start-stream-audio-capture', sourceId),
  stopStreamAudioCapture: (): Promise<boolean> => ipcRenderer.invoke('stop-stream-audio-capture'),
  onStreamAudioData: (callback: (data: Uint8Array, metadata: StreamAudioMetadata) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, data: Uint8Array, metadata: StreamAudioMetadata) => {
      callback(data, metadata)
    }
    ipcRenderer.on('stream-audio-data', listener)
    return () => { ipcRenderer.removeListener('stream-audio-data', listener) }
  },
  getAppVersion: (): Promise<string> => ipcRenderer.invoke('get-app-version'),
  checkForUpdates: (): Promise<any> => ipcRenderer.invoke('check-for-updates'),
  getUpdateStatus: (): Promise<any> => ipcRenderer.invoke('get-update-status'),
  openUpdaterWindow: (): Promise<boolean> => ipcRenderer.invoke('open-updater-window'),
  startUpdateDownload: (downloadUrl: string, version: string): Promise<{ success: boolean; filePath?: string; error?: string }> =>
    ipcRenderer.invoke('start-update-download', downloadUrl, version),
  cancelUpdateDownload: (): Promise<boolean> => ipcRenderer.invoke('cancel-update-download'),
  installUpdate: (): Promise<{ success: boolean; message?: string; error?: string }> =>
    ipcRenderer.invoke('install-update'),
  openExternalUrl: (url: string): Promise<boolean> => ipcRenderer.invoke('open-external-url', url),
  onUpdateAvailable: (callback: (info: any) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, info: any) => callback(info)
    ipcRenderer.on('update-available', listener)
    return () => { ipcRenderer.removeListener('update-available', listener) }
  },
  onUpdateDownloadProgress: (callback: (progress: any) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, progress: any) => callback(progress)
    ipcRenderer.on('update-download-progress', listener)
    return () => { ipcRenderer.removeListener('update-download-progress', listener) }
  },
  onUpdateProgress: (callback: (progress: any) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, progress: any) => callback(progress)
    ipcRenderer.on('update-download-progress', listener)
    return () => { ipcRenderer.removeListener('update-download-progress', listener) }
  },
  onUpdateDownloaded: (callback: (data: { filePath: string }) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, data: any) => callback(data)
    ipcRenderer.on('update-downloaded', listener)
    return () => { ipcRenderer.removeListener('update-downloaded', listener) }
  },
  onUpdateError: (callback: (error: string) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, error: string) => callback(error)
    ipcRenderer.on('update-error', listener)
    return () => { ipcRenderer.removeListener('update-error', listener) }
  },
  onUpdateInstalling: (callback: () => void) => {
    const listener = () => callback()
    ipcRenderer.on('update-installing', listener)
    return () => { ipcRenderer.removeListener('update-installing', listener) }
  },
  setDisplayMediaSource: (sourceId: string | null): Promise<boolean> =>
    ipcRenderer.invoke('set-display-media-source', sourceId),
  writeDiagnostic: (record: unknown): void => ipcRenderer.send('write-diagnostic', record),
  diagnosticsDirectory: (): Promise<string> => ipcRenderer.invoke('diagnostics-directory'),
  remoteControlStart: (): Promise<boolean> => ipcRenderer.invoke('remote-control:start'),
  remoteControlStop: (): Promise<boolean> => ipcRenderer.invoke('remote-control:stop'),
  remoteControlReset: (): Promise<boolean> => ipcRenderer.invoke('remote-control:reset'),
  remoteControlGetScreen: (): Promise<{ width: number; height: number; x: number; y: number }> =>
    ipcRenderer.invoke('remote-control:get-screen'),
  remoteControlClipCursor: (rect: { left: number; top: number; right: number; bottom: number }): Promise<boolean> =>
    ipcRenderer.invoke('remote-control:clip-cursor', rect),
  remoteControlUnclipCursor: (): Promise<boolean> =>
    ipcRenderer.invoke('remote-control:unclip-cursor'),
  remoteControlHideHostCursor: (): Promise<boolean> =>
    ipcRenderer.invoke('remote-control:hide-host-cursor'),
  remoteControlShowHostCursor: (): Promise<boolean> =>
    ipcRenderer.invoke('remote-control:show-host-cursor'),
  remoteControlMove: (absX: number, absY: number) => ipcRenderer.send('remote-control:move', absX, absY),
  remoteControlMoveNormalized: (xNorm: number, yNorm: number) =>
    ipcRenderer.send('remote-control:move-normalized', xNorm, yNorm),
  remoteControlMouseButton: (button: number, down: boolean) =>
    ipcRenderer.send('remote-control:mouse-button', button, down),
  remoteControlMouseWheel: (delta: number, horizontal = 0) => ipcRenderer.send('remote-control:mouse-wheel', delta, horizontal),
  remoteControlKey: (vk: number, down: boolean) => ipcRenderer.send('remote-control:key', vk, down),
  remoteControlShowPill: (data: { controllerName: string; isControlling: boolean }) =>
    ipcRenderer.send('remote-control:show-pill', data),
  remoteControlHidePill: () => ipcRenderer.send('remote-control:hide-pill'),
  onRemoteControlHostActivity: (callback: (data: { type: 'move' | 'click'; dist?: number }) => void) => {
    const listener = (_event: Electron.IpcRendererEvent, data: any) => callback(data)
    ipcRenderer.on('remote-control:host-activity', listener)
    return () => { ipcRenderer.removeListener('remote-control:host-activity', listener) }
  },
  onRemoteControlPanicRevoke: (callback: () => void) => {
    const listener = () => callback()
    ipcRenderer.on('remote-control:panic-revoke', listener)
    return () => { ipcRenderer.removeListener('remote-control:panic-revoke', listener) }
  }
}

contextBridge.exposeInMainWorld('windowControls', windowControls)
